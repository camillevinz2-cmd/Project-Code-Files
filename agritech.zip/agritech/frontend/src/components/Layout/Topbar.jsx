import React from 'react';
import { FaBars } from 'react-icons/fa';

const Topbar = ({ title, subtitle, actions, onMenuClick }) => {
  return (
    <div className="app-topbar">
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <button
          onClick={onMenuClick}
          style={{
            background: 'none', border: 'none',
            color: 'var(--text-secondary)', cursor: 'pointer',
            display: 'none', padding: 4,
          }}
          className="topbar-menu-btn"
        >
          <FaBars size={16} />
        </button>
        <div>
          {title && (
            <h1 style={{
              fontSize: '1.05rem',
              fontWeight: 700,
              color: 'var(--text-primary)',
              lineHeight: 1.2,
            }}>
              {title}
            </h1>
          )}
          {subtitle && (
            <p style={{
              fontSize: '0.75rem',
              color: 'var(--text-muted)',
              marginTop: 1,
            }}>
              {subtitle}
            </p>
          )}
        </div>
      </div>
      {actions && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          {actions}
        </div>
      )}
    </div>
  );
};

export default Topbar;
