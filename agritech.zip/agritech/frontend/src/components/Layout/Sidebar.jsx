import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import {
  FaLeaf, FaTachometerAlt, FaTractor, FaSeedling,
  FaComments, FaStore, FaChartLine, FaShieldAlt,
  FaUser, FaCog, FaSignOutAlt, FaChevronDown,
  FaBars, FaTimes
} from 'react-icons/fa';

const NAV_LINKS = [
  { to: '/dashboard',   label: 'Dashboard',   icon: FaTachometerAlt, show: (isAdmin) => !isAdmin },
  { to: '/farms',       label: 'Farms',       icon: FaTractor,       show: (isAdmin) => !isAdmin },
  { to: '/crops',       label: 'Crops',       icon: FaSeedling,      show: (isAdmin) => !isAdmin },
  { to: '/analytics',   label: 'Analytics',   icon: FaChartLine,     show: (isAdmin) => !isAdmin },
  { to: '/forum',       label: 'Forum',       icon: FaComments,      show: () => true },
  { to: '/marketplace', label: 'Marketplace', icon: FaStore,         show: () => true },
  { to: '/admin',       label: 'Admin Panel', icon: FaShieldAlt,     show: (isAdmin) => isAdmin },
];

const Sidebar = ({ mobileOpen, onMobileClose }) => {
  const { user, logout, isAdmin } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [profilePic, setProfilePic] = useState('');
  const menuRef = useRef(null);

  useEffect(() => {
    const stored = localStorage.getItem('user');
    if (stored) {
      const u = JSON.parse(stored);
      if (u.profilePicture) {
        setProfilePic(
          u.profilePicture.startsWith('/uploads/')
            ? `http://localhost:5000${u.profilePicture}`
            : u.profilePicture
        );
      }
    }
  }, [user]);

  useEffect(() => {
    const handler = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const getUser = () => {
    try { return JSON.parse(localStorage.getItem('user') || '{}'); } catch { return {}; }
  };

  const u = getUser();
  const displayName = u.name?.split(' ')[0] || 'User';
  const role = u.role || 'farmer';
  const avatarSrc = profilePic || `https://ui-avatars.com/api/?name=${encodeURIComponent(u.name || 'U')}&background=16a34a&color=ffffff&size=64`;

  const isActive = (path) => location.pathname === path;

  return (
    <>
      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          onClick={onMobileClose}
          style={{
            position: 'fixed', inset: 0,
            background: 'rgba(15,45,26,0.4)',
            zIndex: 99,
            display: 'none',
          }}
          className="mobile-overlay"
        />
      )}

      <aside className={`app-sidebar${mobileOpen ? ' open' : ''}`}>
        {/* Brand */}
        <div className="sidebar-brand">
          <div className="sidebar-brand-icon">
            <FaLeaf style={{ color: '#fff', fontSize: 16 }} />
          </div>
          <span className="sidebar-brand-text">
            Agri<span>Tech</span>
          </span>
          <button
            onClick={onMobileClose}
            style={{
              marginLeft: 'auto', background: 'none', border: 'none',
              color: 'var(--text-muted)', cursor: 'pointer', display: 'none',
            }}
            className="sidebar-close-btn"
          >
            <FaTimes size={14} />
          </button>
        </div>

        {/* Nav */}
        <nav className="sidebar-nav">
          <span className="sidebar-section-label">Navigation</span>
          {NAV_LINKS.map((link) => {
            if (!link.show(isAdmin)) return null;
            const Icon = link.icon;
            const active = isActive(link.to);
            return (
              <Link
                key={link.to}
                to={link.to}
                className={`sidebar-link${active ? ' active' : ''}`}
                onClick={onMobileClose}
              >
                <span className="sidebar-link-icon">
                  <Icon size={14} />
                </span>
                {link.label}
                {active && (
                  <span style={{
                    marginLeft: 'auto',
                    width: 6, height: 6,
                    borderRadius: '50%',
                    background: 'var(--green)',
                    flexShrink: 0,
                  }} />
                )}
              </Link>
            );
          })}
        </nav>

        {/* User section */}
        <div className="sidebar-user" ref={menuRef}>
          {userMenuOpen && (
            <div style={{
              position: 'absolute',
              bottom: '80px',
              left: '12px',
              right: '12px',
              background: 'var(--bg-surface)',
              border: '1px solid var(--border-strong)',
              borderRadius: 'var(--radius-md)',
              boxShadow: 'var(--shadow-lg)',
              padding: '6px',
              zIndex: 200,
            }}>
              <Link
                to="/profile"
                className="dropdown-item-dark"
                onClick={() => { setUserMenuOpen(false); onMobileClose?.(); }}
              >
                <FaUser size={12} /> My Profile
              </Link>
              <Link
                to="/profile"
                className="dropdown-item-dark"
                onClick={() => { setUserMenuOpen(false); onMobileClose?.(); }}
              >
                <FaCog size={12} /> Settings
              </Link>
              <div style={{ borderTop: '1px solid var(--border)', margin: '4px 0' }} />
              <button
                className="dropdown-item-dark danger"
                onClick={handleLogout}
              >
                <FaSignOutAlt size={12} /> Sign Out
              </button>
            </div>
          )}

          <div
            className="sidebar-user-card"
            onClick={() => setUserMenuOpen(!userMenuOpen)}
          >
            <img src={avatarSrc} alt={displayName} className="sidebar-avatar" />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="sidebar-user-name">{displayName}</div>
              <div className="sidebar-user-role">{role}</div>
            </div>
            <FaChevronDown
              size={10}
              style={{
                color: 'var(--text-muted)',
                transform: userMenuOpen ? 'rotate(180deg)' : 'rotate(0)',
                transition: 'transform 0.2s ease',
                flexShrink: 0,
              }}
            />
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
