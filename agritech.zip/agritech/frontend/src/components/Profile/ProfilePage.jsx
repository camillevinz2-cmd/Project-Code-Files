import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  FaUser, FaEnvelope, FaPhone, FaMapMarkerAlt, FaCamera,
  FaTractor, FaSeedling, FaChartLine, FaEdit, FaSave,
  FaTimes, FaLeaf, FaCalendarAlt, FaCheckCircle, FaUpload
} from 'react-icons/fa';
import { toast } from 'react-toastify';
import axios from 'axios';
import AppLayout from '../Layout/AppLayout';
import { useAuth } from '../../context/AuthContext';

const ProfilePage = () => {
  const navigate = useNavigate();
  const { user: authUser, logout, refreshUser } = useAuth();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [activeTab, setActiveTab] = useState('personal');
  const [stats, setStats] = useState({ totalFarms: 0, totalCrops: 0, activeCrops: 0 });
  const [formData, setFormData] = useState({
    name: '', email: '', phone: '',
    location: { city: '', state: '', pincode: '' },
    farmExperience: '', bio: '', profilePicture: '',
  });

  const getAuthHeaders = () => ({
    headers: { Authorization: `Bearer ${localStorage.getItem('token')}`, 'Content-Type': 'application/json' }
  });

  useEffect(() => { fetchUserProfile(); fetchUserStats(); }, []);

  const fetchUserProfile = async () => {
    setLoading(true);
    try {
      const res = await axios.get('http://localhost:5000/api/auth/profile', getAuthHeaders());
      setUser(res.data);
      setFormData({
        name: res.data.name || '', email: res.data.email || '', phone: res.data.phone || '',
        location: res.data.location || { city: '', state: '', pincode: '' },
        farmExperience: res.data.farmExperience || '', bio: res.data.bio || '',
        profilePicture: res.data.profilePicture || '',
      });
    } catch (error) {
      if (error.response?.status === 401) { toast.error('Session expired.'); logout(); navigate('/login'); }
      else toast.error('Failed to load profile');
    } finally { setLoading(false); }
  };

  const fetchUserStats = async () => {
    try {
      const config = { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } };
      const [farmsRes, cropsRes] = await Promise.all([
        axios.get('http://localhost:5000/api/farms', config),
        axios.get('http://localhost:5000/api/crops', config),
      ]);
      const crops = cropsRes.data || [];
      setStats({
        totalFarms: farmsRes.data?.length || 0,
        totalCrops: crops.length,
        activeCrops: crops.filter(c => c.growthStage !== 'harvesting' && c.growthStage !== 'fallow').length,
      });
    } catch {}
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData(prev => ({ ...prev, [parent]: { ...prev[parent], [child]: value } }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await axios.put('http://localhost:5000/api/auth/profile',
        { name: formData.name, phone: formData.phone, location: formData.location, farmExperience: formData.farmExperience, bio: formData.bio },
        getAuthHeaders()
      );
      setUser(res.data);
      await refreshUser();
      toast.success('Profile updated!');
      setEditing(false);
    } catch (error) { toast.error(error.response?.data?.message || 'Failed to update profile'); }
    finally { setSaving(false); }
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { toast.error('Please select an image file'); return; }
    if (file.size > 5 * 1024 * 1024) { toast.error('Image must be under 5MB'); return; }
    setUploadingImage(true);
    const uploadFormData = new FormData();
    uploadFormData.append('image', file);
    try {
      const uploadRes = await axios.post('http://localhost:5000/api/upload/single', uploadFormData, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}`, 'Content-Type': 'multipart/form-data' }
      });
      if (uploadRes.data.success) {
        const updateRes = await axios.put('http://localhost:5000/api/auth/profile', { profilePicture: uploadRes.data.url }, getAuthHeaders());
        setUser(updateRes.data);
        setFormData(prev => ({ ...prev, profilePicture: uploadRes.data.url }));
        await refreshUser();
        toast.success('Profile picture updated!');
      }
    } catch { toast.error('Failed to upload image'); }
    finally { setUploadingImage(false); }
  };

  const getProfileImageUrl = () => {
    const pic = formData.profilePicture || user?.profilePicture;
    if (pic?.startsWith('/uploads/')) return `http://localhost:5000${pic}`;
    return `https://ui-avatars.com/api/?name=${encodeURIComponent(user?.name || 'U')}&background=16a34a&color=ffffff&size=150`;
  };

  const profileCompletion = Math.min(100,
    (formData.name ? 30 : 0) + (formData.phone ? 20 : 0) +
    (formData.location?.city ? 20 : 0) + (formData.farmExperience ? 15 : 0) + (formData.bio ? 15 : 0)
  );

  const TABS = [
    { key: 'personal', label: 'Personal Info' },
    { key: 'location', label: 'Location' },
    { key: 'farming', label: 'Farming Experience' },
  ];

  if (loading) {
    return (
      <AppLayout title="My Profile">
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '50vh', gap: 16 }}>
          <div className="spinner-amber" />
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Loading profile...</p>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout title="My Profile" subtitle="Manage your account information">
      <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr', gap: 20, alignItems: 'start' }}>
        {/* Left sidebar */}
        <div>
          {/* Avatar card */}
          <div className="card-dark" style={{ padding: 24, textAlign: 'center', marginBottom: 16 }}>
            <div style={{ position: 'relative', display: 'inline-block', marginBottom: 16 }}>
              <img
                src={getProfileImageUrl()}
                alt={user?.name}
                style={{ width: 100, height: 100, borderRadius: '50%', objectFit: 'cover', border: '3px solid var(--amber-dim)' }}
              />
              <label htmlFor="profile-image-upload" style={{
                position: 'absolute', bottom: 0, right: 0,
                width: 30, height: 30,
                background: 'var(--green)',
                borderRadius: '50%',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                cursor: 'pointer',
                border: '2px solid var(--bg-surface)',
                boxShadow: '0 2px 8px var(--green-glow)',
              }}>
                {uploadingImage ? (
                  <div style={{ width: 12, height: 12, border: '2px solid rgba(255,255,255,0.3)', borderTopColor: '#fff', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
                ) : (
                  <FaCamera style={{ color: '#fff', fontSize: 11 }} />
                )}
              </label>
              <input id="profile-image-upload" type="file" accept="image/*" onChange={handleImageUpload} style={{ display: 'none' }} />
            </div>

            <div style={{ fontWeight: 700, fontSize: '1rem', color: 'var(--text-primary)', marginBottom: 4 }}>{user?.name}</div>
            <div style={{ marginBottom: 12 }}>
              <span className={user?.role === 'admin' ? 'badge-rose' : user?.role === 'expert' ? 'badge-sky' : 'badge-emerald'} style={{ textTransform: 'capitalize' }}>
                {user?.role === 'farmer' ? '🌾' : user?.role === 'expert' ? '👨‍🌾' : '👑'} {user?.role}
              </span>
            </div>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, marginBottom: 6 }}>
              <FaEnvelope size={11} /> {user?.email}
            </div>
            {user?.phone && (
              <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                <FaPhone size={11} /> {user.phone}
              </div>
            )}
          </div>

          {/* Stats */}
          <div className="card-dark" style={{ padding: 20, marginBottom: 16 }}>
            <div style={{ fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 12, display: 'flex', alignItems: 'center', gap: 6 }}>
              <FaChartLine style={{ color: 'var(--green)', fontSize: 12 }} /> Farm Statistics
            </div>
            {[
              { label: 'Total Farms', value: stats.totalFarms, icon: FaTractor, color: 'var(--green)' },
              { label: 'Total Crops', value: stats.totalCrops, icon: FaSeedling, color: 'var(--emerald)' },
              { label: 'Active Crops', value: stats.activeCrops, icon: FaLeaf, color: 'var(--sky)' },
            ].map((item, i) => {
              const Icon = item.icon;
              return (
                <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: i < 2 ? '1px solid var(--border)' : 'none' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <Icon style={{ color: item.color, fontSize: 12 }} />
                    <span style={{ fontSize: '0.82rem', color: 'var(--text-secondary)' }}>{item.label}</span>
                  </div>
                  <span style={{ fontWeight: 700, color: 'var(--text-primary)', fontSize: '0.9rem' }}>{item.value}</span>
                </div>
              );
            })}
          </div>

          {/* Profile completion */}
          <div className="card-dark" style={{ padding: 20 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
              <span style={{ fontSize: '0.78rem', color: 'var(--text-secondary)' }}>Profile Completion</span>
              <span style={{ fontSize: '0.78rem', fontWeight: 600, color: 'var(--green)' }}>{profileCompletion}%</span>
            </div>
            <div className="progress-dark">
              <div className="progress-fill" style={{ width: `${profileCompletion}%` }} />
            </div>
            {user?.createdAt && (
              <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: 12, display: 'flex', alignItems: 'center', gap: 5 }}>
                <FaCalendarAlt size={10} /> Member since {new Date(user.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long' })}
              </div>
            )}
          </div>
        </div>

        {/* Right content */}
        <div className="card-dark">
          {/* Tabs */}
          <div style={{ display: 'flex', borderBottom: '1px solid var(--border)', padding: '0 20px' }}>
            {TABS.map(tab => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                style={{
                  padding: '14px 16px',
                  border: 'none',
                  background: 'transparent',
                  cursor: 'pointer',
                  fontSize: '0.85rem',
                  fontWeight: activeTab === tab.key ? 600 : 400,
                  color: activeTab === tab.key ? 'var(--green)' : 'var(--text-muted)',
                  borderBottom: activeTab === tab.key ? '2px solid var(--green)' : '2px solid transparent',
                  transition: 'all 0.15s ease',
                  marginBottom: -1,
                }}
              >
                {tab.label}
              </button>
            ))}
            <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 8, padding: '8px 0' }}>
              {!editing ? (
                <button className="btn-ghost" style={{ padding: '6px 14px', fontSize: '0.8rem' }} onClick={() => setEditing(true)}>
                  <FaEdit size={11} /> Edit Profile
                </button>
              ) : (
                <>
                  <button className="btn-ghost" style={{ padding: '6px 14px', fontSize: '0.8rem' }} onClick={() => setEditing(false)}>
                    <FaTimes size={11} /> Cancel
                  </button>
                  <button className="btn-amber" style={{ padding: '6px 14px', fontSize: '0.8rem' }} onClick={handleSubmit} disabled={saving}>
                    <FaSave size={11} /> {saving ? 'Saving...' : 'Save'}
                  </button>
                </>
              )}
            </div>
          </div>

          <div style={{ padding: 24 }}>
            {/* Personal Info Tab */}
            {activeTab === 'personal' && (
              <form onSubmit={handleSubmit}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                  <div className="form-group">
                    <label className="label-dark">Full Name</label>
                    <input type="text" name="name" value={formData.name} onChange={handleChange} disabled={!editing} placeholder="Your full name" className="input-dark" style={{ opacity: !editing ? 0.6 : 1 }} />
                  </div>
                  <div className="form-group">
                    <label className="label-dark">Email Address</label>
                    <input type="email" value={formData.email} disabled readOnly className="input-dark" style={{ opacity: 0.5 }} />
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: 4 }}>Email cannot be changed</div>
                  </div>
                </div>
                <div className="form-group">
                  <label className="label-dark">Phone Number</label>
                  <input type="tel" name="phone" value={formData.phone} onChange={handleChange} disabled={!editing} placeholder="09XXXXXXXXX" className="input-dark" style={{ opacity: !editing ? 0.6 : 1 }} />
                </div>
                <div className="form-group">
                  <label className="label-dark">Bio / About</label>
                  <textarea rows={4} name="bio" value={formData.bio} onChange={handleChange} disabled={!editing} placeholder="Tell us about your farming journey..." className="input-dark" style={{ resize: 'vertical', opacity: !editing ? 0.6 : 1 }} />
                </div>
              </form>
            )}

            {/* Location Tab */}
            {activeTab === 'location' && (
              <form onSubmit={handleSubmit}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                  <div className="form-group">
                    <label className="label-dark">City</label>
                    <input type="text" name="location.city" value={formData.location.city} onChange={handleChange} disabled={!editing} placeholder="Your city" className="input-dark" style={{ opacity: !editing ? 0.6 : 1 }} />
                  </div>
                  <div className="form-group">
                    <label className="label-dark">State</label>
                    <input type="text" name="location.state" value={formData.location.state} onChange={handleChange} disabled={!editing} placeholder="Your state" className="input-dark" style={{ opacity: !editing ? 0.6 : 1 }} />
                  </div>
                </div>
                <div className="form-group">
                  <label className="label-dark">Pincode</label>
                  <input type="text" name="location.pincode" value={formData.location.pincode} onChange={handleChange} disabled={!editing} placeholder="Postal code" className="input-dark" style={{ opacity: !editing ? 0.6 : 1, maxWidth: 200 }} />
                </div>
              </form>
            )}

            {/* Farming Experience Tab */}
            {activeTab === 'farming' && (
              <form onSubmit={handleSubmit}>
                <div className="form-group">
                  <label className="label-dark">Farming Experience Level</label>
                  <select name="farmExperience" value={formData.farmExperience} onChange={handleChange} disabled={!editing} className="input-dark" style={{ opacity: !editing ? 0.6 : 1, maxWidth: 300 }}>
                    <option value="">Select experience level</option>
                    <option value="beginner">🌱 Beginner (Less than 1 year)</option>
                    <option value="intermediate">🌿 Intermediate (1-5 years)</option>
                    <option value="expert">🌾 Expert (5+ years)</option>
                  </select>
                </div>
                {formData.farmExperience && (
                  <div className="alert-dark alert-sky" style={{ marginTop: 16 }}>
                    <FaLeaf size={13} />
                    <div>
                      <div style={{ fontWeight: 600, marginBottom: 4 }}>💡 Farming Tips for You</div>
                      <div style={{ fontSize: '0.82rem' }}>
                        {formData.farmExperience === 'beginner' && 'Start with easy-to-grow crops like tomatoes, eggplant, and okra. Join our community forum for daily tips!'}
                        {formData.farmExperience === 'intermediate' && 'Great! Consider diversifying your crops and exploring organic farming methods.'}
                        {formData.farmExperience === 'expert' && 'Share your wisdom in our community forum and help fellow farmers!'}
                      </div>
                    </div>
                  </div>
                )}
              </form>
            )}
          </div>
        </div>
      </div>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </AppLayout>
  );
};

export default ProfilePage;
