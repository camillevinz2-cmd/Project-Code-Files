import React, { useState, useEffect } from 'react';
import {
  WiDaySunny, WiCloudy, WiRain, WiSnow, WiThunderstorm,
  WiFog, WiHumidity, WiStrongWind, WiBarometer
} from 'react-icons/wi';
import { FaSearch, FaLocationArrow, FaLeaf, FaExclamationTriangle, FaCity } from 'react-icons/fa';
import { getCurrentWeather, getWeatherByCity, getWeatherForecast } from '../../services/weatherService';
import { toast } from 'react-toastify';

const WeatherWidget = () => {
  const [weather, setWeather] = useState(null);
  const [forecast, setForecast] = useState(null);
  const [loading, setLoading] = useState(false);
  const [city, setCity] = useState('');
  const [error, setError] = useState(null);
  const [recommendations, setRecommendations] = useState([]);
  const [locationPermission, setLocationPermission] = useState(null);
  const defaultCity = 'Manila';

  useEffect(() => { checkLocationPermissionAndGetWeather(); }, []);

  const checkLocationPermissionAndGetWeather = async () => {
    if (!navigator.geolocation) {
      setLocationPermission('denied');
      await fetchWeatherByCity(defaultCity);
      return;
    }
    navigator.permissions.query({ name: 'geolocation' }).then((result) => {
      if (result.state === 'granted') { setLocationPermission('granted'); getUserLocation(); }
      else if (result.state === 'prompt') { setLocationPermission('prompt'); getUserLocation(); }
      else { setLocationPermission('denied'); fetchWeatherByCity(defaultCity); }
    }).catch(() => { getUserLocation(); });
  };

  const getUserLocation = () => {
    setLoading(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => { await fetchWeather(pos.coords.latitude, pos.coords.longitude); setLocationPermission('granted'); setLoading(false); },
      (err) => { setLocationPermission('denied'); setLoading(false); fetchWeatherByCity(defaultCity); },
      { timeout: 10000, enableHighAccuracy: false }
    );
  };

  const fetchWeather = async (lat, lon) => {
    setLoading(true);
    try {
      const [weatherData, forecastData] = await Promise.all([getCurrentWeather(lat, lon), getWeatherForecast(lat, lon)]);
      setWeather(weatherData);
      setForecast(forecastData.list?.slice(0, 5) || []);
      setRecommendations(weatherData.agriculturalRecommendations || []);
      setError(null);
    } catch { setError('Failed to fetch weather data.'); }
    finally { setLoading(false); }
  };

  const fetchWeatherByCity = async (cityName) => {
    if (!cityName?.trim()) return;
    setLoading(true);
    try {
      const weatherData = await getWeatherByCity(cityName);
      setWeather(weatherData);
      const forecastData = await getWeatherForecast(weatherData.coord.lat, weatherData.coord.lon);
      setForecast(forecastData.list?.slice(0, 5) || []);
      setRecommendations(weatherData.agriculturalRecommendations || []);
      setError(null);
    } catch { setError(`City "${cityName}" not found.`); toast.error('City not found'); }
    finally { setLoading(false); }
  };

  const handleCitySearch = async (e) => {
    e.preventDefault();
    if (!city.trim()) { toast.error('Please enter a city name'); return; }
    await fetchWeatherByCity(city);
    setCity('');
  };

  const getWeatherIcon = (condition, size = 48) => {
    const main = condition?.toLowerCase() || '';
    if (main.includes('clear'))   return <WiDaySunny   size={size} style={{ color: '#d97706' }} />;
    if (main.includes('cloud'))   return <WiCloudy     size={size} style={{ color: '#6b8f78' }} />;
    if (main.includes('rain'))    return <WiRain       size={size} style={{ color: '#0284c7' }} />;
    if (main.includes('snow'))    return <WiSnow       size={size} style={{ color: '#7c3aed' }} />;
    if (main.includes('thunder')) return <WiThunderstorm size={size} style={{ color: '#dc2626' }} />;
    if (main.includes('fog'))     return <WiFog        size={size} style={{ color: '#6b8f78' }} />;
    return <WiDaySunny size={size} style={{ color: '#d97706' }} />;
  };

  const getRecColor = (type) => ({
    warning: 'var(--sky-dim)', alert: 'var(--rose-dim)',
  }[type] || 'var(--green-dim)');

  const getRecTextColor = (type) => ({
    warning: 'var(--sky)', alert: 'var(--rose)',
  }[type] || 'var(--green)');

  if (loading && !weather) {
    return (
      <div className="card-dark" style={{ padding: 24, textAlign: 'center' }}>
        <div className="spinner-amber" style={{ margin: '0 auto 12px' }} />
        <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', margin: 0 }}>Loading weather data...</p>
      </div>
    );
  }

  return (
    <div className="card-dark" style={{ padding: 20 }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ width: 28, height: 28, background: 'var(--sky-dim)', borderRadius: 7, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <FaLeaf style={{ color: 'var(--sky)', fontSize: 12 }} />
          </div>
          <span style={{ fontSize: '0.875rem', fontWeight: 600, color: 'var(--text-primary)' }}>Weather & Farming Insights</span>
        </div>
        {locationPermission === 'denied' && (
          <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: 4 }}>
            <FaExclamationTriangle style={{ color: 'var(--rose)', fontSize: 10 }} /> Location disabled
          </span>
        )}
      </div>

      {/* Search */}
      <form onSubmit={handleCitySearch} style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        <div style={{ position: 'relative', flex: 1 }}>
          <FaSearch style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)', fontSize: 12 }} />
          <input
            type="text"
            placeholder="Search city..."
            value={city}
            onChange={(e) => setCity(e.target.value)}
            className="input-dark"
            style={{ paddingLeft: 36 }}
          />
        </div>
        <button type="submit" className="btn-amber" style={{ padding: '9px 16px', fontSize: '0.82rem' }}>Search</button>
        <button
          type="button"
          className="btn-ghost"
          onClick={() => locationPermission !== 'denied' ? getUserLocation() : toast.info('Enable location in browser settings')}
          style={{ padding: '9px 12px' }}
          title="Use current location"
        >
          <FaLocationArrow size={13} />
        </button>
      </form>

      {error && (
        <div className="alert-dark alert-amber" style={{ marginBottom: 16 }}>
          <FaExclamationTriangle size={12} />
          <span style={{ fontSize: '0.82rem' }}>{error}</span>
        </div>
      )}

      {weather ? (
        <div>
          {/* Main weather */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 16, alignItems: 'center', marginBottom: 16 }}>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                <FaCity style={{ color: 'var(--rose)', fontSize: 11 }} />
                <span style={{ fontSize: '1.1rem', fontWeight: 700, color: 'var(--text-primary)' }}>{weather.name}</span>
                <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{weather.sys?.country}</span>
              </div>
              <div style={{ fontSize: '2.8rem', fontWeight: 800, color: 'var(--green)', lineHeight: 1 }}>
                {Math.round(weather.main?.temp)}°C
              </div>
              <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', textTransform: 'capitalize', marginTop: 4 }}>
                {weather.weather?.[0]?.description}
              </div>
            </div>
            {getWeatherIcon(weather.weather?.[0]?.main, 64)}
          </div>

          {/* Stats */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 16 }}>
            {[
              { icon: WiHumidity, value: `${weather.main?.humidity}%`, label: 'Humidity', color: 'var(--sky)' },
              { icon: WiStrongWind, value: `${Math.round(weather.wind?.speed)} m/s`, label: 'Wind', color: 'var(--violet)' },
              { icon: WiBarometer, value: `${weather.main?.pressure}`, label: 'Pressure hPa', color: 'var(--green)' },
            ].map((item, i) => {
              const Icon = item.icon;
              return (
                <div key={i} style={{ background: 'var(--bg-elevated)', borderRadius: 10, padding: '10px', textAlign: 'center', border: '1px solid var(--border)' }}>
                  <Icon size={24} style={{ color: item.color }} />
                  <div style={{ fontWeight: 700, fontSize: '0.9rem', color: 'var(--text-primary)' }}>{item.value}</div>
                  <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>{item.label}</div>
                </div>
              );
            })}
          </div>

          {/* Recommendations */}
          {recommendations.length > 0 && (
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 8, display: 'flex', alignItems: 'center', gap: 6 }}>
                <FaLeaf style={{ color: 'var(--emerald)', fontSize: 11 }} /> Agricultural Recommendations
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {recommendations.map((rec, idx) => (
                  <div key={idx} style={{ background: getRecColor(rec.type), borderRadius: 8, padding: '8px 12px' }}>
                    <div style={{ fontSize: '0.78rem', fontWeight: 600, color: getRecTextColor(rec.type) }}>{rec.message}</div>
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: 2 }}>{rec.action}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Forecast */}
          {forecast?.length > 0 && (
            <div>
              <div style={{ fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 8 }}>5-Day Forecast</div>
              <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 4 }}>
                {forecast.map((item, idx) => (
                  <div key={idx} style={{
                    textAlign: 'center', padding: '10px 12px',
                    background: 'var(--bg-elevated)', borderRadius: 10,
                    minWidth: 68, flexShrink: 0,
                    border: '1px solid var(--border)',
                  }}>
                    <div style={{ fontSize: '0.7rem', fontWeight: 600, color: 'var(--text-muted)', marginBottom: 4 }}>
                      {new Date(item.dt * 1000).toLocaleDateString('en-US', { weekday: 'short' })}
                    </div>
                    {getWeatherIcon(item.weather?.[0]?.main, 28)}
                    <div style={{ fontWeight: 700, fontSize: '0.85rem', color: 'var(--text-primary)', marginTop: 4 }}>
                      {Math.round(item.main?.temp_max)}°
                    </div>
                    <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
                      {Math.round(item.main?.temp_min)}°
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        <div style={{ textAlign: 'center', padding: '32px 0' }}>
          <FaCity style={{ color: 'var(--text-muted)', fontSize: 40, marginBottom: 12 }} />
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', margin: 0 }}>Search for a city to see weather</p>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.78rem', marginTop: 4 }}>Try: Manila, New York, London</p>
        </div>
      )}
    </div>
  );
};

export default WeatherWidget;
