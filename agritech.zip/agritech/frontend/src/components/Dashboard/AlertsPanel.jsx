import React, { useState, useEffect } from 'react';
import { FaBell, FaBug, FaTint, FaCalendarAlt, FaCheckCircle } from 'react-icons/fa';
import { getUserCrops } from '../../services/cropService';

const AlertsPanel = () => {
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAlerts = async () => {
      try {
        const crops = await getUserCrops();
        const allAlerts = crops.flatMap(crop =>
          (crop.alerts || []).map(alert => ({ ...alert, cropName: crop.name }))
        );
        setAlerts(allAlerts.slice(0, 5));
      } catch {}
      finally { setLoading(false); }
    };
    fetchAlerts();
  }, []);

  const getAlertIcon = (type) => {
    if (type === 'pest') return <FaBug style={{ color: 'var(--rose)', fontSize: 12 }} />;
    if (type === 'water') return <FaTint style={{ color: 'var(--sky)', fontSize: 12 }} />;
    return <FaCalendarAlt style={{ color: 'var(--green)', fontSize: 12 }} />;
  };

  return (
    <div className="card-dark" style={{ padding: 20 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
        <div style={{ width: 28, height: 28, background: 'var(--rose-dim)', borderRadius: 7, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <FaBell style={{ color: 'var(--rose)', fontSize: 12 }} />
        </div>
        <span style={{ fontSize: '0.875rem', fontWeight: 600, color: 'var(--text-primary)' }}>Alerts</span>
        {alerts.length > 0 && (
          <span className="badge-rose" style={{ marginLeft: 'auto' }}>{alerts.length}</span>
        )}
      </div>

      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', padding: '20px 0' }}>
          <div className="spinner-amber" style={{ width: 24, height: 24, borderWidth: 2 }} />
        </div>
      ) : alerts.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '20px 0' }}>
          <FaCheckCircle style={{ color: 'var(--emerald)', fontSize: 28, marginBottom: 8 }} />
          <p style={{ color: 'var(--text-muted)', fontSize: '0.8rem', margin: 0 }}>No active alerts</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {alerts.map((alert, idx) => (
            <div key={idx} style={{
              display: 'flex', alignItems: 'flex-start', gap: 10,
              padding: '10px 12px',
              background: 'var(--bg-elevated)',
              borderRadius: 8,
              borderLeft: '3px solid var(--rose)',
            }}>
              {getAlertIcon(alert.type)}
              <div>
                <div style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--text-primary)' }}>{alert.cropName}</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{alert.message || alert.type}</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AlertsPanel;
