import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FaSeedling, FaExclamationTriangle, FaCheckCircle, FaArrowRight } from 'react-icons/fa';
import { getUserCrops } from '../../services/cropService';

const STAGES = ['planting', 'germination', 'vegetative', 'flowering', 'fruiting', 'maturing', 'harvesting'];

const CropStatusCard = () => {
  const [crops, setCrops] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCrops = async () => {
      try {
        const data = await getUserCrops();
        setCrops(data.slice(0, 4));
      } catch {}
      finally { setLoading(false); }
    };
    fetchCrops();
  }, []);

  const getProgress = (stage) => ((STAGES.indexOf(stage) + 1) / STAGES.length) * 100;

  const getHealthClass = (h) => ({
    excellent: 'badge-emerald', good: 'badge-emerald',
    fair: 'badge-amber', poor: 'badge-rose', critical: 'badge-rose',
  }[h] || 'badge-muted');

  return (
    <div className="card-dark" style={{ padding: 20 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ width: 28, height: 28, background: 'var(--emerald-dim)', borderRadius: 7, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <FaSeedling style={{ color: 'var(--emerald)', fontSize: 12 }} />
          </div>
          <span style={{ fontSize: '0.875rem', fontWeight: 600, color: 'var(--text-primary)' }}>Crop Status</span>
        </div>
        <Link to="/crops" style={{ fontSize: '0.75rem', color: 'var(--green)', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 4 }}>
          View All <FaArrowRight size={10} />
        </Link>
      </div>

      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', padding: '20px 0' }}>
          <div className="spinner-amber" style={{ width: 24, height: 24, borderWidth: 2 }} />
        </div>
      ) : crops.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '20px 0' }}>
          <FaSeedling style={{ color: 'var(--text-muted)', fontSize: 28, marginBottom: 8 }} />
          <p style={{ color: 'var(--text-muted)', fontSize: '0.8rem', margin: 0 }}>No crops yet</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {crops.map(crop => (
            <div key={crop._id} style={{ padding: '12px', background: 'var(--bg-elevated)', borderRadius: 8 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                <span style={{ fontWeight: 600, fontSize: '0.85rem', color: 'var(--text-primary)' }}>{crop.name}</span>
                <span className={getHealthClass(crop.health)}>{crop.health}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
                <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'capitalize' }}>{crop.growthStage}</span>
                <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{Math.round(getProgress(crop.growthStage))}%</span>
              </div>
              <div className="progress-dark">
                <div className="progress-fill progress-fill-emerald" style={{ width: `${getProgress(crop.growthStage)}%` }} />
              </div>
              {crop.alerts?.length > 0 && (
                <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 6 }}>
                  <FaExclamationTriangle style={{ color: 'var(--rose)', fontSize: 10 }} />
                  <span style={{ fontSize: '0.72rem', color: 'var(--rose)' }}>{crop.alerts.length} alert(s)</span>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default CropStatusCard;
