import React, { useState, useRef } from 'react';
import { FaUpload, FaTrash } from 'react-icons/fa';
import axios from 'axios';
import { toast } from 'react-toastify';

const ImageUpload = ({ images = [], onImagesChange, maxImages = 5 }) => {
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  const handleUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    if (images.length + files.length > maxImages) {
      toast.error(`Maximum ${maxImages} images allowed`);
      return;
    }
    setUploading(true);
    try {
      const uploadedUrls = [];
      for (const file of files) {
        if (!file.type.startsWith('image/')) { toast.error(`${file.name} is not an image`); continue; }
        if (file.size > 5 * 1024 * 1024) { toast.error(`${file.name} exceeds 5MB`); continue; }
        const formData = new FormData();
        formData.append('image', file);
        const res = await axios.post('http://localhost:5000/api/upload/single', formData, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}`, 'Content-Type': 'multipart/form-data' },
        });
        if (res.data.success) uploadedUrls.push(res.data.url);
      }
      if (uploadedUrls.length) {
        onImagesChange([...images, ...uploadedUrls]);
        toast.success(`${uploadedUrls.length} image(s) uploaded`);
      }
    } catch { toast.error('Upload failed'); }
    finally { setUploading(false); if (fileInputRef.current) fileInputRef.current.value = ''; }
  };

  const handleRemove = async (url, idx) => {
    try {
      const filename = url.split('/uploads/')[1];
      if (filename) await axios.delete(`http://localhost:5000/api/upload/${filename}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
      });
    } catch {}
    onImagesChange(images.filter((_, i) => i !== idx));
  };

  return (
    <div>
      {/* Upload area */}
      <div
        onClick={() => !uploading && fileInputRef.current?.click()}
        style={{
          border: '2px dashed var(--border-strong)',
          borderRadius: 10, padding: 20, textAlign: 'center',
          cursor: uploading ? 'not-allowed' : 'pointer',
          background: 'var(--bg-elevated)',
          transition: 'border-color 0.2s ease, background 0.2s ease',
          marginBottom: 12,
        }}
        onMouseEnter={e => { if (!uploading) { e.currentTarget.style.borderColor = 'var(--green)'; e.currentTarget.style.background = 'var(--green-dim)'; } }}
        onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border-strong)'; e.currentTarget.style.background = 'var(--bg-elevated)'; }}
      >
        {uploading ? (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
            <div style={{ width: 16, height: 16, border: '2px solid var(--green-dim)', borderTopColor: 'var(--green)', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
            <span style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Uploading...</span>
          </div>
        ) : (
          <>
            <FaUpload style={{ color: 'var(--green)', fontSize: 22, marginBottom: 8 }} />
            <div style={{ fontWeight: 600, color: 'var(--text-secondary)', fontSize: '0.875rem' }}>
              Click to upload {images.length > 0 ? 'more ' : ''}images
            </div>
            <div style={{ color: 'var(--text-muted)', fontSize: '0.75rem', marginTop: 4 }}>
              JPG, PNG, WebP · max 5MB · {images.length}/{maxImages} uploaded
            </div>
          </>
        )}
      </div>
      <input ref={fileInputRef} type="file" accept="image/*" multiple onChange={handleUpload} style={{ display: 'none' }} />

      {/* Preview grid */}
      {images.length > 0 && (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
          {images.map((url, idx) => (
            <div key={idx} style={{ position: 'relative', width: 80, height: 80, borderRadius: 8, overflow: 'hidden', border: '1px solid var(--border)', flexShrink: 0 }}>
              <img
                src={url.startsWith('/uploads/') ? `http://localhost:5000${url}` : url}
                alt={`upload-${idx}`}
                style={{ width: '100%', height: '100%', objectFit: 'cover' }}
              />
              <button
                type="button"
                onClick={() => handleRemove(url, idx)}
                style={{ position: 'absolute', top: 3, right: 3, background: 'var(--rose)', border: 'none', borderRadius: '50%', width: 18, height: 18, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: 'white', padding: 0 }}
              >
                <FaTrash size={8} />
              </button>
              {idx === 0 && (
                <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, background: 'rgba(22,163,74,0.85)', color: '#fff', fontSize: '0.6rem', textAlign: 'center', padding: '2px 0', fontWeight: 700 }}>
                  MAIN
                </div>
              )}
            </div>
          ))}
        </div>
      )}
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
};

export default ImageUpload;
