import React from 'react';

const LoadingSpinner = ({ text = 'Loading...' }) => (
  <div style={{
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '50vh',
    gap: 16,
  }}>
    <div className="spinner-amber" />
    <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', margin: 0 }}>{text}</p>
  </div>
);

export default LoadingSpinner;
