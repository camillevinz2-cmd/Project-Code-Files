import React from 'react';
import { FaExclamationTriangle, FaTimes } from 'react-icons/fa';

const ErrorMessage = ({ message, onDismiss }) => {
  if (!message) return null;
  return (
    <div className="alert-dark alert-rose" style={{ marginBottom: 16 }}>
      <FaExclamationTriangle size={13} style={{ flexShrink: 0 }} />
      <span style={{ flex: 1 }}>{message}</span>
      {onDismiss && (
        <button
          onClick={onDismiss}
          style={{
            background: 'none', border: 'none', cursor: 'pointer',
            color: 'var(--rose)', padding: 0, flexShrink: 0,
          }}
        >
          <FaTimes size={12} />
        </button>
      )}
    </div>
  );
};

export default ErrorMessage;
