import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  FaLeaf, FaChartLine, FaComments, FaCloudSun, FaTractor,
  FaShieldAlt, FaSeedling, FaUsers, FaArrowRight, FaCheckCircle,
  FaStar, FaUserGraduate, FaPlay, FaBars, FaTimes, FaQuoteLeft
} from 'react-icons/fa';

const NAV_LINKS = ['Features', 'How It Works', 'Testimonials'];

const FEATURES = [
  { icon: FaTractor,   title: 'Farm Management',  desc: 'Centralize all your farm data — fields, crops, resources — in one powerful dashboard.',  color: 'var(--green)',   bg: 'var(--green-dim)',   num: '01' },
  { icon: FaCloudSun,  title: 'Weather Insights', desc: 'Hyper-local forecasts with AI-powered planting and harvesting recommendations.',           color: 'var(--sky)',     bg: 'var(--sky-dim)',     num: '02' },
  { icon: FaChartLine, title: 'Smart Analytics',  desc: 'Interactive yield charts, health trends, and exportable reports for smarter decisions.',   color: 'var(--emerald)', bg: 'var(--emerald-dim)', num: '03' },
  { icon: FaComments,  title: 'Expert Community', desc: 'Post questions, share knowledge, and get answers from certified agricultural experts.',    color: 'var(--violet)',  bg: 'var(--violet-dim)',  num: '04' },
  { icon: FaSeedling,  title: 'Crop Tracking',    desc: 'Monitor growth stages, log issues, and get alerts before problems escalate.',             color: 'var(--teal)',    bg: 'var(--teal-dim)',    num: '05' },
  { icon: FaShieldAlt, title: 'Secure Access',    desc: 'Role-based permissions keep your data private and your team organized.',                  color: 'var(--violet)',  bg: 'var(--violet-dim)',  num: '06' },
];

const STEPS = [
  { step: '1', title: 'Create your account', desc: 'Sign up free in under 2 minutes. No credit card needed.' },
  { step: '2', title: 'Add your farms & crops', desc: 'Register your fields, set crop types, and configure your profile.' },
  { step: '3', title: 'Track & grow smarter', desc: 'Monitor everything in real-time and act on data-driven insights.' },
];

const TESTIMONIALS = [
  { name: 'Maria Santos', role: 'Rice Farmer, Bulacan', text: 'AgriTech cut my fertilizer costs by 25%. The crop health alerts alone paid for itself in the first season.', rating: 5 },
  { name: 'Jose Reyes', role: 'Vegetable Grower, Benguet', text: 'The weather integration is incredible. I haven\'t lost a harvest to unexpected rain since I started using it.', rating: 5 },
  { name: 'Ana Cruz', role: 'Agricultural Expert', text: 'I advise over 40 farmers through the platform. The forum tools make it easy to reach everyone at once.', rating: 5 },
];

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-surface)', overflowX: 'hidden' }}>

      {/* ── NAV ── */}
      <nav style={{
        position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
        background: scrolled ? 'rgba(255,255,255,0.97)' : 'transparent',
        backdropFilter: scrolled ? 'blur(16px)' : 'none',
        borderBottom: scrolled ? '1px solid var(--border)' : 'none',
        transition: 'all 0.3s ease',
        padding: '0 5%',
        height: 68,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 38, height: 38, background: 'linear-gradient(135deg, var(--green), var(--green-dark))', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 4px 12px var(--green-glow)' }}>
            <FaLeaf style={{ color: '#fff', fontSize: 16 }} />
          </div>
          <span style={{ fontWeight: 800, fontSize: '1.15rem', color: 'var(--text-primary)', letterSpacing: '-0.3px' }}>
            Agri<span style={{ color: 'var(--green)' }}>Tech</span>
          </span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 32 }} className="nav-desktop">
          {NAV_LINKS.map(l => (
            <a key={l} href={`#${l.toLowerCase().replace(/ /g, '-')}`} style={{ fontSize: '0.875rem', fontWeight: 500, color: 'var(--text-secondary)', textDecoration: 'none', transition: 'color 0.2s' }}
              onMouseEnter={e => e.target.style.color = 'var(--green)'}
              onMouseLeave={e => e.target.style.color = 'var(--text-secondary)'}
            >{l}</a>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <Link to="/login" className="btn-ghost" style={{ padding: '8px 20px', fontSize: '0.875rem' }}>Sign In</Link>
          <Link to="/register" className="btn-amber" style={{ padding: '8px 20px', fontSize: '0.875rem' }}>Get Started</Link>
        </div>
      </nav>

      {/* ── HERO ── */}
      <section style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', position: 'relative', overflow: 'hidden', background: 'linear-gradient(160deg, #f0fdf4 0%, #dcfce7 50%, #bbf7d0 100%)' }}>
        {/* Background pattern */}
        <div style={{ position: 'absolute', inset: 0, backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(22,163,74,0.08) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(5,150,105,0.06) 0%, transparent 50%)', pointerEvents: 'none' }} />
        <div style={{ position: 'absolute', top: '10%', right: '5%', width: 400, height: 400, borderRadius: '50%', background: 'rgba(22,163,74,0.06)', border: '1px solid rgba(22,163,74,0.1)', pointerEvents: 'none' }} />
        <div style={{ position: 'absolute', bottom: '5%', left: '2%', width: 250, height: 250, borderRadius: '50%', background: 'rgba(5,150,105,0.05)', pointerEvents: 'none' }} />

        <div style={{ maxWidth: 1200, margin: '0 auto', padding: '120px 5% 80px', width: '100%', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 60, alignItems: 'center' }}>
          <div className="fade-in-up">
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: 'rgba(22,163,74,0.12)', border: '1px solid rgba(22,163,74,0.2)', borderRadius: 99, padding: '5px 14px', marginBottom: 24 }}>
              <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--green)', display: 'inline-block' }} />
              <span style={{ fontSize: '0.78rem', fontWeight: 600, color: 'var(--green-dark)' }}>Now serving 10,000+ farmers</span>
            </div>
            <h1 style={{ fontSize: 'clamp(2.4rem, 4.5vw, 3.6rem)', fontWeight: 900, lineHeight: 1.08, letterSpacing: '-1.5px', color: 'var(--text-primary)', marginBottom: 20 }}>
              Grow smarter.<br />
              <span style={{ color: 'var(--green)', position: 'relative' }}>
                Farm better.
                <svg style={{ position: 'absolute', bottom: -4, left: 0, width: '100%' }} height="6" viewBox="0 0 200 6">
                  <path d="M0 5 Q50 0 100 5 Q150 10 200 5" stroke="var(--green)" strokeWidth="2.5" fill="none" strokeLinecap="round" opacity="0.5"/>
                </svg>
              </span>
            </h1>
            <p style={{ fontSize: '1.05rem', color: 'var(--text-muted)', lineHeight: 1.75, marginBottom: 36, maxWidth: 480 }}>
              The all-in-one platform for modern farmers. Track crops, monitor weather, connect with experts, and make data-driven decisions — all in one place.
            </p>
            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 40 }}>
              <Link to="/register" className="btn-amber" style={{ padding: '13px 28px', fontSize: '0.95rem', borderRadius: 12 }}>
                Start Free Today <FaArrowRight size={13} />
              </Link>
              <Link to="/login" style={{ display: 'inline-flex', alignItems: 'center', gap: 10, padding: '13px 24px', fontSize: '0.95rem', fontWeight: 600, color: 'var(--text-secondary)', textDecoration: 'none', border: '1.5px solid var(--border-strong)', borderRadius: 12, background: 'rgba(255,255,255,0.7)', transition: 'all 0.2s' }}
                onMouseEnter={e => { e.currentTarget.style.background = '#fff'; e.currentTarget.style.borderColor = 'var(--green)'; }}
                onMouseLeave={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.7)'; e.currentTarget.style.borderColor = 'var(--border-strong)'; }}
              >
                <div style={{ width: 28, height: 28, borderRadius: '50%', background: 'var(--green-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <FaPlay style={{ color: 'var(--green)', fontSize: 9, marginLeft: 2 }} />
                </div>
                Watch Demo
              </Link>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
              <div style={{ display: 'flex' }}>
                {['🧑‍🌾','👩‍🌾','🧑‍🌾','👨‍🌾'].map((e, i) => (
                  <div key={i} style={{ width: 32, height: 32, borderRadius: '50%', background: `hsl(${130 + i * 15}, 50%, ${75 - i * 5}%)`, border: '2px solid #fff', marginLeft: i > 0 ? -10 : 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14 }}>{e}</div>
                ))}
              </div>
              <div>
                <div style={{ display: 'flex', gap: 2, marginBottom: 2 }}>
                  {[...Array(5)].map((_, i) => <span key={i} style={{ color: '#d97706', fontSize: 12 }}>★</span>)}
                </div>
                <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)', fontWeight: 500 }}>Trusted by 10,000+ farmers</span>
              </div>
            </div>
          </div>

          {/* Hero card mockup */}
          <div style={{ position: 'relative' }} className="fade-in-up">
            <div style={{ background: '#fff', borderRadius: 24, padding: 24, boxShadow: '0 32px 80px rgba(22,163,74,0.18)', border: '1px solid var(--border)' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
                <div>
                  <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>Farm Overview</div>
                  <div style={{ fontSize: '1.1rem', fontWeight: 700, color: 'var(--text-primary)' }}>Green Valley Farm</div>
                </div>
                <div style={{ background: 'var(--green-dim)', borderRadius: 10, padding: '6px 12px', fontSize: '0.78rem', fontWeight: 600, color: 'var(--green)' }}>● Live</div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 20 }}>
                {[
                  { label: 'Active Crops', value: '12', icon: '🌾', color: 'var(--green)' },
                  { label: 'Health Score', value: '94%', icon: '💚', color: 'var(--emerald)' },
                  { label: 'Yield Est.', value: '2.4t', icon: '📊', color: 'var(--sky)' },
                  { label: 'Alerts', value: '0', icon: '🔔', color: 'var(--rose)' },
                ].map((s, i) => (
                  <div key={i} style={{ background: 'var(--bg-elevated)', borderRadius: 12, padding: '14px 16px', border: '1px solid var(--border)' }}>
                    <div style={{ fontSize: 18, marginBottom: 6 }}>{s.icon}</div>
                    <div style={{ fontSize: '1.3rem', fontWeight: 800, color: s.color, lineHeight: 1 }}>{s.value}</div>
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: 3 }}>{s.label}</div>
                  </div>
                ))}
              </div>
              <div style={{ background: 'var(--bg-elevated)', borderRadius: 12, padding: '14px 16px', border: '1px solid var(--border)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                  <span style={{ fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-secondary)' }}>Rice — Vegetative Stage</span>
                  <span style={{ fontSize: '0.78rem', color: 'var(--green)', fontWeight: 600 }}>71%</span>
                </div>
                <div style={{ height: 8, background: 'var(--border)', borderRadius: 99, overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: '71%', background: 'linear-gradient(90deg, var(--green), var(--green-light))', borderRadius: 99 }} />
                </div>
              </div>
            </div>
            {/* Floating badge */}
            <div style={{ position: 'absolute', top: -16, right: -16, background: '#fff', borderRadius: 14, padding: '10px 16px', boxShadow: '0 8px 24px rgba(22,163,74,0.15)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontSize: 18 }}>🌤️</span>
              <div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Today</div>
                <div style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-primary)' }}>28°C · Clear</div>
              </div>
            </div>
            <div style={{ position: 'absolute', bottom: -16, left: -16, background: '#fff', borderRadius: 14, padding: '10px 16px', boxShadow: '0 8px 24px rgba(22,163,74,0.15)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'var(--green-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <FaCheckCircle style={{ color: 'var(--green)', fontSize: 14 }} />
              </div>
              <div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>No alerts</div>
                <div style={{ fontSize: '0.82rem', fontWeight: 700, color: 'var(--green)' }}>All crops healthy</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── STATS STRIP ── */}
      <section style={{ background: 'var(--green)', padding: '28px 5%' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 24, textAlign: 'center' }}>
          {[
            { num: '10K+', label: 'Active Farmers' },
            { num: '500+', label: 'Expert Advisors' },
            { num: '50K+', label: 'Crops Tracked' },
            { num: '98%',  label: 'Satisfaction Rate' },
          ].map((s, i) => (
            <div key={i}>
              <div style={{ fontSize: '2rem', fontWeight: 900, color: '#fff', lineHeight: 1 }}>{s.num}</div>
              <div style={{ fontSize: '0.82rem', color: 'rgba(255,255,255,0.75)', marginTop: 4, fontWeight: 500 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── FEATURES ── */}
      <section id="features" style={{ padding: '100px 5%', background: 'var(--bg-surface)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 60, alignItems: 'start' }}>
            <div style={{ position: 'sticky', top: 100 }}>
              <div style={{ display: 'inline-block', background: 'var(--green-dim)', borderRadius: 8, padding: '4px 12px', fontSize: '0.75rem', fontWeight: 700, color: 'var(--green)', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: 16 }}>Features</div>
              <h2 style={{ fontSize: 'clamp(1.8rem, 3vw, 2.6rem)', fontWeight: 800, color: 'var(--text-primary)', lineHeight: 1.15, letterSpacing: '-0.5px', marginBottom: 16 }}>
                Everything a modern farmer needs
              </h2>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.95rem', lineHeight: 1.7, marginBottom: 28 }}>
                Built from the ground up for Philippine agriculture, with tools that scale from a single plot to hundreds of hectares.
              </p>
              <Link to="/register" className="btn-amber" style={{ padding: '11px 24px', fontSize: '0.875rem', borderRadius: 10 }}>
                Try All Features Free <FaArrowRight size={12} />
              </Link>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              {FEATURES.map((f, i) => {
                const Icon = f.icon;
                return (
                  <div key={i} style={{ background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: 16, padding: '24px', transition: 'all 0.25s ease', cursor: 'default' }}
                    onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.boxShadow = '0 12px 32px rgba(22,163,74,0.12)'; e.currentTarget.style.borderColor = 'var(--border-strong)'; }}
                    onMouseLeave={e => { e.currentTarget.style.transform = 'none'; e.currentTarget.style.boxShadow = 'none'; e.currentTarget.style.borderColor = 'var(--border)'; }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
                      <div style={{ width: 44, height: 44, background: f.bg, borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', border: `1px solid ${f.color}25` }}>
                        <Icon style={{ color: f.color, fontSize: 18 }} />
                      </div>
                      <span style={{ fontSize: '0.65rem', fontWeight: 700, color: 'var(--text-muted)', letterSpacing: '1px' }}>{f.num}</span>
                    </div>
                    <h3 style={{ fontSize: '0.95rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: 8 }}>{f.title}</h3>
                    <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', lineHeight: 1.6, margin: 0 }}>{f.desc}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* ── HOW IT WORKS ── */}
      <section id="how-it-works" style={{ padding: '100px 5%', background: 'linear-gradient(180deg, #f0fdf4 0%, #fff 100%)' }}>
        <div style={{ maxWidth: 900, margin: '0 auto', textAlign: 'center' }}>
          <div style={{ display: 'inline-block', background: 'var(--green-dim)', borderRadius: 8, padding: '4px 12px', fontSize: '0.75rem', fontWeight: 700, color: 'var(--green)', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: 16 }}>How It Works</div>
          <h2 style={{ fontSize: 'clamp(1.8rem, 3vw, 2.6rem)', fontWeight: 800, color: 'var(--text-primary)', letterSpacing: '-0.5px', marginBottom: 12 }}>Up and running in minutes</h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.95rem', marginBottom: 64 }}>No complicated setup. Just sign up and start farming smarter.</p>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 32, position: 'relative' }}>
            <div style={{ position: 'absolute', top: 28, left: '16%', right: '16%', height: 2, background: 'linear-gradient(90deg, var(--green), var(--emerald))', opacity: 0.3, zIndex: 0 }} />
            {STEPS.map((s, i) => (
              <div key={i} style={{ position: 'relative', zIndex: 1 }}>
                <div style={{ width: 56, height: 56, borderRadius: '50%', background: 'linear-gradient(135deg, var(--green), var(--green-dark))', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 20px', boxShadow: '0 8px 24px var(--green-glow)', border: '4px solid #fff' }}>
                  <span style={{ fontSize: '1.1rem', fontWeight: 900, color: '#fff' }}>{s.step}</span>
                </div>
                <h3 style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: 8 }}>{s.title}</h3>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', lineHeight: 1.6 }}>{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── TESTIMONIALS ── */}
      <section id="testimonials" style={{ padding: '100px 5%', background: 'var(--bg-surface)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 56 }}>
            <div style={{ display: 'inline-block', background: 'var(--green-dim)', borderRadius: 8, padding: '4px 12px', fontSize: '0.75rem', fontWeight: 700, color: 'var(--green)', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: 16 }}>Testimonials</div>
            <h2 style={{ fontSize: 'clamp(1.8rem, 3vw, 2.6rem)', fontWeight: 800, color: 'var(--text-primary)', letterSpacing: '-0.5px' }}>Farmers love AgriTech</h2>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 24 }}>
            {TESTIMONIALS.map((t, i) => (
              <div key={i} style={{ background: i === 1 ? 'linear-gradient(135deg, var(--green), var(--green-dark))' : 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: 20, padding: '28px', transition: 'transform 0.2s' }}
                onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-4px)'}
                onMouseLeave={e => e.currentTarget.style.transform = 'none'}
              >
                <FaQuoteLeft style={{ color: i === 1 ? 'rgba(255,255,255,0.3)' : 'var(--green-dim)', fontSize: 28, marginBottom: 16 }} />
                <p style={{ fontSize: '0.9rem', lineHeight: 1.7, color: i === 1 ? 'rgba(255,255,255,0.9)' : 'var(--text-secondary)', marginBottom: 20 }}>"{t.text}"</p>
                <div style={{ display: 'flex', gap: 2, marginBottom: 14 }}>
                  {[...Array(t.rating)].map((_, j) => <span key={j} style={{ color: i === 1 ? '#fde68a' : '#d97706', fontSize: 13 }}>★</span>)}
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{ width: 38, height: 38, borderRadius: '50%', background: i === 1 ? 'rgba(255,255,255,0.2)' : 'var(--green-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>🧑‍🌾</div>
                  <div>
                    <div style={{ fontSize: '0.85rem', fontWeight: 700, color: i === 1 ? '#fff' : 'var(--text-primary)' }}>{t.name}</div>
                    <div style={{ fontSize: '0.72rem', color: i === 1 ? 'rgba(255,255,255,0.65)' : 'var(--text-muted)' }}>{t.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section style={{ padding: '80px 5%', background: 'linear-gradient(135deg, var(--green-dark) 0%, var(--green) 100%)', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', top: -60, right: -60, width: 300, height: 300, borderRadius: '50%', background: 'rgba(255,255,255,0.05)', pointerEvents: 'none' }} />
        <div style={{ position: 'absolute', bottom: -40, left: -40, width: 200, height: 200, borderRadius: '50%', background: 'rgba(255,255,255,0.04)', pointerEvents: 'none' }} />
        <div style={{ maxWidth: 700, margin: '0 auto', textAlign: 'center', position: 'relative', zIndex: 1 }}>
          <h2 style={{ fontSize: 'clamp(1.8rem, 3.5vw, 2.8rem)', fontWeight: 900, color: '#fff', letterSpacing: '-0.5px', marginBottom: 16 }}>Ready to grow smarter?</h2>
          <p style={{ color: 'rgba(255,255,255,0.8)', fontSize: '1rem', marginBottom: 36, lineHeight: 1.7 }}>Join thousands of Filipino farmers already using AgriTech to maximize their yields and reduce costs.</p>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link to="/register" style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '13px 28px', background: '#fff', color: 'var(--green-dark)', borderRadius: 12, fontWeight: 700, fontSize: '0.95rem', textDecoration: 'none', boxShadow: '0 4px 16px rgba(0,0,0,0.15)', transition: 'transform 0.2s' }}
              onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-2px)'}
              onMouseLeave={e => e.currentTarget.style.transform = 'none'}
            >
              Create Free Account <FaArrowRight size={13} />
            </Link>
            <Link to="/login" style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '13px 28px', background: 'rgba(255,255,255,0.15)', color: '#fff', borderRadius: 12, fontWeight: 600, fontSize: '0.95rem', textDecoration: 'none', border: '1.5px solid rgba(255,255,255,0.3)', transition: 'all 0.2s' }}
              onMouseEnter={e => e.currentTarget.style.background = 'rgba(255,255,255,0.25)'}
              onMouseLeave={e => e.currentTarget.style.background = 'rgba(255,255,255,0.15)'}
            >
              Sign In
            </Link>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: 20 }}>
            <FaCheckCircle style={{ color: 'rgba(255,255,255,0.7)', fontSize: 13 }} />
            <span style={{ fontSize: '0.8rem', color: 'rgba(255,255,255,0.7)' }}>Free forever · No credit card required</span>
          </div>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer style={{ background: 'var(--text-primary)', padding: '40px 5% 28px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 16, paddingBottom: 24, borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ width: 34, height: 34, background: 'var(--green)', borderRadius: 9, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <FaLeaf style={{ color: '#fff', fontSize: 14 }} />
              </div>
              <span style={{ fontWeight: 800, fontSize: '1rem', color: '#fff' }}>Agri<span style={{ color: 'var(--green-light)' }}>Tech</span></span>
            </div>
            <div style={{ display: 'flex', gap: 28 }}>
              {['/dashboard', '/forum', '/marketplace', '/crops'].map((path, i) => (
                <Link key={i} to={path} style={{ fontSize: '0.82rem', color: 'rgba(255,255,255,0.55)', textDecoration: 'none', fontWeight: 500, transition: 'color 0.2s' }}
                  onMouseEnter={e => e.target.style.color = '#fff'}
                  onMouseLeave={e => e.target.style.color = 'rgba(255,255,255,0.55)'}
                >
                  {['Dashboard', 'Forum', 'Marketplace', 'Crops'][i]}
                </Link>
              ))}
            </div>
          </div>
          <div style={{ paddingTop: 20, textAlign: 'center' }}>
            <p style={{ fontSize: '0.78rem', color: 'rgba(255,255,255,0.35)' }}>© {new Date().getFullYear()} AgriTech. Smart farming for modern agriculture.</p>
          </div>
        </div>
      </footer>

      <style>{`
        @media (max-width: 768px) {
          .nav-desktop { display: none !important; }
        }
      `}</style>
    </div>
  );
}
