import React, { useState, useEffect } from 'react';
import {
  BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  AreaChart, Area
} from 'recharts';
import {
  FaTractor, FaSeedling, FaChartLine, FaLeaf,
  FaCalendarAlt, FaTint, FaDownload, FaSyncAlt,
  FaFileExcel, FaFilePdf, FaPrint, FaTemperatureHigh, FaWater
} from 'react-icons/fa';
import AppLayout from '../components/Layout/AppLayout';
import { getUserCrops } from '../services/cropService';
import { getUserFarms } from '../services/farmService';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';

const HEALTH_COLORS = {
  excellent: '#059669', good: '#059669',
  fair: '#0284c7', poor: '#dc2626', critical: '#dc2626',
};

const HEALTH_SCORES = { excellent: 5, good: 4, fair: 3, poor: 2, critical: 1 };

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload?.length) {
    return (
      <div style={{ background: 'var(--bg-elevated)', border: '1px solid var(--border-strong)', borderRadius: 8, padding: '10px 14px' }}>
        <p style={{ margin: 0, fontSize: '0.8rem', fontWeight: 600, color: 'var(--text-primary)' }}>{label}</p>
        <p style={{ margin: '4px 0 0', fontSize: '0.8rem', color: payload[0].color }}>{payload[0].name}: {payload[0].value}</p>
      </div>
    );
  }
  return null;
};

const AnalyticsPage = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [crops, setCrops] = useState([]);
  const [farms, setFarms] = useState([]);
  const [cropStages, setCropStages] = useState([]);
  const [healthData, setHealthData] = useState([]);
  const [monthlyData, setMonthlyData] = useState([]);
  const [stats, setStats] = useState({ totalCrops: 0, activeCrops: 0, harvestedCrops: 0, predictedYield: 0, actualYield: 0, avgHealth: 0 });

  useEffect(() => { fetchAnalytics(); }, []);

  const fetchAnalytics = async () => {
    setLoading(true);
    try {
      const [cropsData, farmsData] = await Promise.all([getUserCrops(), getUserFarms()]);
      setCrops(cropsData);
      setFarms(farmsData);

      const harvestedCrops = cropsData.filter(c => c.growthStage === 'harvesting');
      const activeCrops = cropsData.filter(c => c.growthStage !== 'harvesting' && c.growthStage !== 'fallow');
      const avgHealth = cropsData.reduce((sum, c) => sum + (HEALTH_SCORES[c.health] || 3), 0) / (cropsData.length || 1);

      setStats({
        totalCrops: cropsData.length, activeCrops: activeCrops.length,
        harvestedCrops: harvestedCrops.length,
        predictedYield: cropsData.reduce((sum, c) => sum + (c.predictedYield?.value || 0), 0),
        actualYield: cropsData.reduce((sum, c) => sum + (c.actualYield?.value || 0), 0),
        avgHealth,
      });

      const stageCount = {};
      cropsData.forEach(c => { stageCount[c.growthStage] = (stageCount[c.growthStage] || 0) + 1; });
      setCropStages(Object.entries(stageCount).map(([stage, count]) => ({ stage: stage.charAt(0).toUpperCase() + stage.slice(1), count })));

      const healthCount = { excellent: 0, good: 0, fair: 0, poor: 0 };
      cropsData.forEach(c => { if (healthCount[c.health] !== undefined) healthCount[c.health]++; });
      setHealthData(Object.entries(healthCount).map(([name, value]) => ({ name, value })));

      const monthlyPlanting = {};
      cropsData.forEach(c => {
        if (c.plantingDate) {
          const month = new Date(c.plantingDate).toLocaleString('default', { month: 'short' });
          monthlyPlanting[month] = (monthlyPlanting[month] || 0) + 1;
        }
      });
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      setMonthlyData(months.map(month => ({ month, plantings: monthlyPlanting[month] || 0 })));
    } catch { toast.error('Failed to load analytics data'); }
    finally { setLoading(false); }
  };

  const exportToCSV = () => {
    setExporting(true);
    try {
      if (!crops.length) { toast.warning('No data to export'); return; }
      const exportData = crops.map(c => ({
        'Crop Name': c.name, 'Farm': c.farm?.name || 'N/A', 'Variety': c.variety || 'N/A',
        'Growth Stage': c.growthStage, 'Health': c.health,
        'Planted': new Date(c.plantingDate).toLocaleDateString(),
        'Expected Harvest': c.expectedHarvestDate ? new Date(c.expectedHarvestDate).toLocaleDateString() : 'N/A',
        'Area': `${c.areaPlanted?.value || 0} ${c.areaPlanted?.unit || ''}`,
        'Predicted Yield (kg)': c.predictedYield?.value || 0,
        'Actual Yield (kg)': c.actualYield?.value || 0,
      }));
      const headers = Object.keys(exportData[0]);
      const csv = [headers.join(','), ...exportData.map(row => headers.map(h => `"${String(row[h]).replace(/"/g, '""')}"`).join(','))].join('\n');
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `farm_analytics_${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(link); link.click(); document.body.removeChild(link);
      toast.success(`Exported ${exportData.length} records!`);
    } catch { toast.error('Export failed'); }
    finally { setExporting(false); }
  };

  const exportToJSON = () => {
    setExporting(true);
    try {
      const data = { generatedAt: new Date().toISOString(), user: user?.name, summary: stats, crops: crops.map(c => ({ name: c.name, farm: c.farm?.name, growthStage: c.growthStage, health: c.health, plantingDate: c.plantingDate })), farms: farms.map(f => ({ name: f.name, location: f.location, size: f.size })) };
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `farm_analytics_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link); link.click(); document.body.removeChild(link);
      toast.success('JSON exported!');
    } catch { toast.error('Export failed'); }
    finally { setExporting(false); }
  };

  const printReport = () => {
    if (!crops.length) { toast.warning('No data to print'); return; }
    const w = window.open('', '_blank');
    w.document.write(`<html><head><title>Farm Analytics</title><style>body{font-family:sans-serif;padding:20px}h1{color:#16a34a}table{width:100%;border-collapse:collapse;margin-top:20px}th,td{border:1px solid #ddd;padding:8px;text-align:left}th{background:#f0fdf4;color:#0f2d1a}.summary{margin:20px 0;padding:15px;background:#f0fdf4;border-radius:8px;border-left:4px solid #16a34a}</style></head><body><h1>🌾 Farm Analytics Report</h1><p>Generated: ${new Date().toLocaleString()}</p><p>Farmer: ${user?.name}</p><div class="summary"><h3>Summary</h3><p>Total Farms: ${farms.length}</p><p>Total Crops: ${stats.totalCrops}</p><p>Active Crops: ${stats.activeCrops}</p><p>Avg Health: ${stats.avgHealth.toFixed(2)}/5</p></div><h3>Crops</h3><table><thead><tr><th>Crop</th><th>Farm</th><th>Stage</th><th>Health</th><th>Planted</th></tr></thead><tbody>${crops.map(c => `<tr><td>${c.name}</td><td>${c.farm?.name || 'N/A'}</td><td>${c.growthStage}</td><td>${c.health}</td><td>${new Date(c.plantingDate).toLocaleDateString()}</td></tr>`).join('')}</tbody></table></body></html>`);
    w.document.close(); w.print();
  };

  const statCards = [
    { icon: FaTractor,   title: 'Total Farms',   value: farms.length,                  color: 'var(--green)',   bg: 'var(--green-dim)' },
    { icon: FaSeedling,  title: 'Total Crops',   value: stats.totalCrops,              color: 'var(--emerald)', bg: 'var(--emerald-dim)' },
    { icon: FaLeaf,      title: 'Active Crops',  value: stats.activeCrops,             color: 'var(--sky)',     bg: 'var(--sky-dim)' },
    { icon: FaChartLine, title: 'Health Avg',    value: `${stats.avgHealth.toFixed(1)}/5`, color: 'var(--violet)', bg: 'var(--violet-dim)' },
  ];

  if (loading) {
    return (
      <AppLayout title="Farm Analytics">
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '50vh', gap: 16 }}>
          <div className="spinner-amber" />
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Loading analytics...</p>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout
      title="Farm Analytics"
      subtitle="Data-driven insights for better farming decisions"
      actions={
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn-ghost" onClick={fetchAnalytics} style={{ padding: '7px 14px', fontSize: '0.82rem' }}>
            <FaSyncAlt size={11} /> Refresh
          </button>
          <div style={{ position: 'relative' }}>
            <button className="btn-amber" style={{ padding: '7px 14px', fontSize: '0.82rem' }} disabled={exporting || !crops.length}
              onClick={() => document.getElementById('export-menu').classList.toggle('open')}>
              <FaDownload size={11} /> {exporting ? 'Exporting…' : 'Export'}
            </button>
            <div id="export-menu" style={{ display: 'none', position: 'absolute', right: 0, top: '100%', marginTop: 4, background: 'var(--bg-surface)', border: '1px solid var(--border-strong)', borderRadius: 10, padding: 6, minWidth: 180, zIndex: 100, boxShadow: 'var(--shadow-lg)' }}>
              <button className="dropdown-item-dark" onClick={() => { exportToCSV(); document.getElementById('export-menu').classList.remove('open'); }}>
                <FaFileExcel size={12} /> Export as CSV
              </button>
              <button className="dropdown-item-dark" onClick={() => { exportToJSON(); document.getElementById('export-menu').classList.remove('open'); }}>
                <FaFilePdf size={12} /> Export as JSON
              </button>
              <div style={{ borderTop: '1px solid var(--border)', margin: '4px 0' }} />
              <button className="dropdown-item-dark" onClick={() => { printReport(); document.getElementById('export-menu').classList.remove('open'); }}>
                <FaPrint size={12} /> Print Report
              </button>
            </div>
          </div>
        </div>
      }
    >
      {!crops.length && (
        <div className="alert-dark alert-sky" style={{ marginBottom: 20 }}>
          <FaLeaf size={13} /> No crops data available. Add some crops to see analytics.
        </div>
      )}

      {/* Stat Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 16, marginBottom: 24 }}>
        {statCards.map((card, i) => {
          const Icon = card.icon;
          return (
            <div key={i} className="stat-card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div className="stat-label" style={{ marginBottom: 8 }}>{card.title}</div>
                  <div className="stat-value">{card.value}</div>
                </div>
                <div className="stat-icon" style={{ background: card.bg }}>
                  <Icon style={{ color: card.color }} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts Row 1 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
        <div className="card-dark" style={{ padding: 20 }}>
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: '0.875rem', fontWeight: 600, color: 'var(--text-primary)' }}>Crop Growth Distribution</div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Crops by growth stage</div>
          </div>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={cropStages} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="stage" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="count" fill="var(--green)" radius={[4, 4, 0, 0]} name="Crops" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="card-dark" style={{ padding: 20 }}>
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: '0.875rem', fontWeight: 600, color: 'var(--text-primary)' }}>Crop Health Status</div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Overall health distribution</div>
          </div>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={healthData} cx="50%" cy="50%" innerRadius={55} outerRadius={90} paddingAngle={2} dataKey="value"
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`} labelLine={{ stroke: 'var(--text-muted)', strokeWidth: 1 }}>
                {healthData.map((entry, i) => (
                  <Cell key={i} fill={HEALTH_COLORS[entry.name] || 'var(--green)'} stroke="var(--bg-surface)" strokeWidth={2} />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Charts Row 2 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 24 }}>
        <div className="card-dark" style={{ padding: 20 }}>
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: '0.875rem', fontWeight: 600, color: 'var(--text-primary)' }}>Monthly Planting Activity</div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Plantings per month</div>
          </div>
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={monthlyData} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
              <defs>
                <linearGradient id="colorPlantings" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="var(--emerald)" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="var(--emerald)" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="plantings" stroke="var(--emerald)" strokeWidth={2} fillOpacity={1} fill="url(#colorPlantings)" name="Plantings" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="card-dark" style={{ padding: 20 }}>
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: '0.875rem', fontWeight: 600, color: 'var(--text-primary)' }}>Yield Overview</div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Predicted vs Actual (kg)</div>
          </div>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={[{ name: 'Yield', predicted: stats.predictedYield, actual: stats.actualYield }]} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: '0.78rem', color: 'var(--text-muted)' }} />
              <Bar dataKey="predicted" fill="var(--green)" name="Predicted" radius={[4, 4, 0, 0]} />
              <Bar dataKey="actual" fill="var(--emerald)" name="Actual" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Crops Table */}
      <div className="card-dark" style={{ marginBottom: 24 }}>
        <div className="section-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 28, height: 28, background: 'var(--emerald-dim)', borderRadius: 7, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <FaSeedling style={{ color: 'var(--emerald)', fontSize: 12 }} />
            </div>
            <span className="section-title">Recent Crops Summary</span>
          </div>
          {crops.length > 0 && (
            <button className="btn-ghost" onClick={exportToCSV} style={{ padding: '6px 12px', fontSize: '0.78rem' }}>
              <FaDownload size={11} /> Export
            </button>
          )}
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table className="table-dark-custom">
            <thead>
              <tr>
                <th>Crop Name</th>
                <th>Farm</th>
                <th>Growth Stage</th>
                <th>Health</th>
                <th>Planted Date</th>
                <th style={{ textAlign: 'right' }}>Predicted Yield</th>
              </tr>
            </thead>
            <tbody>
              {crops.slice(0, 5).map((crop) => (
                <tr key={crop._id}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <FaSeedling style={{ color: 'var(--emerald)', fontSize: 12 }} />
                      <strong style={{ color: 'var(--text-primary)' }}>{crop.name}</strong>
                    </div>
                  </td>
                  <td>{crop.farm?.name || 'N/A'}</td>
                  <td><span className="badge-muted" style={{ textTransform: 'capitalize' }}>{crop.growthStage}</span></td>
                  <td>
                    <span className={['excellent', 'good'].includes(crop.health) ? 'badge-emerald' : ['fair'].includes(crop.health) ? 'badge-amber' : 'badge-rose'}>
                      {crop.health}
                    </span>
                  </td>
                  <td>{new Date(crop.plantingDate).toLocaleDateString()}</td>
                  <td style={{ textAlign: 'right' }}>{crop.predictedYield?.value || 0} kg</td>
                </tr>
              ))}
              {!crops.length && (
                <tr>
                  <td colSpan="6" style={{ textAlign: 'center', padding: '32px', color: 'var(--text-muted)' }}>
                    No crops added yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Insights Banner */}
      <div style={{
        background: 'linear-gradient(135deg, #f0fdf4, #dcfce7)',
        border: '1px solid var(--border)',
        borderLeft: '4px solid var(--green)',
        borderRadius: 12,
        padding: '20px 24px',
      }}>
        <div style={{ fontSize: '0.875rem', fontWeight: 600, color: 'var(--text-primary)', marginBottom: 16 }}>
          Smart Farming Insights
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 16 }}>
          {[
            { icon: FaTemperatureHigh, text: stats.avgHealth > 4 ? '✨ Crops in excellent condition!' : stats.avgHealth > 3 ? '🌿 Crops doing well. Keep monitoring.' : '⚠️ Some crops need attention.', color: 'var(--green)' },
            { icon: FaTractor, text: `${stats.activeCrops} active crops across ${farms.length} farms`, color: 'var(--emerald)' },
            { icon: FaWater, text: stats.avgHealth > 3 ? 'Maintain current irrigation schedule' : 'Consider increasing irrigation frequency', color: 'var(--sky)' },
          ].map((item, i) => {
            const Icon = item.icon;
            return (
              <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
                <div style={{ width: 32, height: 32, background: `${item.color}20`, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <Icon style={{ color: item.color, fontSize: 13 }} />
                </div>
                <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.5 }}>{item.text}</p>
              </div>
            );
          })}
        </div>
      </div>
    </AppLayout>
  );
};

export default AnalyticsPage;
