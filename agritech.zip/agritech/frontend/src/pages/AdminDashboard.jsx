import React, { useState, useEffect, useRef } from 'react';
import {
  FaUsers, FaTractor, FaSeedling, FaDollarSign, FaEdit, FaTrash,
  FaLeaf, FaShieldAlt, FaChartBar, FaShoppingCart, FaComments,
  FaSearch, FaEye, FaPlus, FaStore, FaUserCheck, FaSyncAlt,
  FaImage, FaUpload, FaTimes, FaSignOutAlt, FaHome
} from 'react-icons/fa';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  getSystemStats, getAllUsers, updateUser, deleteUser,
  getAllBookings, updateBookingStatus,
  getAllProductsAdmin, getAllForumPosts, deleteForumPost,
  getAllFarmsAdmin, getAllCropsAdmin,
} from '../services/adminService';
import { createProduct, updateProduct, deleteProduct } from '../services/productService';
import { toast } from 'react-toastify';
import moment from 'moment';

const NAV = [
  { key: 'overview',  label: 'Overview',    icon: FaChartBar,    color: 'var(--green)' },
  { key: 'users',     label: 'Users',       icon: FaUsers,       color: 'var(--sky)' },
  { key: 'farms',     label: 'Farms',       icon: FaTractor,     color: 'var(--green)' },
  { key: 'crops',     label: 'Crops',       icon: FaSeedling,    color: 'var(--emerald)' },
  { key: 'products',  label: 'Products',    icon: FaStore,       color: 'var(--sky)' },
  { key: 'bookings',  label: 'Bookings',    icon: FaShoppingCart, color: 'var(--rose)' },
  { key: 'forum',     label: 'Forum',       icon: FaComments,    color: 'var(--violet)' },
];

const roleBadge = (role) => {
  const map = { admin: 'badge-rose', expert: 'badge-sky', farmer: 'badge-emerald' };
  const emoji = { admin: '👑', expert: '👨‍🌾', farmer: '🌾' };
  return <span className={map[role] || 'badge-muted'}>{emoji[role]} {role}</span>;
};

const statusBadge = (s) => {
  const map = { pending: 'badge-amber', confirmed: 'badge-sky', in_progress: 'badge-sky', completed: 'badge-emerald', cancelled: 'badge-rose', refunded: 'badge-muted' };
  return <span className={map[s] || 'badge-muted'} style={{ textTransform: 'capitalize' }}>{s?.replace(/_/g, ' ')}</span>;
};

const healthBadge = (h) => {
  const map = { excellent: 'badge-emerald', good: 'badge-emerald', fair: 'badge-amber', poor: 'badge-rose', critical: 'badge-rose' };
  return <span className={map[h] || 'badge-muted'}>{h}</span>;
};

const EmptyState = ({ icon, title, sub }) => (
  <div className="empty-state">
    <div className="empty-icon" style={{ fontSize: 28 }}>{icon}</div>
    <div className="empty-title">{title}</div>
    {sub && <div className="empty-sub">{sub}</div>}
  </div>
);

const AdminDashboard = () => {
  const navigate = useNavigate();
  const { logout } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [farms, setFarms] = useState([]);
  const [crops, setCrops] = useState([]);
  const [products, setProducts] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [forum, setForum] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tabLoading, setTabLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [userModal, setUserModal] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [userForm, setUserForm] = useState({ name: '', email: '', role: 'farmer', isVerified: false });
  const [productModal, setProductModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [productForm, setProductForm] = useState({ name: '', category: 'seeds', description: '', price: '', unit: 'kg', stock: '', manufacturer: '', isAvailable: true, images: [] });
  const [imageUploading, setImageUploading] = useState(false);
  const imageInputRef = useRef(null);
  const [bookingModal, setBookingModal] = useState(false);
  const [editingBooking, setEditingBooking] = useState(null);
  const [bookingForm, setBookingForm] = useState({ status: 'pending', paymentStatus: 'pending' });
  const [viewUserModal, setViewUserModal] = useState(false);
  const [viewingUser, setViewingUser] = useState(null);
  const [createUserModal, setCreateUserModal] = useState(false);
  const [createUserForm, setCreateUserForm] = useState({ name: '', email: '', password: '', role: 'farmer', isVerified: false });

  useEffect(() => { fetchOverview(); }, []);
  useEffect(() => { fetchTab(activeTab); }, [activeTab]);

  const fetchOverview = async () => {
    setLoading(true);
    try { const s = await getSystemStats(); setStats(s); }
    catch { toast.error('Failed to load stats'); }
    finally { setLoading(false); }
  };

  const fetchTab = async (tab) => {
    setTabLoading(true);
    try {
      if (tab === 'users')    setUsers(await getAllUsers());
      if (tab === 'farms')    setFarms(await getAllFarmsAdmin());
      if (tab === 'crops')    setCrops(await getAllCropsAdmin());
      if (tab === 'products') setProducts(await getAllProductsAdmin());
      if (tab === 'bookings') setBookings(await getAllBookings());
      if (tab === 'forum')    setForum(await getAllForumPosts());
      if (tab === 'overview') { const s = await getSystemStats(); setStats(s); }
    } catch { toast.error(`Failed to load ${tab}`); }
    finally { setTabLoading(false); }
  };

  const openEditUser = (u) => { setEditingUser(u); setUserForm({ name: u.name, email: u.email, role: u.role, isVerified: u.isVerified }); setUserModal(true); };
  const handleSaveUser = async (e) => {
    e.preventDefault();
    try { await updateUser(editingUser._id, userForm); toast.success('User updated'); setUserModal(false); fetchTab('users'); }
    catch (err) { toast.error(err.response?.data?.message || 'Failed to update user'); }
  };
  const handleDeleteUser = async (id) => {
    if (!window.confirm('Delete this user and all their data?')) return;
    try { await deleteUser(id); toast.success('User deleted'); fetchTab('users'); }
    catch { toast.error('Failed to delete user'); }
  };

  const handleCreateUser = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/auth/register', { name: createUserForm.name, email: createUserForm.email, password: createUserForm.password, role: createUserForm.role }, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } });
      if (createUserForm.isVerified) {
        const allUsers = await getAllUsers();
        const newUser = allUsers.find(u => u.email === createUserForm.email);
        if (newUser) await updateUser(newUser._id, { isVerified: true });
      }
      toast.success(`Account created for ${createUserForm.name}`);
      setCreateUserModal(false);
      setCreateUserForm({ name: '', email: '', password: '', role: 'farmer', isVerified: false });
      fetchTab('users');
    } catch (err) { toast.error(err.response?.data?.message || 'Failed to create account'); }
  };

  const openAddProduct = () => { setEditingProduct(null); setProductForm({ name: '', category: 'seeds', description: '', price: '', unit: 'kg', stock: '', manufacturer: '', isAvailable: true, images: [] }); setProductModal(true); };
  const openEditProduct = (p) => { setEditingProduct(p); setProductForm({ name: p.name, category: p.category, description: p.description, price: p.price, unit: p.unit, stock: p.stock, manufacturer: p.manufacturer || '', isAvailable: p.isAvailable, images: p.images || [] }); setProductModal(true); };

  const handleProductImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { toast.error('Please select an image file'); return; }
    if (file.size > 5 * 1024 * 1024) { toast.error('Image must be under 5MB'); return; }
    setImageUploading(true);
    try {
      const fd = new FormData(); fd.append('image', file);
      const res = await axios.post('http://localhost:5000/api/upload/single', fd, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}`, 'Content-Type': 'multipart/form-data' } });
      if (res.data.success) { setProductForm(prev => ({ ...prev, images: [...prev.images, res.data.url] })); toast.success('Image uploaded'); }
    } catch { toast.error('Image upload failed'); }
    finally { setImageUploading(false); if (imageInputRef.current) imageInputRef.current.value = ''; }
  };

  const removeProductImage = (idx) => setProductForm(prev => ({ ...prev, images: prev.images.filter((_, i) => i !== idx) }));

  const handleSaveProduct = async (e) => {
    e.preventDefault();
    try {
      if (editingProduct) { await updateProduct(editingProduct._id, productForm); toast.success('Product updated'); }
      else { await createProduct(productForm); toast.success('Product created'); }
      setProductModal(false); fetchTab('products');
    } catch (err) { toast.error(err.response?.data?.message || 'Failed to save product'); }
  };
  const handleDeleteProduct = async (id) => {
    if (!window.confirm('Delete this product?')) return;
    try { await deleteProduct(id); toast.success('Product deleted'); fetchTab('products'); }
    catch { toast.error('Failed to delete product'); }
  };

  const openEditBooking = (b) => { setEditingBooking(b); setBookingForm({ status: b.status, paymentStatus: b.paymentStatus }); setBookingModal(true); };
  const handleSaveBooking = async (e) => {
    e.preventDefault();
    try { await updateBookingStatus(editingBooking._id, bookingForm); toast.success('Booking updated'); setBookingModal(false); fetchTab('bookings'); }
    catch { toast.error('Failed to update booking'); }
  };

  const handleDeletePost = async (id) => {
    if (!window.confirm('Delete this forum post?')) return;
    try { await deleteForumPost(id); toast.success('Post deleted'); fetchTab('forum'); }
    catch { toast.error('Failed to delete post'); }
  };

  const filter = (arr, keys) => arr.filter(item => keys.some(k => String(item[k] || '').toLowerCase().includes(search.toLowerCase())));

  if (loading) return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', gap: 16, background: 'var(--bg-base)' }}>
      <div className="spinner-amber" />
      <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Loading admin panel...</p>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );

  const statCards = [
    { icon: FaUsers,       label: 'Total Users',  value: stats?.users?.total || 0,           color: 'var(--sky)',     bg: 'var(--sky-dim)' },
    { icon: FaTractor,     label: 'Farmers',      value: stats?.users?.farmers || 0,         color: 'var(--green)',   bg: 'var(--green-dim)' },
    { icon: FaUserCheck,   label: 'Experts',      value: stats?.users?.experts || 0,         color: 'var(--violet)',  bg: 'var(--violet-dim)' },
    { icon: FaTractor,     label: 'Total Farms',  value: stats?.agriculture?.farms || 0,     color: 'var(--green)',   bg: 'var(--green-dim)' },
    { icon: FaSeedling,    label: 'Total Crops',  value: stats?.agriculture?.crops || 0,     color: 'var(--emerald)', bg: 'var(--emerald-dim)' },
    { icon: FaStore,       label: 'Products',     value: stats?.commerce?.products || 0,     color: 'var(--sky)',     bg: 'var(--sky-dim)' },
    { icon: FaShoppingCart,label: 'Bookings',     value: stats?.commerce?.bookings || 0,     color: 'var(--rose)',    bg: 'var(--rose-dim)' },
    { icon: FaDollarSign,  label: 'Revenue',      value: `₱${(stats?.commerce?.revenue || 0).toLocaleString()}`, color: 'var(--emerald)', bg: 'var(--emerald-dim)' },
  ];

  const ModalOverlay = ({ children, onClose }) => (
    <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      {children}
    </div>
  );

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: 'var(--bg-base)' }}>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>

      {/* Sidebar */}
      <div style={{ width: 220, background: 'var(--bg-surface)', borderRight: '1px solid var(--border)', display: 'flex', flexDirection: 'column', position: 'sticky', top: 0, height: '100vh', flexShrink: 0, boxShadow: '2px 0 12px rgba(22,163,74,0.06)' }}>
        <div className="sidebar-brand">
          <div className="sidebar-brand-icon"><FaLeaf style={{ color: '#fff', fontSize: 15 }} /></div>
          <div>
            <div className="sidebar-brand-text">Agri<span>Tech</span></div>
            <div style={{ fontSize: '0.65rem', color: 'var(--text-muted)', marginTop: -2 }}>Admin Panel</div>
          </div>
        </div>
        <nav className="sidebar-nav">
          <span className="sidebar-section-label">Management</span>
          {NAV.map(n => {
            const Icon = n.icon;
            return (
              <button key={n.key} className={`sidebar-link${activeTab === n.key ? ' active' : ''}`} onClick={() => setActiveTab(n.key)}>
                <span className="sidebar-link-icon"><Icon size={13} /></span>
                {n.label}
              </button>
            );
          })}
        </nav>
        <div style={{ padding: 12, borderTop: '1px solid var(--border)' }}>
          <button className="sidebar-link" onClick={() => navigate('/dashboard')} style={{ marginBottom: 2 }}>
            <span className="sidebar-link-icon"><FaHome size={13} /></span> Back to App
          </button>
          <button className="sidebar-link" onClick={() => { logout(); navigate('/login'); }} style={{ color: 'var(--rose)' }}>
            <span className="sidebar-link-icon"><FaSignOutAlt size={13} /></span> Sign Out
          </button>
        </div>
      </div>

      {/* Main */}
      <div style={{ flex: 1, overflowY: 'auto', padding: 28, background: 'var(--bg-base)' }}>
        {/* Topbar */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24, flexWrap: 'wrap', gap: 12 }}>
          <div>
            <h4 style={{ fontWeight: 700, color: 'var(--text-primary)', marginBottom: 2 }}>
              {NAV.find(n => n.key === activeTab)?.label || 'Overview'}
            </h4>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.78rem', margin: 0 }}>
              {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
          </div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            {activeTab !== 'overview' && (
              <div style={{ position: 'relative' }}>
                <FaSearch style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)', fontSize: 11 }} />
                <input placeholder={`Search ${activeTab}...`} value={search} onChange={e => setSearch(e.target.value)} className="input-dark" style={{ paddingLeft: 30, width: 200 }} />
              </div>
            )}
            <button className="btn-ghost" onClick={() => fetchTab(activeTab)} style={{ padding: '8px 14px', fontSize: '0.82rem' }}>
              <FaSyncAlt size={11} /> Refresh
            </button>
            {activeTab === 'products' && (
              <button className="btn-amber" onClick={openAddProduct} style={{ padding: '8px 14px', fontSize: '0.82rem' }}>
                <FaPlus size={11} /> Add Product
              </button>
            )}
            {activeTab === 'users' && (
              <button className="btn-amber" onClick={() => setCreateUserModal(true)} style={{ padding: '8px 14px', fontSize: '0.82rem' }}>
                <FaPlus size={11} /> Create Account
              </button>
            )}
          </div>
        </div>

        {tabLoading ? (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '80px 0', gap: 16 }}>
            <div className="spinner-amber" />
            <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Loading...</p>
          </div>
        ) : (
          <>
            {/* OVERVIEW */}
            {activeTab === 'overview' && (
              <>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 14, marginBottom: 24 }}>
                  {statCards.map((c, i) => {
                    const Icon = c.icon;
                    return (
                      <div key={i} className="stat-card">
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                          <div>
                            <div className="stat-label" style={{ marginBottom: 6 }}>{c.label}</div>
                            <div className="stat-value" style={{ fontSize: '1.6rem' }}>{c.value}</div>
                          </div>
                          <div className="stat-icon" style={{ background: c.bg, width: 38, height: 38 }}>
                            <Icon style={{ color: c.color, fontSize: 15 }} />
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                  {[
                    { title: 'Recent Users', icon: FaUsers, color: 'var(--sky)', items: stats?.recentActivity?.users || [], render: (u) => (
                      <div key={u._id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 20px', borderBottom: '1px solid var(--border)' }}>
                        <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'var(--green-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                          <FaUsers style={{ color: 'var(--green)', fontSize: 13 }} />
                        </div>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontWeight: 600, fontSize: '0.85rem', color: 'var(--text-primary)' }}>{u.name}</div>
                          <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{u.email}</div>
                        </div>
                        {roleBadge(u.role)}
                      </div>
                    )},
                    { title: 'Recent Bookings', icon: FaShoppingCart, color: 'var(--rose)', items: stats?.recentActivity?.bookings || [], render: (b) => (
                      <div key={b._id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 20px', borderBottom: '1px solid var(--border)' }}>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontWeight: 600, fontSize: '0.85rem', color: 'var(--text-primary)' }}>{b.user?.name || 'Unknown'}</div>
                          <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{b.bookingType?.replace(/_/g, ' ')} · ₱{b.totalAmount}</div>
                        </div>
                        {statusBadge(b.status)}
                      </div>
                    )},
                  ].map((section, i) => {
                    const Icon = section.icon;
                    return (
                      <div key={i} className="card-dark" style={{ overflow: 'hidden' }}>
                        <div className="section-header">
                          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                            <Icon style={{ color: section.color, fontSize: 14 }} />
                            <span className="section-title">{section.title}</span>
                          </div>
                        </div>
                        <div>
                          {section.items.slice(0, 5).map(section.render)}
                          {!section.items.length && <EmptyState icon="📭" title="No data yet" />}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </>
            )}

            {/* USERS */}
            {activeTab === 'users' && (
              <div className="card-dark" style={{ overflow: 'hidden' }}>
                <div className="section-header">
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <FaUsers style={{ color: 'var(--sky)', fontSize: 14 }} />
                    <span className="section-title">All Users</span>
                    <span className="badge-sky" style={{ marginLeft: 4 }}>{users.length}</span>
                  </div>
                </div>
                {!filter(users, ['name', 'email', 'role']).length ? <EmptyState icon="👥" title="No users found" /> : (
                  <div style={{ overflowX: 'auto' }}>
                    <table className="table-dark-custom">
                      <thead><tr><th>User</th><th>Role</th><th>Status</th><th>Joined</th><th>Last Login</th><th>Actions</th></tr></thead>
                      <tbody>
                        {filter(users, ['name', 'email', 'role']).map(u => (
                          <tr key={u._id}>
                            <td><div style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{u.name}</div><div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{u.email}</div></td>
                            <td>{roleBadge(u.role)}</td>
                            <td><span className={u.isVerified ? 'badge-emerald' : 'badge-amber'}>{u.isVerified ? '✓ Verified' : 'Pending'}</span></td>
                            <td>{moment(u.createdAt).format('MMM D, YYYY')}</td>
                            <td>{u.lastLogin ? moment(u.lastLogin).fromNow() : '—'}</td>
                            <td>
                              <div style={{ display: 'flex', gap: 6 }}>
                                <button className="btn-icon" style={{ background: 'var(--sky-dim)', color: 'var(--sky)' }} onClick={() => { setViewingUser(u); setViewUserModal(true); }} title="View"><FaEye size={11} /></button>
                                <button className="btn-icon" style={{ background: 'var(--emerald-dim)', color: 'var(--emerald)' }} onClick={() => openEditUser(u)} title="Edit"><FaEdit size={11} /></button>
                                <button className="btn-icon" style={{ background: 'var(--rose-dim)', color: 'var(--rose)' }} onClick={() => handleDeleteUser(u._id)} title="Delete"><FaTrash size={11} /></button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* FARMS */}
            {activeTab === 'farms' && (
              <div className="card-dark" style={{ overflow: 'hidden' }}>
                <div className="section-header">
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <FaTractor style={{ color: 'var(--green)', fontSize: 14 }} />
                    <span className="section-title">All Farms</span>
                    <span className="badge-green" style={{ marginLeft: 4 }}>{farms.length}</span>
                  </div>
                </div>
                {!filter(farms, ['name']).length ? <EmptyState icon="🚜" title="No farms found" /> : (
                  <div style={{ overflowX: 'auto' }}>
                    <table className="table-dark-custom">
                      <thead><tr><th>Farm Name</th><th>Owner</th><th>Location</th><th>Size</th><th>Soil Type</th><th>Irrigation</th><th>Created</th></tr></thead>
                      <tbody>
                        {filter(farms, ['name']).map(f => (
                          <tr key={f._id}>
                            <td style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{f.name}</td>
                            <td><div style={{ fontWeight: 500, color: 'var(--text-primary)' }}>{f.user?.name || '—'}</div><div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{f.user?.email || ''}</div></td>
                            <td>{[f.location?.city, f.location?.state].filter(Boolean).join(', ') || '—'}</td>
                            <td>{f.size?.value ? `${f.size.value} ${f.size.unit}` : '—'}</td>
                            <td><span className="badge-muted" style={{ textTransform: 'capitalize' }}>{f.soilType || '—'}</span></td>
                            <td style={{ textTransform: 'capitalize' }}>{f.irrigationType || '—'}</td>
                            <td>{moment(f.createdAt).format('MMM D, YYYY')}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* CROPS */}
            {activeTab === 'crops' && (
              <div className="card-dark" style={{ overflow: 'hidden' }}>
                <div className="section-header">
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <FaSeedling style={{ color: 'var(--emerald)', fontSize: 14 }} />
                    <span className="section-title">All Crops</span>
                    <span className="badge-emerald" style={{ marginLeft: 4 }}>{crops.length}</span>
                  </div>
                </div>
                {!filter(crops, ['name', 'variety']).length ? <EmptyState icon="🌾" title="No crops found" /> : (
                  <div style={{ overflowX: 'auto' }}>
                    <table className="table-dark-custom">
                      <thead><tr><th>Crop</th><th>Farmer</th><th>Farm</th><th>Stage</th><th>Health</th><th>Planted</th><th>Harvest</th></tr></thead>
                      <tbody>
                        {filter(crops, ['name', 'variety']).map(c => (
                          <tr key={c._id}>
                            <td><div style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{c.name}</div>{c.variety && <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{c.variety}</div>}</td>
                            <td>{c.user?.name || '—'}</td>
                            <td>{c.farm?.name || '—'}</td>
                            <td><span className="badge-muted" style={{ textTransform: 'capitalize' }}>{c.growthStage}</span></td>
                            <td>{healthBadge(c.health)}</td>
                            <td>{moment(c.plantingDate).format('MMM D, YYYY')}</td>
                            <td>{c.expectedHarvestDate ? moment(c.expectedHarvestDate).format('MMM D, YYYY') : '—'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* PRODUCTS */}
            {activeTab === 'products' && (
              <div className="card-dark" style={{ overflow: 'hidden' }}>
                <div className="section-header">
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <FaStore style={{ color: 'var(--sky)', fontSize: 14 }} />
                    <span className="section-title">All Products</span>
                    <span className="badge-sky" style={{ marginLeft: 4 }}>{products.length}</span>
                  </div>
                </div>
                {!filter(products, ['name', 'category']).length ? <EmptyState icon="📦" title="No products yet" sub="Click 'Add Product' to create one" /> : (
                  <div style={{ overflowX: 'auto' }}>
                    <table className="table-dark-custom">
                      <thead><tr><th>Image</th><th>Product</th><th>Category</th><th>Price</th><th>Stock</th><th>Rating</th><th>Status</th><th>Actions</th></tr></thead>
                      <tbody>
                        {filter(products, ['name', 'category']).map(p => (
                          <tr key={p._id}>
                            <td>
                              {p.images?.[0] ? (
                                <img src={p.images[0].startsWith('/uploads/') ? `http://localhost:5000${p.images[0]}` : p.images[0]} alt={p.name} style={{ width: 44, height: 44, objectFit: 'cover', borderRadius: 8, border: '1px solid var(--border)' }} />
                              ) : (
                                <div style={{ width: 44, height: 44, borderRadius: 8, background: 'var(--green-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                  <FaImage style={{ color: 'var(--green)', fontSize: 16 }} />
                                </div>
                              )}
                            </td>
                            <td><div style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{p.name}</div><div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{p.manufacturer || ''}</div></td>
                            <td><span className="badge-sky" style={{ textTransform: 'capitalize' }}>{p.category}</span></td>
                            <td style={{ fontWeight: 600, color: 'var(--green)' }}>₱{p.price}/{p.unit}</td>
                            <td style={{ color: p.stock === 0 ? 'var(--rose)' : 'var(--text-secondary)' }}>{p.stock} {p.unit}s</td>
                            <td style={{ color: 'var(--green)', fontWeight: 500 }}>{'★'.repeat(Math.round(p.rating || 0))} {p.rating?.toFixed(1) || '—'}</td>
                            <td><span className={p.isAvailable ? 'badge-emerald' : 'badge-muted'}>{p.isAvailable ? 'Available' : 'Hidden'}</span></td>
                            <td>
                              <div style={{ display: 'flex', gap: 6 }}>
                                <button className="btn-icon" style={{ background: 'var(--emerald-dim)', color: 'var(--emerald)' }} onClick={() => openEditProduct(p)}><FaEdit size={11} /></button>
                                <button className="btn-icon" style={{ background: 'var(--rose-dim)', color: 'var(--rose)' }} onClick={() => handleDeleteProduct(p._id)}><FaTrash size={11} /></button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* BOOKINGS */}
            {activeTab === 'bookings' && (
              <div className="card-dark" style={{ overflow: 'hidden' }}>
                <div className="section-header">
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <FaShoppingCart style={{ color: 'var(--rose)', fontSize: 14 }} />
                    <span className="section-title">All Bookings</span>
                    <span className="badge-rose" style={{ marginLeft: 4 }}>{bookings.length}</span>
                  </div>
                </div>
                {!filter(bookings, ['bookingType']).length ? <EmptyState icon="🛒" title="No bookings yet" /> : (
                  <div style={{ overflowX: 'auto' }}>
                    <table className="table-dark-custom">
                      <thead><tr><th>Customer</th><th>Type</th><th>Product</th><th>Amount</th><th>Status</th><th>Payment</th><th>Date</th><th>Actions</th></tr></thead>
                      <tbody>
                        {filter(bookings, ['bookingType']).map(b => (
                          <tr key={b._id}>
                            <td><div style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{b.user?.name || '—'}</div><div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{b.user?.email || ''}</div></td>
                            <td style={{ textTransform: 'capitalize', fontSize: '0.82rem' }}>{b.bookingType?.replace(/_/g, ' ')}</td>
                            <td>{b.product?.name || '—'}</td>
                            <td style={{ fontWeight: 600, color: 'var(--green)' }}>₱{b.totalAmount}</td>
                            <td>{statusBadge(b.status)}</td>
                            <td><span className={b.paymentStatus === 'paid' ? 'badge-emerald' : b.paymentStatus === 'failed' ? 'badge-rose' : 'badge-amber'}>{b.paymentStatus}</span></td>
                            <td>{moment(b.createdAt).format('MMM D, YYYY')}</td>
                            <td><button className="btn-icon" style={{ background: 'var(--emerald-dim)', color: 'var(--emerald)' }} onClick={() => openEditBooking(b)}><FaEdit size={11} /></button></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* FORUM */}
            {activeTab === 'forum' && (
              <div className="card-dark" style={{ overflow: 'hidden' }}>
                <div className="section-header">
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <FaComments style={{ color: 'var(--violet)', fontSize: 14 }} />
                    <span className="section-title">Forum Posts</span>
                    <span className="badge-violet" style={{ marginLeft: 4 }}>{forum.length}</span>
                  </div>
                </div>
                {!filter(forum, ['title', 'category']).length ? <EmptyState icon="💬" title="No forum posts yet" /> : (
                  <div style={{ overflowX: 'auto' }}>
                    <table className="table-dark-custom">
                      <thead><tr><th>Title</th><th>Author</th><th>Category</th><th>Likes</th><th>Views</th><th>Status</th><th>Posted</th><th>Actions</th></tr></thead>
                      <tbody>
                        {filter(forum, ['title', 'category']).map(p => (
                          <tr key={p._id}>
                            <td style={{ maxWidth: 200 }}><div style={{ fontWeight: 600, color: 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.title}</div></td>
                            <td>{p.user?.name || '—'}</td>
                            <td><span className="badge-muted">{p.category || 'general'}</span></td>
                            <td>{p.likes?.length || 0}</td>
                            <td>{p.views || 0}</td>
                            <td><span className={p.isResolved ? 'badge-emerald' : 'badge-amber'}>{p.isResolved ? 'Resolved' : 'Open'}</span></td>
                            <td>{moment(p.createdAt).format('MMM D, YYYY')}</td>
                            <td><button className="btn-icon" style={{ background: 'var(--rose-dim)', color: 'var(--rose)' }} onClick={() => handleDeletePost(p._id)}><FaTrash size={11} /></button></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>

      {/* MODALS */}

      {/* Create User */}
      {createUserModal && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setCreateUserModal(false)}>
          <div className="modal-dark">
            <div className="modal-header-dark"><span className="modal-title-dark">➕ Create New Account</span><button className="modal-close" onClick={() => setCreateUserModal(false)}><FaTimes size={12} /></button></div>
            <form onSubmit={handleCreateUser}>
              <div className="modal-body-dark">
                <div className="form-group"><label className="label-dark">Full Name *</label><input value={createUserForm.name} onChange={e => setCreateUserForm({ ...createUserForm, name: e.target.value })} required placeholder="e.g. Juan dela Cruz" className="input-dark" /></div>
                <div className="form-group"><label className="label-dark">Email *</label><input type="email" value={createUserForm.email} onChange={e => setCreateUserForm({ ...createUserForm, email: e.target.value })} required placeholder="user@email.com" className="input-dark" /></div>
                <div className="form-group"><label className="label-dark">Password *</label><input type="password" value={createUserForm.password} onChange={e => setCreateUserForm({ ...createUserForm, password: e.target.value })} required placeholder="Minimum 6 characters" minLength={6} className="input-dark" /></div>
                <div className="form-group"><label className="label-dark">Role</label><select value={createUserForm.role} onChange={e => setCreateUserForm({ ...createUserForm, role: e.target.value })} className="input-dark"><option value="farmer">🌾 Farmer</option><option value="expert">👨‍🌾 Expert</option><option value="admin">👑 Admin</option></select></div>
                <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                  <input type="checkbox" checked={createUserForm.isVerified} onChange={e => setCreateUserForm({ ...createUserForm, isVerified: e.target.checked })} />
                  Mark as Verified immediately
                </label>
              </div>
              <div className="modal-footer-dark"><button type="button" className="btn-ghost" onClick={() => setCreateUserModal(false)}>Cancel</button><button type="submit" className="btn-amber">Create Account</button></div>
            </form>
          </div>
        </div>
      )}

      {/* Edit User */}
      {userModal && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setUserModal(false)}>
          <div className="modal-dark">
            <div className="modal-header-dark"><span className="modal-title-dark">✏️ Edit User</span><button className="modal-close" onClick={() => setUserModal(false)}><FaTimes size={12} /></button></div>
            <form onSubmit={handleSaveUser}>
              <div className="modal-body-dark">
                <div className="form-group"><label className="label-dark">Full Name</label><input value={userForm.name} onChange={e => setUserForm({ ...userForm, name: e.target.value })} required className="input-dark" /></div>
                <div className="form-group"><label className="label-dark">Email</label><input type="email" value={userForm.email} onChange={e => setUserForm({ ...userForm, email: e.target.value })} required className="input-dark" /></div>
                <div className="form-group"><label className="label-dark">Role</label><select value={userForm.role} onChange={e => setUserForm({ ...userForm, role: e.target.value })} className="input-dark"><option value="farmer">🌾 Farmer</option><option value="expert">👨‍🌾 Expert</option><option value="admin">👑 Admin</option></select></div>
                <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                  <input type="checkbox" checked={userForm.isVerified} onChange={e => setUserForm({ ...userForm, isVerified: e.target.checked })} />
                  Account Verified
                </label>
              </div>
              <div className="modal-footer-dark"><button type="button" className="btn-ghost" onClick={() => setUserModal(false)}>Cancel</button><button type="submit" className="btn-amber">Save Changes</button></div>
            </form>
          </div>
        </div>
      )}

      {/* View User */}
      {viewUserModal && viewingUser && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setViewUserModal(false)}>
          <div className="modal-dark">
            <div className="modal-header-dark"><span className="modal-title-dark">👤 User Details</span><button className="modal-close" onClick={() => setViewUserModal(false)}><FaTimes size={12} /></button></div>
            <div className="modal-body-dark">
              <div style={{ textAlign: 'center', marginBottom: 20 }}>
                <div style={{ width: 56, height: 56, borderRadius: '50%', background: 'var(--green-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 10px' }}>
                  <FaUsers style={{ color: 'var(--green)', fontSize: 24 }} />
                </div>
                <div style={{ fontWeight: 700, fontSize: '1rem', color: 'var(--text-primary)', marginBottom: 6 }}>{viewingUser.name}</div>
                {roleBadge(viewingUser.role)}
              </div>
              {[['Email', viewingUser.email], ['Phone', viewingUser.phone || '—'], ['Status', viewingUser.isVerified ? '✓ Verified' : 'Pending'], ['Joined', moment(viewingUser.createdAt).format('MMMM D, YYYY')], ['Last Login', viewingUser.lastLogin ? moment(viewingUser.lastLogin).fromNow() : '—'], ['Location', [viewingUser.location?.city, viewingUser.location?.state].filter(Boolean).join(', ') || '—'], ['Experience', viewingUser.farmExperience || '—']].map(([k, v]) => (
                <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
                  <span style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>{k}</span>
                  <span style={{ fontWeight: 500, fontSize: '0.875rem', color: 'var(--text-secondary)' }}>{v}</span>
                </div>
              ))}
              {viewingUser.bio && <div style={{ marginTop: 12, padding: 12, background: 'var(--bg-elevated)', borderRadius: 8, fontSize: '0.875rem', color: 'var(--text-secondary)' }}>{viewingUser.bio}</div>}
            </div>
          </div>
        </div>
      )}

      {/* Product Modal */}
      {productModal && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setProductModal(false)}>
          <div className="modal-dark modal-dark-lg">
            <div className="modal-header-dark"><span className="modal-title-dark">{editingProduct ? '✏️ Edit Product' : '➕ Add New Product'}</span><button className="modal-close" onClick={() => setProductModal(false)}><FaTimes size={12} /></button></div>
            <form onSubmit={handleSaveProduct}>
              <div className="modal-body-dark">
                <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 12 }}>
                  <div className="form-group"><label className="label-dark">Product Name *</label><input value={productForm.name} onChange={e => setProductForm({ ...productForm, name: e.target.value })} required placeholder="e.g. Hybrid Rice Seeds" className="input-dark" /></div>
                  <div className="form-group"><label className="label-dark">Category *</label><select value={productForm.category} onChange={e => setProductForm({ ...productForm, category: e.target.value })} className="input-dark">{['seeds', 'fertilizers', 'pesticides', 'herbicides', 'equipment', 'tools'].map(c => <option key={c} value={c}>{c}</option>)}</select></div>
                </div>
                <div className="form-group"><label className="label-dark">Description *</label><textarea rows={3} value={productForm.description} onChange={e => setProductForm({ ...productForm, description: e.target.value })} required placeholder="Describe the product..." className="input-dark" style={{ resize: 'vertical' }} /></div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
                  <div className="form-group"><label className="label-dark">Price (₱) *</label><input type="number" step="0.01" min="0" value={productForm.price} onChange={e => setProductForm({ ...productForm, price: e.target.value })} required placeholder="0.00" className="input-dark" /></div>
                  <div className="form-group"><label className="label-dark">Unit</label><select value={productForm.unit} onChange={e => setProductForm({ ...productForm, unit: e.target.value })} className="input-dark">{['kg', 'g', 'liter', 'ml', 'piece', 'bag', 'bottle'].map(u => <option key={u} value={u}>{u}</option>)}</select></div>
                  <div className="form-group"><label className="label-dark">Stock *</label><input type="number" min="0" value={productForm.stock} onChange={e => setProductForm({ ...productForm, stock: e.target.value })} required placeholder="0" className="input-dark" /></div>
                </div>
                <div className="form-group"><label className="label-dark">Manufacturer</label><input value={productForm.manufacturer} onChange={e => setProductForm({ ...productForm, manufacturer: e.target.value })} placeholder="Optional" className="input-dark" /></div>
                <div className="form-group">
                  <label className="label-dark" style={{ display: 'flex', alignItems: 'center', gap: 6 }}><FaImage size={12} /> Product Images <span style={{ fontWeight: 400, color: 'var(--text-muted)' }}>(max 5MB each)</span></label>
                  <div onClick={() => !imageUploading && imageInputRef.current?.click()} style={{ border: '2px dashed var(--border-strong)', borderRadius: 10, padding: 16, textAlign: 'center', cursor: imageUploading ? 'not-allowed' : 'pointer', background: 'var(--bg-elevated)', marginBottom: 10 }}>
                    {imageUploading ? (
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
                        <div style={{ width: 16, height: 16, border: '2px solid var(--border)', borderTopColor: 'var(--green)', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
                        <span style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Uploading...</span>
                      </div>
                    ) : (
                      <>
                        <FaUpload style={{ color: 'var(--green)', fontSize: 20, marginBottom: 6 }} />
                        <div style={{ fontWeight: 600, color: 'var(--text-secondary)', fontSize: '0.875rem' }}>Click to upload image</div>
                      </>
                    )}
                  </div>
                  <input ref={imageInputRef} type="file" accept="image/jpeg,image/jpg,image/png,image/gif,image/webp" onChange={handleProductImageUpload} style={{ display: 'none' }} />
                  {productForm.images.length > 0 && (
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                      {productForm.images.map((url, idx) => (
                        <div key={idx} style={{ position: 'relative', width: 80, height: 80, borderRadius: 8, overflow: 'hidden', border: '1px solid var(--border)' }}>
                          <img src={url.startsWith('/uploads/') ? `http://localhost:5000${url}` : url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                          <button type="button" onClick={() => removeProductImage(idx)} style={{ position: 'absolute', top: 3, right: 3, background: 'var(--rose)', border: 'none', borderRadius: '50%', width: 18, height: 18, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: 'white', padding: 0 }}><FaTimes size={9} /></button>
                          {idx === 0 && <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, background: 'rgba(22,163,74,0.85)', color: '#fff', fontSize: '0.6rem', textAlign: 'center', padding: '2px 0', fontWeight: 700 }}>MAIN</div>}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                  <input type="checkbox" checked={productForm.isAvailable} onChange={e => setProductForm({ ...productForm, isAvailable: e.target.checked })} />
                  Available for purchase
                </label>
              </div>
              <div className="modal-footer-dark"><button type="button" className="btn-ghost" onClick={() => setProductModal(false)}>Cancel</button><button type="submit" className="btn-amber">{editingProduct ? 'Update Product' : 'Create Product'}</button></div>
            </form>
          </div>
        </div>
      )}

      {/* Booking Modal */}
      {bookingModal && editingBooking && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setBookingModal(false)}>
          <div className="modal-dark">
            <div className="modal-header-dark"><span className="modal-title-dark">📦 Update Booking Status</span><button className="modal-close" onClick={() => setBookingModal(false)}><FaTimes size={12} /></button></div>
            <form onSubmit={handleSaveBooking}>
              <div className="modal-body-dark">
                <div style={{ background: 'var(--bg-elevated)', borderRadius: 8, padding: '10px 14px', marginBottom: 16, fontSize: '0.875rem', color: 'var(--text-secondary)', border: '1px solid var(--border)' }}>
                  <strong style={{ color: 'var(--text-primary)' }}>{editingBooking.user?.name}</strong> · {editingBooking.bookingType?.replace(/_/g, ' ')} · <strong style={{ color: 'var(--green)' }}>₱{editingBooking.totalAmount}</strong>
                </div>
                <div className="form-group"><label className="label-dark">Order Status</label><select value={bookingForm.status} onChange={e => setBookingForm({ ...bookingForm, status: e.target.value })} className="input-dark">{['pending', 'confirmed', 'in_progress', 'completed', 'cancelled', 'refunded'].map(s => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}</select></div>
                <div className="form-group"><label className="label-dark">Payment Status</label><select value={bookingForm.paymentStatus} onChange={e => setBookingForm({ ...bookingForm, paymentStatus: e.target.value })} className="input-dark">{['pending', 'paid', 'failed', 'refunded'].map(s => <option key={s} value={s}>{s}</option>)}</select></div>
              </div>
              <div className="modal-footer-dark"><button type="button" className="btn-ghost" onClick={() => setBookingModal(false)}>Cancel</button><button type="submit" className="btn-amber">Update Booking</button></div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
