import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  FaPlus, FaEdit, FaTrash, FaMapMarkerAlt, FaTint,
  FaSeedling, FaTractor, FaChartLine, FaWater, FaLeaf,
  FaCity, FaTimes
} from 'react-icons/fa';
import { toast } from 'react-toastify';
import axios from 'axios';
import AppLayout from '../components/Layout/AppLayout';
import { useAuth } from '../context/AuthContext';

const SOIL_COLORS = {
  clay: 'var(--rose)', sandy: 'var(--teal)', loamy: 'var(--green)',
  silt: 'var(--sky)', peaty: 'var(--violet)', chalky: 'var(--text-muted)',
};

const FarmsPage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [farms, setFarms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingFarm, setEditingFarm] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    location: { address: '', city: '', state: '', pincode: '' },
    size: { value: '', unit: 'acre' },
    soilType: '',
    irrigationType: '',
    waterSource: '',
    ownership: 'owned',
  });

  const getAuthHeaders = () => ({ headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } });

  useEffect(() => { fetchFarms(); }, []);

  const fetchFarms = async () => {
    setLoading(true);
    try {
      const res = await axios.get('http://localhost:5000/api/farms', getAuthHeaders());
      setFarms(res.data);
    } catch (error) {
      if (error.response?.status === 401) { toast.error('Please login again'); navigate('/login'); }
      else toast.error('Failed to load farms');
    } finally { setLoading(false); }
  };

  const handleOpenModal = (farm = null) => {
    if (farm) {
      setEditingFarm(farm);
      setFormData({
        name: farm.name,
        location: farm.location || { address: '', city: '', state: '', pincode: '' },
        size: farm.size || { value: '', unit: 'acre' },
        soilType: farm.soilType || '',
        irrigationType: farm.irrigationType || '',
        waterSource: farm.waterSource || '',
        ownership: farm.ownership || 'owned',
      });
    } else {
      setEditingFarm(null);
      setFormData({ name: '', location: { address: '', city: '', state: '', pincode: '' }, size: { value: '', unit: 'acre' }, soilType: '', irrigationType: '', waterSource: '', ownership: 'owned' });
    }
    setShowModal(true);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData(prev => ({ ...prev, [parent]: { ...prev[parent], [child]: value } }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleLocationChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, location: { ...prev.location, [name]: value } }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      if (editingFarm) {
        await axios.put(`http://localhost:5000/api/farms/${editingFarm._id}`, formData, getAuthHeaders());
        toast.success('Farm updated successfully!');
      } else {
        await axios.post('http://localhost:5000/api/farms', formData, getAuthHeaders());
        toast.success('Farm created successfully!');
      }
      setShowModal(false);
      fetchFarms();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to save farm');
    } finally { setSubmitting(false); }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Delete this farm? All associated crops will also be deleted.')) {
      try {
        await axios.delete(`http://localhost:5000/api/farms/${id}`, getAuthHeaders());
        toast.success('Farm deleted');
        fetchFarms();
      } catch { toast.error('Failed to delete farm'); }
    }
  };

  if (loading) {
    return (
      <AppLayout title="My Farms">
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '50vh', gap: 16 }}>
          <div className="spinner-amber" />
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Loading your farms...</p>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout
      title="My Farms"
      subtitle="Manage and monitor all your farming operations"
      actions={
        <button className="btn-amber" onClick={() => handleOpenModal()} style={{ padding: '8px 16px', fontSize: '0.85rem' }}>
          <FaPlus size={11} /> Add Farm
        </button>
      }
    >
      {farms.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon"><FaTractor style={{ color: 'var(--green)' }} /></div>
          <div className="empty-title">No farms yet</div>
          <div className="empty-sub">Get started by adding your first farm.</div>
          <button className="btn-amber" onClick={() => handleOpenModal()}>
            <FaPlus size={11} /> Add Your First Farm
          </button>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 16 }}>
          {farms.map((farm) => (
            <div key={farm._id} className="card-dark card-hover-lift" style={{ padding: 20 }}>
              {/* Header */}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                    <div style={{ width: 32, height: 32, background: 'var(--green-dim)', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <FaTractor style={{ color: 'var(--green)', fontSize: 13 }} />
                    </div>
                    <h4 style={{ fontWeight: 700, fontSize: '1rem', color: 'var(--text-primary)', margin: 0 }}>{farm.name}</h4>
                  </div>
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                    <span className="badge-muted" style={{ textTransform: 'capitalize' }}>
                      {farm.ownership === 'owned' ? '👑' : farm.ownership === 'leased' ? '📄' : '🤝'} {farm.ownership}
                    </span>
                    {farm.soilType && (
                      <span style={{
                        background: `${SOIL_COLORS[farm.soilType] || 'var(--text-muted)'}20`,
                        color: SOIL_COLORS[farm.soilType] || 'var(--text-muted)',
                        borderRadius: 6, padding: '3px 9px', fontSize: '0.72rem', fontWeight: 600,
                      }}>
                        {farm.soilType} soil
                      </span>
                    )}
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 6 }}>
                  <button
                    className="btn-icon"
                    style={{ background: 'var(--emerald-dim)', color: 'var(--emerald)' }}
                    onClick={() => handleOpenModal(farm)}
                    title="Edit"
                  >
                    <FaEdit size={12} />
                  </button>
                  <button
                    className="btn-icon"
                    style={{ background: 'var(--rose-dim)', color: 'var(--rose)' }}
                    onClick={() => handleDelete(farm._id)}
                    title="Delete"
                  >
                    <FaTrash size={12} />
                  </button>
                </div>
              </div>

              {/* Details */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 16 }}>
                {farm.location?.city && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <FaCity style={{ color: 'var(--sky)', fontSize: 12, flexShrink: 0 }} />
                    <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                      {farm.location.city}{farm.location.state ? `, ${farm.location.state}` : ''}
                    </span>
                  </div>
                )}
                {farm.size?.value && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <FaTractor style={{ color: 'var(--green)', fontSize: 12, flexShrink: 0 }} />
                    <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{farm.size.value} {farm.size.unit}</span>
                  </div>
                )}
                {farm.irrigationType && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <FaTint style={{ color: 'var(--sky)', fontSize: 12, flexShrink: 0 }} />
                    <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', textTransform: 'capitalize' }}>{farm.irrigationType} irrigation</span>
                  </div>
                )}
                {farm.waterSource && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <FaWater style={{ color: 'var(--sky)', fontSize: 12, flexShrink: 0 }} />
                    <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', textTransform: 'capitalize' }}>{farm.waterSource}</span>
                  </div>
                )}
              </div>

              {/* Actions */}
              <div style={{ display: 'flex', gap: 8, borderTop: '1px solid var(--border)', paddingTop: 14 }}>
                <button
                  className="btn-ghost"
                  style={{ flex: 1, padding: '7px 10px', fontSize: '0.78rem', justifyContent: 'center', color: 'var(--green)', borderColor: 'var(--green-dim)' }}
                  onClick={() => navigate(`/crops?farm=${farm._id}`)}
                >
                  <FaSeedling size={11} /> View Crops
                </button>
                <button
                  className="btn-ghost"
                  style={{ flex: 1, padding: '7px 10px', fontSize: '0.78rem', justifyContent: 'center', color: 'var(--sky)', borderColor: 'var(--sky-dim)' }}
                  onClick={() => navigate(`/analytics?farm=${farm._id}`)}
                >
                  <FaChartLine size={11} /> Analytics
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setShowModal(false)}>
          <div className="modal-dark modal-dark-lg">
            <div className="modal-header-dark">
              <span className="modal-title-dark">
                {editingFarm ? '✏️ Edit Farm' : '➕ Add New Farm'}
              </span>
              <button className="modal-close" onClick={() => setShowModal(false)}><FaTimes size={12} /></button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="modal-body-dark">
                <div className="form-group">
                  <label className="label-dark">Farm Name <span style={{ color: 'var(--rose)' }}>*</span></label>
                  <input type="text" name="name" value={formData.name} onChange={handleChange} required placeholder="e.g., Green Valley Farm" className="input-dark" />
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div className="form-group">
                    <label className="label-dark">Size</label>
                    <input type="number" name="size.value" value={formData.size.value} onChange={handleChange} placeholder="Size" className="input-dark" />
                  </div>
                  <div className="form-group">
                    <label className="label-dark">Unit</label>
                    <select name="size.unit" value={formData.size.unit} onChange={handleChange} className="input-dark">
                      <option value="acre">Acre</option>
                      <option value="hectare">Hectare</option>
                      <option value="sq-meter">Square Meter</option>
                    </select>
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div className="form-group">
                    <label className="label-dark">Soil Type</label>
                    <select name="soilType" value={formData.soilType} onChange={handleChange} className="input-dark">
                      <option value="">Select soil type</option>
                      <option value="clay">Clay</option>
                      <option value="sandy">Sandy</option>
                      <option value="loamy">Loamy</option>
                      <option value="silt">Silt</option>
                      <option value="peaty">Peaty</option>
                      <option value="chalky">Chalky</option>
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="label-dark">Irrigation Type</label>
                    <select name="irrigationType" value={formData.irrigationType} onChange={handleChange} className="input-dark">
                      <option value="">Select irrigation</option>
                      <option value="drip">Drip Irrigation</option>
                      <option value="sprinkler">Sprinkler</option>
                      <option value="flood">Flood</option>
                      <option value="rain-fed">Rain-fed</option>
                    </select>
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div className="form-group">
                    <label className="label-dark">Water Source</label>
                    <select name="waterSource" value={formData.waterSource} onChange={handleChange} className="input-dark">
                      <option value="">Select water source</option>
                      <option value="borewell">Borewell</option>
                      <option value="river">River</option>
                      <option value="canal">Canal</option>
                      <option value="rain">Rain</option>
                      <option value="pond">Pond</option>
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="label-dark">Ownership</label>
                    <select name="ownership" value={formData.ownership} onChange={handleChange} className="input-dark">
                      <option value="owned">Owned</option>
                      <option value="leased">Leased</option>
                      <option value="shared">Shared</option>
                    </select>
                  </div>
                </div>

                <div style={{ borderTop: '1px solid var(--border)', paddingTop: 16, marginTop: 4 }}>
                  <div style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 12, display: 'flex', alignItems: 'center', gap: 6 }}>
                    <FaMapMarkerAlt style={{ color: 'var(--rose)', fontSize: 12 }} /> Location (Optional)
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                    <div className="form-group">
                      <label className="label-dark">City</label>
                      <input type="text" name="city" value={formData.location.city} onChange={handleLocationChange} placeholder="City" className="input-dark" />
                    </div>
                    <div className="form-group">
                      <label className="label-dark">State</label>
                      <input type="text" name="state" value={formData.location.state} onChange={handleLocationChange} placeholder="State" className="input-dark" />
                    </div>
                  </div>
                  <div className="form-group">
                    <label className="label-dark">Pincode</label>
                    <input type="text" name="pincode" value={formData.location.pincode} onChange={handleLocationChange} placeholder="Postal code" className="input-dark" />
                  </div>
                </div>
              </div>
              <div className="modal-footer-dark">
                <button type="button" className="btn-ghost" onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn-amber" disabled={submitting} style={{ opacity: submitting ? 0.7 : 1 }}>
                  {submitting ? 'Saving...' : (editingFarm ? 'Update Farm' : 'Create Farm')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </AppLayout>
  );
};

export default FarmsPage;
