import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';
import {
  FaLeaf, FaUser, FaEnvelope, FaLock, FaPhone,
  FaEye, FaEyeSlash, FaArrowRight, FaCheckCircle,
  FaTractor, FaUserGraduate, FaCheck, FaArrowLeft
} from 'react-icons/fa';

const STEPS = [
  { id: 1, label: 'Credentials', icon: FaLock },
  { id: 2, label: 'Profile',     icon: FaUser },
  { id: 3, label: 'Role',        icon: FaTractor },
];

const getStrength = (p) => {
  if (!p) return null;
  if (p.length < 6) return { label: 'Too short', color: 'var(--rose)',  pct: 20 };
  if (p.length < 8) return { label: 'Weak',      color: 'var(--sky)',   pct: 45 };
  if (/[A-Z]/.test(p) && /[0-9]/.test(p)) return { label: 'Strong', color: 'var(--green)', pct: 100 };
  return { label: 'Fair', color: 'var(--sky)', pct: 70 };
};

const Field = ({ label, required, icon: Icon, children }) => (
  <div style={{ marginBottom: 18 }}>
    <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 8 }}>
      {label}{required && <span style={{ color: 'var(--rose)', marginLeft: 3 }}>*</span>}
    </label>
    <div style={{ position: 'relative' }}>
      {Icon && (
        <div style={{ position: 'absolute', left: 13, top: '50%', transform: 'translateY(-50%)', width: 30, height: 30, background: 'var(--green-dim)', borderRadius: 7, display: 'flex', alignItems: 'center', justifyContent: 'center', pointerEvents: 'none' }}>
          <Icon style={{ color: 'var(--green)', fontSize: 12 }} />
        </div>
      )}
      {children}
    </div>
  </div>
);

const inputStyle = (hasIcon, extra = {}) => ({
  width: '100%',
  padding: `13px 14px 13px ${hasIcon ? '53px' : '14px'}`,
  border: '1.5px solid var(--border-strong)',
  borderRadius: 12,
  fontSize: '0.9rem',
  color: 'var(--text-primary)',
  background: 'var(--bg-elevated)',
  outline: 'none',
  fontFamily: 'Inter, sans-serif',
  transition: 'all 0.2s',
  ...extra,
});

export default function Register() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [showPw, setShowPw] = useState(false);
  const [showCf, setShowCf] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', password: '', confirmPassword: '', phone: '', role: 'farmer' });

  const set = f => e => setForm(p => ({ ...p, [f]: e.target.value }));
  const strength = getStrength(form.password);
  const pwMismatch = form.confirmPassword && form.confirmPassword !== form.password;

  const canProceed = () => {
    if (step === 1) return form.email.trim() && form.password.length >= 6 && form.password === form.confirmPassword;
    if (step === 2) return form.name.trim();
    return true;
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      await axios.post('http://localhost:5000/api/auth/register', { name: form.name, email: form.email, password: form.password, phone: form.phone, role: form.role });
      toast.success('Account created! Please sign in.');
      navigate('/login');
    } catch (err) {
      toast.error(err.response?.data?.message || (err.request ? 'Cannot reach server.' : 'Registration failed.'));
    } finally { setLoading(false); }
  };

  const focusStyle = e => { e.target.style.borderColor = 'var(--green)'; e.target.style.boxShadow = '0 0 0 3px var(--green-dim)'; e.target.style.background = '#fff'; };
  const blurStyle  = e => { e.target.style.borderColor = 'var(--border-strong)'; e.target.style.boxShadow = 'none'; e.target.style.background = 'var(--bg-elevated)'; };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-base)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '40px 20px' }}>
      <div style={{ width: '100%', maxWidth: 960, display: 'grid', gridTemplateColumns: '1fr 1.1fr', gap: 0, borderRadius: 24, overflow: 'hidden', boxShadow: '0 32px 80px rgba(22,163,74,0.14)', border: '1px solid var(--border)' }}>

        {/* ── LEFT PANEL ── */}
        <div style={{ background: 'linear-gradient(160deg, var(--green-dark) 0%, var(--green) 100%)', padding: '48px 40px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', position: 'relative', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', top: -80, right: -80, width: 280, height: 280, borderRadius: '50%', background: 'rgba(255,255,255,0.06)', pointerEvents: 'none' }} />
          <div style={{ position: 'absolute', bottom: -60, left: -60, width: 220, height: 220, borderRadius: '50%', background: 'rgba(255,255,255,0.04)', pointerEvents: 'none' }} />

          <div style={{ position: 'relative', zIndex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 48 }}>
              <div style={{ width: 38, height: 38, background: 'rgba(255,255,255,0.2)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px solid rgba(255,255,255,0.3)' }}>
                <FaLeaf style={{ color: '#fff', fontSize: 16 }} />
              </div>
              <span style={{ fontWeight: 800, fontSize: '1.1rem', color: '#fff' }}>AgriTech</span>
            </div>
            <h2 style={{ fontSize: '1.9rem', fontWeight: 900, color: '#fff', lineHeight: 1.15, letterSpacing: '-0.5px', marginBottom: 12 }}>
              Start your<br />farming journey
            </h2>
            <p style={{ color: 'rgba(255,255,255,0.72)', fontSize: '0.875rem', lineHeight: 1.7, marginBottom: 36 }}>
              Join thousands of farmers using data and technology to grow more with less.
            </p>
            {/* Step indicators */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {STEPS.map(s => {
                const Icon = s.icon;
                const done = s.id < step;
                const active = s.id === step;
                return (
                  <div key={s.id} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <div style={{ width: 34, height: 34, borderRadius: '50%', background: done ? '#fff' : active ? 'rgba(255,255,255,0.25)' : 'rgba(255,255,255,0.1)', border: `2px solid ${done || active ? '#fff' : 'rgba(255,255,255,0.25)'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, transition: 'all 0.3s' }}>
                      {done ? <FaCheck style={{ color: 'var(--green)', fontSize: 12 }} /> : <Icon style={{ color: active ? '#fff' : 'rgba(255,255,255,0.5)', fontSize: 12 }} />}
                    </div>
                    <span style={{ fontSize: '0.875rem', fontWeight: active ? 700 : 500, color: active ? '#fff' : done ? 'rgba(255,255,255,0.8)' : 'rgba(255,255,255,0.45)' }}>{s.label}</span>
                    {done && <FaCheckCircle style={{ color: 'rgba(255,255,255,0.6)', fontSize: 12, marginLeft: 'auto' }} />}
                  </div>
                );
              })}
            </div>
          </div>

          <div style={{ position: 'relative', zIndex: 1, background: 'rgba(255,255,255,0.1)', borderRadius: 14, padding: '16px 18px', border: '1px solid rgba(255,255,255,0.15)', backdropFilter: 'blur(8px)' }}>
            <div style={{ display: 'flex', gap: 2, marginBottom: 8 }}>
              {[...Array(5)].map((_, i) => <span key={i} style={{ color: '#fde68a', fontSize: 12 }}>★</span>)}
            </div>
            <p style={{ fontSize: '0.82rem', color: 'rgba(255,255,255,0.85)', lineHeight: 1.6, margin: '0 0 10px', fontStyle: 'italic' }}>
              "Reduced my input costs by 30% in the first year. Best farming tool I've ever used."
            </p>
            <div style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.6)', fontWeight: 600 }}>— Pedro Villanueva, Corn Farmer</div>
          </div>
        </div>

        {/* ── RIGHT PANEL: Form ── */}
        <div style={{ background: '#fff', padding: '48px 44px', overflowY: 'auto' }}>
          <div style={{ marginBottom: 32 }}>
            <div style={{ display: 'flex', gap: 6, marginBottom: 20 }}>
              {STEPS.map(s => (
                <div key={s.id} style={{ flex: 1, height: 5, borderRadius: 99, background: s.id <= step ? 'var(--green)' : 'var(--bg-elevated)', transition: 'background 0.4s ease', border: '1px solid var(--border)' }} />
              ))}
            </div>
            <h2 style={{ fontSize: '1.5rem', fontWeight: 800, color: 'var(--text-primary)', letterSpacing: '-0.3px', marginBottom: 4 }}>
              {step === 1 ? 'Create your account' : step === 2 ? 'Tell us about yourself' : 'Choose your role'}
            </h2>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>
              Step {step} of {STEPS.length} — {STEPS[step - 1].label}
            </p>
          </div>

          {/* STEP 1 */}
          {step === 1 && (
            <div>
              <Field label="Email address" required icon={FaEnvelope}>
                <input type="email" value={form.email} onChange={set('email')} placeholder="you@example.com" style={inputStyle(true)} onFocus={focusStyle} onBlur={blurStyle} />
              </Field>
              <Field label="Password" required icon={FaLock}>
                <input type={showPw ? 'text' : 'password'} value={form.password} onChange={set('password')} placeholder="Min. 6 characters" style={inputStyle(true, { paddingRight: 44 })} onFocus={focusStyle} onBlur={blurStyle} />
                <button type="button" onClick={() => setShowPw(v => !v)} style={{ position: 'absolute', right: 14, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', padding: 0 }}>
                  {showPw ? <FaEyeSlash size={14} /> : <FaEye size={14} />}
                </button>
              </Field>
              {strength && (
                <div style={{ marginTop: -10, marginBottom: 18 }}>
                  <div style={{ height: 4, background: 'var(--bg-elevated)', borderRadius: 99, overflow: 'hidden', marginBottom: 5 }}>
                    <div style={{ height: '100%', width: `${strength.pct}%`, background: strength.color, borderRadius: 99, transition: 'width 0.4s ease' }} />
                  </div>
                  <span style={{ fontSize: '0.72rem', color: strength.color, fontWeight: 600 }}>{strength.label} password</span>
                </div>
              )}
              <Field label="Confirm password" required icon={FaLock}>
                <input type={showCf ? 'text' : 'password'} value={form.confirmPassword} onChange={set('confirmPassword')} placeholder="Repeat your password"
                  style={inputStyle(true, { paddingRight: 44, borderColor: pwMismatch ? 'var(--rose)' : undefined })}
                  onFocus={focusStyle} onBlur={blurStyle} />
                <button type="button" onClick={() => setShowCf(v => !v)} style={{ position: 'absolute', right: 14, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', padding: 0 }}>
                  {showCf ? <FaEyeSlash size={14} /> : <FaEye size={14} />}
                </button>
                {!pwMismatch && form.confirmPassword && <FaCheckCircle style={{ position: 'absolute', right: 42, top: '50%', transform: 'translateY(-50%)', color: 'var(--green)', fontSize: 13, pointerEvents: 'none' }} />}
              </Field>
              {pwMismatch && <p style={{ fontSize: '0.75rem', color: 'var(--rose)', marginTop: -10, marginBottom: 12 }}>Passwords do not match</p>}
            </div>
          )}

          {/* STEP 2 */}
          {step === 2 && (
            <div>
              <Field label="Full name" required icon={FaUser}>
                <input type="text" value={form.name} onChange={set('name')} placeholder="Your full name" style={inputStyle(true)} onFocus={focusStyle} onBlur={blurStyle} />
              </Field>
              <Field label="Phone number" icon={FaPhone}>
                <input type="tel" value={form.phone} onChange={set('phone')} placeholder="Optional" style={inputStyle(true)} onFocus={focusStyle} onBlur={blurStyle} />
              </Field>
              <div style={{ background: 'var(--green-dim)', border: '1px solid rgba(22,163,74,0.2)', borderRadius: 12, padding: '14px 16px', marginTop: 8 }}>
                <p style={{ fontSize: '0.82rem', color: 'var(--green-dark)', margin: 0, lineHeight: 1.6 }}>
                  💡 Your profile helps us personalize crop recommendations and connect you with the right experts.
                </p>
              </div>
            </div>
          )}

          {/* STEP 3 */}
          {step === 3 && (
            <div>
              <p style={{ fontSize: '0.875rem', color: 'var(--text-muted)', marginBottom: 20, lineHeight: 1.6 }}>
                Your role determines what features and tools you'll see in your dashboard.
              </p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                {[
                  { value: 'farmer', icon: FaTractor, label: 'Farmer', desc: 'I grow crops and manage farmland', emoji: '🌾', color: 'var(--green)' },
                  { value: 'expert', icon: FaUserGraduate, label: 'Agricultural Expert', desc: 'I provide advice and guidance to farmers', emoji: '👨‍🎓', color: 'var(--sky)' },
                ].map(opt => {
                  const active = form.role === opt.value;
                  return (
                    <button key={opt.value} type="button" onClick={() => setForm(p => ({ ...p, role: opt.value }))}
                      style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '18px 20px', cursor: 'pointer', textAlign: 'left', border: `2px solid ${active ? opt.color : 'var(--border-strong)'}`, borderRadius: 14, background: active ? `${opt.color}08` : '#fff', transition: 'all 0.2s ease', width: '100%' }}
                    >
                      <div style={{ fontSize: 28, width: 48, height: 48, background: active ? `${opt.color}15` : 'var(--bg-elevated)', borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, border: `1px solid ${active ? opt.color + '30' : 'var(--border)'}` }}>
                        {opt.emoji}
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontWeight: 700, fontSize: '0.95rem', color: active ? opt.color : 'var(--text-primary)', marginBottom: 3 }}>{opt.label}</div>
                        <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{opt.desc}</div>
                      </div>
                      <div style={{ width: 22, height: 22, borderRadius: '50%', border: `2px solid ${active ? opt.color : 'var(--border-strong)'}`, background: active ? opt.color : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, transition: 'all 0.2s' }}>
                        {active && <FaCheck style={{ color: '#fff', fontSize: 9 }} />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Navigation */}
          <div style={{ display: 'flex', gap: 10, marginTop: 28 }}>
            {step > 1 && (
              <button type="button" onClick={() => setStep(s => s - 1)} className="btn-ghost" style={{ padding: '13px 20px', borderRadius: 12, display: 'flex', alignItems: 'center', gap: 7 }}>
                <FaArrowLeft size={12} /> Back
              </button>
            )}
            {step < STEPS.length ? (
              <button type="button" onClick={() => setStep(s => s + 1)} disabled={!canProceed()} className="btn-amber"
                style={{ flex: 1, justifyContent: 'center', padding: '13px', borderRadius: 12, opacity: canProceed() ? 1 : 0.4, cursor: canProceed() ? 'pointer' : 'not-allowed' }}
              >
                Continue <FaArrowRight size={12} />
              </button>
            ) : (
              <button type="button" onClick={handleSubmit} disabled={loading} className="btn-amber"
                style={{ flex: 1, justifyContent: 'center', padding: '13px', borderRadius: 12, opacity: loading ? 0.75 : 1, cursor: loading ? 'not-allowed' : 'pointer' }}
              >
                {loading ? <><span style={{ width: 15, height: 15, border: '2px solid rgba(255,255,255,0.3)', borderTopColor: '#fff', borderRadius: '50%', animation: 'spin 0.8s linear infinite', display: 'inline-block' }} /> Creating...</> : <>Create Account <FaArrowRight size={12} /></>}
              </button>
            )}
          </div>

          <p style={{ textAlign: 'center', marginTop: 20, fontSize: '0.85rem', color: 'var(--text-muted)' }}>
            Already have an account?{' '}
            <Link to="/login" style={{ color: 'var(--green)', fontWeight: 700, textDecoration: 'none' }}>Sign in</Link>
          </p>
        </div>
      </div>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
