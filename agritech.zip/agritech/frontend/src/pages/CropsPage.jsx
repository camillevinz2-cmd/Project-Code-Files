import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  FaPlus, FaEdit, FaTrash, FaSeedling, FaBug,
  FaCalendarAlt, FaChartLine, FaLeaf, FaExclamationTriangle,
  FaCheckCircle, FaClock, FaTag, FaRuler, FaTimes, FaPaperPlane,
  FaInfoCircle
} from 'react-icons/fa';
import { toast } from 'react-toastify';
import axios from 'axios';
import AppLayout from '../components/Layout/AppLayout';
import { useAuth } from '../context/AuthContext';

const STAGES = ['planting', 'germination', 'vegetative', 'flowering', 'fruiting', 'maturing', 'harvesting'];

const CropsPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const [crops, setCrops] = useState([]);
  const [farms, setFarms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showIssueModal, setShowIssueModal] = useState(false);
  const [submittingIssue, setSubmittingIssue] = useState(false);
  const [editingCrop, setEditingCrop] = useState(null);
  const [selectedCrop, setSelectedCrop] = useState(null);
  const [issueData, setIssueData] = useState({ type: 'pest', description: '', severity: 'medium' });
  const [formData, setFormData] = useState({
    name: '', farm: '', variety: '', plantingDate: '',
    expectedHarvestDate: '', areaPlanted: { value: '', unit: 'acre' }, growthStage: 'planting',
  });

  const getAuthHeaders = () => ({ headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } });

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const queryParams = new URLSearchParams(location.search);
      const farmId = queryParams.get('farm');
      const [cropsRes, farmsRes] = await Promise.all([
        axios.get('http://localhost:5000/api/crops', getAuthHeaders()),
        axios.get('http://localhost:5000/api/farms', getAuthHeaders()),
      ]);
      let cropsData = cropsRes.data;
      if (farmId) cropsData = cropsData.filter(c => c.farm?._id === farmId || c.farm === farmId);
      setCrops(cropsData);
      setFarms(farmsRes.data);
    } catch { toast.error('Failed to load crops'); }
    finally { setLoading(false); }
  };

  const handleOpenModal = (crop = null) => {
    if (crop) {
      setEditingCrop(crop);
      setFormData({
        name: crop.name, farm: crop.farm?._id || crop.farm, variety: crop.variety || '',
        plantingDate: crop.plantingDate?.split('T')[0] || '',
        expectedHarvestDate: crop.expectedHarvestDate?.split('T')[0] || '',
        areaPlanted: crop.areaPlanted || { value: '', unit: 'acre' },
        growthStage: crop.growthStage,
      });
    } else {
      setEditingCrop(null);
      setFormData({ name: '', farm: '', variety: '', plantingDate: '', expectedHarvestDate: '', areaPlanted: { value: '', unit: 'acre' }, growthStage: 'planting' });
    }
    setShowModal(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingCrop) {
        await axios.put(`http://localhost:5000/api/crops/${editingCrop._id}`, formData, getAuthHeaders());
        toast.success('Crop updated!');
      } else {
        await axios.post('http://localhost:5000/api/crops', formData, getAuthHeaders());
        toast.success('Crop added!');
      }
      setShowModal(false);
      fetchData();
    } catch (error) { toast.error(error.response?.data?.message || 'Operation failed'); }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Delete this crop?')) {
      try {
        await axios.delete(`http://localhost:5000/api/crops/${id}`, getAuthHeaders());
        toast.success('Crop deleted');
        fetchData();
      } catch { toast.error('Failed to delete crop'); }
    }
  };

  const handleStageChange = async (cropId, newStage) => {
    try {
      await axios.put(`http://localhost:5000/api/crops/${cropId}/growth-stage`, { growthStage: newStage }, getAuthHeaders());
      toast.success(`Stage updated to ${newStage}`);
      fetchData();
    } catch { toast.error('Failed to update stage'); }
  };

  const handleReportIssue = async (e) => {
    e.preventDefault();
    if (!issueData.description.trim()) { toast.error('Please provide a description'); return; }
    setSubmittingIssue(true);
    try {
      await axios.post(`http://localhost:5000/api/crops/${selectedCrop._id}/report-issue`,
        { type: issueData.type, issue: issueData.description, severity: issueData.severity },
        { headers: { Authorization: `Bearer ${localStorage.getItem('token')}`, 'Content-Type': 'application/json' } }
      );
      toast.success('Issue reported! Experts will review it.');
      setIssueData({ type: 'pest', description: '', severity: 'medium' });
      setShowIssueModal(false);
      setSelectedCrop(null);
      fetchData();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to report issue.');
    } finally { setSubmittingIssue(false); }
  };

  const getGrowthProgress = (stage) => ((STAGES.indexOf(stage) + 1) / STAGES.length) * 100;

  const getHealthBadge = (h) => ({
    excellent: 'badge-emerald', good: 'badge-emerald',
    fair: 'badge-amber', poor: 'badge-rose', critical: 'badge-rose',
  }[h] || 'badge-muted');

  if (loading) {
    return (
      <AppLayout title="My Crops">
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '50vh', gap: 16 }}>
          <div className="spinner-amber" />
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Loading crops...</p>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout
      title="My Crops"
      subtitle="Track and monitor your crop growth"
      actions={
        <button className="btn-amber" onClick={() => handleOpenModal()} disabled={farms.length === 0} style={{ padding: '8px 16px', fontSize: '0.85rem' }}>
          <FaPlus size={11} /> Add Crop
        </button>
      }
    >
      {farms.length === 0 && (
        <div className="alert-dark alert-amber" style={{ marginBottom: 20 }}>
          <FaExclamationTriangle size={14} />
          <span>Please add a farm before adding crops.</span>
        </div>
      )}

      {crops.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon"><FaSeedling style={{ color: 'var(--emerald)' }} /></div>
          <div className="empty-title">No crops yet</div>
          <div className="empty-sub">Start tracking your first crop.</div>
          {farms.length > 0 && (
            <button className="btn-amber" onClick={() => handleOpenModal()}>
              <FaPlus size={11} /> Add Your First Crop
            </button>
          )}
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 16 }}>
          {crops.map((crop) => (
            <div key={crop._id} className="card-dark card-hover-lift" style={{ padding: 20 }}>
              {/* Header */}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                    <div style={{ width: 30, height: 30, background: 'var(--emerald-dim)', borderRadius: 7, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <FaSeedling style={{ color: 'var(--emerald)', fontSize: 12 }} />
                    </div>
                    <h5 style={{ fontWeight: 700, fontSize: '0.95rem', color: 'var(--text-primary)', margin: 0 }}>{crop.name}</h5>
                  </div>
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                    <span className={getHealthBadge(crop.health)}>{crop.health}</span>
                    <span className="badge-muted" style={{ textTransform: 'capitalize' }}>{crop.growthStage}</span>
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 6 }}>
                  <button className="btn-icon" style={{ background: 'var(--emerald-dim)', color: 'var(--emerald)' }} onClick={() => handleOpenModal(crop)} title="Edit"><FaEdit size={11} /></button>
                  <button className="btn-icon" style={{ background: 'var(--rose-dim)', color: 'var(--rose)' }} onClick={() => handleDelete(crop._id)} title="Delete"><FaTrash size={11} /></button>
                </div>
              </div>

              {/* Progress */}
              <div style={{ marginBottom: 14 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
                  <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Growth Progress</span>
                  <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{Math.round(getGrowthProgress(crop.growthStage))}%</span>
                </div>
                <div className="progress-dark">
                  <div className="progress-fill progress-fill-emerald" style={{ width: `${getGrowthProgress(crop.growthStage)}%` }} />
                </div>
              </div>

              {/* Details */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: 5, marginBottom: 14 }}>
                {crop.variety && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                    <FaTag style={{ color: 'var(--green)', fontSize: 11, flexShrink: 0 }} />
                    <span style={{ fontSize: '0.78rem', color: 'var(--text-secondary)' }}>Variety: {crop.variety}</span>
                  </div>
                )}
                <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                  <FaCalendarAlt style={{ color: 'var(--sky)', fontSize: 11, flexShrink: 0 }} />
                  <span style={{ fontSize: '0.78rem', color: 'var(--text-secondary)' }}>Planted: {new Date(crop.plantingDate).toLocaleDateString()}</span>
                </div>
                {crop.expectedHarvestDate && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                    <FaCheckCircle style={{ color: 'var(--emerald)', fontSize: 11, flexShrink: 0 }} />
                    <span style={{ fontSize: '0.78rem', color: 'var(--text-secondary)' }}>Harvest: {new Date(crop.expectedHarvestDate).toLocaleDateString()}</span>
                  </div>
                )}
                {crop.areaPlanted?.value && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                    <FaRuler style={{ color: 'var(--violet)', fontSize: 11, flexShrink: 0 }} />
                    <span style={{ fontSize: '0.78rem', color: 'var(--text-secondary)' }}>Area: {crop.areaPlanted.value} {crop.areaPlanted.unit}</span>
                  </div>
                )}
              </div>

              {/* Alert */}
              {crop.alerts?.length > 0 && (
                <div className="alert-dark alert-rose" style={{ marginBottom: 12, padding: '8px 12px' }}>
                  <FaExclamationTriangle size={11} />
                  <span style={{ fontSize: '0.78rem' }}>{crop.alerts[0].message || `${crop.alerts.length} alert(s) need attention`}</span>
                </div>
              )}

              {/* Actions */}
              <div style={{ display: 'flex', gap: 8, borderTop: '1px solid var(--border)', paddingTop: 12 }}>
                <button
                  className="btn-ghost"
                  style={{ flex: 1, padding: '7px 8px', fontSize: '0.75rem', justifyContent: 'center', color: 'var(--rose)', borderColor: 'var(--rose-dim)' }}
                  onClick={() => { setSelectedCrop(crop); setIssueData({ type: 'pest', description: '', severity: 'medium' }); setShowIssueModal(true); }}
                >
                  <FaBug size={11} /> Report Issue
                </button>
                <button
                  className="btn-ghost"
                  style={{ flex: 1, padding: '7px 8px', fontSize: '0.75rem', justifyContent: 'center', color: 'var(--green)', borderColor: 'var(--green-dim)' }}
                  onClick={() => {
                    const idx = STAGES.indexOf(crop.growthStage);
                    if (idx < STAGES.length - 1) handleStageChange(crop._id, STAGES[idx + 1]);
                    else toast.info('Already in harvesting stage');
                  }}
                >
                  <FaChartLine size={11} /> Next Stage
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setShowModal(false)}>
          <div className="modal-dark modal-dark-lg">
            <div className="modal-header-dark">
              <span className="modal-title-dark">{editingCrop ? '✏️ Edit Crop' : '➕ Add New Crop'}</span>
              <button className="modal-close" onClick={() => setShowModal(false)}><FaTimes size={12} /></button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="modal-body-dark">
                <div className="form-group">
                  <label className="label-dark">Crop Name <span style={{ color: 'var(--rose)' }}>*</span></label>
                  <input type="text" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} required placeholder="e.g., Rice, Wheat, Tomato" className="input-dark" />
                </div>
                <div className="form-group">
                  <label className="label-dark">Farm <span style={{ color: 'var(--rose)' }}>*</span></label>
                  <select value={formData.farm} onChange={(e) => setFormData({ ...formData, farm: e.target.value })} required className="input-dark">
                    <option value="">Select farm</option>
                    {farms.map(f => <option key={f._id} value={f._id}>{f.name}</option>)}
                  </select>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div className="form-group">
                    <label className="label-dark">Variety</label>
                    <input type="text" value={formData.variety} onChange={(e) => setFormData({ ...formData, variety: e.target.value })} placeholder="e.g., Hybrid, Local" className="input-dark" />
                  </div>
                  <div className="form-group">
                    <label className="label-dark">Planting Date <span style={{ color: 'var(--rose)' }}>*</span></label>
                    <input type="date" value={formData.plantingDate} onChange={(e) => setFormData({ ...formData, plantingDate: e.target.value })} required className="input-dark" />
                  </div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div className="form-group">
                    <label className="label-dark">Expected Harvest</label>
                    <input type="date" value={formData.expectedHarvestDate} onChange={(e) => setFormData({ ...formData, expectedHarvestDate: e.target.value })} className="input-dark" />
                  </div>
                  <div className="form-group">
                    <label className="label-dark">Growth Stage</label>
                    <select value={formData.growthStage} onChange={(e) => setFormData({ ...formData, growthStage: e.target.value })} className="input-dark">
                      {STAGES.map(s => <option key={s} value={s} style={{ textTransform: 'capitalize' }}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
                    </select>
                  </div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div className="form-group">
                    <label className="label-dark">Area Planted</label>
                    <input type="number" value={formData.areaPlanted.value} onChange={(e) => setFormData({ ...formData, areaPlanted: { ...formData.areaPlanted, value: e.target.value } })} placeholder="Area" className="input-dark" />
                  </div>
                  <div className="form-group">
                    <label className="label-dark">Unit</label>
                    <select value={formData.areaPlanted.unit} onChange={(e) => setFormData({ ...formData, areaPlanted: { ...formData.areaPlanted, unit: e.target.value } })} className="input-dark">
                      <option value="acre">Acre</option>
                      <option value="hectare">Hectare</option>
                      <option value="sq-meter">Square Meter</option>
                    </select>
                  </div>
                </div>
              </div>
              <div className="modal-footer-dark">
                <button type="button" className="btn-ghost" onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn-amber">{editingCrop ? 'Update' : 'Add'} Crop</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Report Issue Modal */}
      {showIssueModal && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setShowIssueModal(false)}>
          <div className="modal-dark">
            <div className="modal-header-dark">
              <span className="modal-title-dark">🐛 Report Issue — {selectedCrop?.name}</span>
              <button className="modal-close" onClick={() => setShowIssueModal(false)}><FaTimes size={12} /></button>
            </div>
            <form onSubmit={handleReportIssue}>
              <div className="modal-body-dark">
                <div className="form-group">
                  <label className="label-dark">Issue Type</label>
                  <select value={issueData.type} onChange={(e) => setIssueData({ ...issueData, type: e.target.value })} className="input-dark">
                    <option value="pest">🐛 Pest Infestation</option>
                    <option value="disease">🦠 Disease</option>
                    <option value="nutrient">🌿 Nutrient Deficiency</option>
                    <option value="water">💧 Water Issue</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="label-dark">Description <span style={{ color: 'var(--rose)' }}>*</span></label>
                  <textarea
                    rows={4}
                    value={issueData.description}
                    onChange={(e) => setIssueData({ ...issueData, description: e.target.value })}
                    placeholder="Describe the issue in detail..."
                    required
                    className="input-dark"
                    style={{ resize: 'vertical' }}
                  />
                </div>
                <div className="form-group">
                  <label className="label-dark">Severity Level</label>
                  <select value={issueData.severity} onChange={(e) => setIssueData({ ...issueData, severity: e.target.value })} className="input-dark">
                    <option value="low">🟢 Low — Minor issue, isolated spots</option>
                    <option value="medium">🟡 Medium — Spreading, needs attention</option>
                    <option value="high">🔴 High — Widespread, urgent action needed</option>
                  </select>
                </div>
                <div className="alert-dark alert-sky">
                  <FaInfoCircle size={13} />
                  <span>Our agricultural experts will review your report and provide recommendations within 24 hours.</span>
                </div>
              </div>
              <div className="modal-footer-dark">
                <button type="button" className="btn-ghost" onClick={() => setShowIssueModal(false)}>Cancel</button>
                <button type="submit" className="btn-amber" disabled={submittingIssue || !issueData.description.trim()} style={{ opacity: submittingIssue ? 0.7 : 1 }}>
                  {submittingIssue ? 'Submitting...' : <><FaPaperPlane size={11} /> Submit Report</>}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </AppLayout>
  );
};

export default CropsPage;
