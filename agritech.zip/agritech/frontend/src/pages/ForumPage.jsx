﻿import React, { useState, useEffect } from 'react';
import {
  FaPlus, FaSearch, FaThumbsUp, FaComment, FaEye,
  FaUserCircle, FaCheckCircle, FaFire, FaClock,
  FaLeaf, FaPaperPlane, FaTimes
} from 'react-icons/fa';
import { getForumPosts, createPost, likePost, getPostById, addComment } from '../services/forumService';
import AppLayout from '../components/Layout/AppLayout';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import moment from 'moment';

const CATEGORIES = [
  { value: 'all',            label: 'All Topics',        icon: '📋', color: 'var(--text-muted)' },
  { value: 'general',        label: 'General',           icon: '💬', color: 'var(--emerald)' },
  { value: 'crops',          label: 'Crop Management',   icon: '🌾', color: 'var(--green)' },
  { value: 'pests-diseases', label: 'Pests & Diseases',  icon: '🐛', color: 'var(--rose)' },
  { value: 'irrigation',     label: 'Irrigation',        icon: '💧', color: 'var(--sky)' },
  { value: 'soil-health',    label: 'Soil Health',       icon: '🌱', color: 'var(--teal)' },
  { value: 'market',         label: 'Market & Pricing',  icon: '💰', color: 'var(--emerald)' },
  { value: 'equipment',      label: 'Equipment & Tools', icon: '🔧', color: 'var(--violet)' },
];

const getCatMeta = (value) => CATEGORIES.find(c => c.value === value) || CATEGORIES[1];

const ForumPage = () => {
  const { user } = useAuth();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('newest');
  const [formData, setFormData] = useState({ title: '', content: '', category: 'general' });
  const [submitting, setSubmitting] = useState(false);
  const [selectedPost, setSelectedPost] = useState(null);
  const [postComments, setPostComments] = useState([]);
  const [showPostModal, setShowPostModal] = useState(false);
  const [loadingPost, setLoadingPost] = useState(false);
  const [newComment, setNewComment] = useState('');
  const [postingComment, setPostingComment] = useState(false);

  useEffect(() => { fetchPosts(); }, [selectedCategory, searchTerm, sortBy]);

  const fetchPosts = async () => {
    setLoading(true);
    try {
      const filters = { category: selectedCategory };
      if (searchTerm) filters.search = searchTerm;
      if (sortBy === 'popular') filters.sort = 'popular';
      const data = await getForumPosts(filters);
      setPosts(data);
    } catch { toast.error('Failed to load forum posts'); }
    finally { setLoading(false); }
  };

  const handleCreatePost = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await createPost(formData);
      toast.success('Discussion posted!');
      setShowCreateModal(false);
      setFormData({ title: '', content: '', category: 'general' });
      fetchPosts();
    } catch { toast.error('Failed to create post'); }
    finally { setSubmitting(false); }
  };

  const handleLike = async (e, postId) => {
    e.stopPropagation();
    try { await likePost(postId); fetchPosts(); }
    catch { toast.error('Failed to like post'); }
  };

  const handleViewPost = async (post) => {
    setSelectedPost(post);
    setShowPostModal(true);
    setLoadingPost(true);
    try {
      const data = await getPostById(post._id);
      setSelectedPost(data.post || post);
      setPostComments(data.comments || []);
    } catch { setPostComments([]); }
    finally { setLoadingPost(false); }
  };

  const handlePostComment = async (e) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    setPostingComment(true);
    try {
      await addComment(selectedPost._id, newComment);
      toast.success('Comment posted!');
      setNewComment('');
      const data = await getPostById(selectedPost._id);
      setPostComments(data.comments || []);
    } catch { toast.error('Failed to post comment'); }
    finally { setPostingComment(false); }
  };

  return (
    <AppLayout
      title="Community Forum"
      subtitle={`Connect with farmers and agricultural experts · ${posts.length} discussions`}
      actions={
        <button className="btn-amber" onClick={() => setShowCreateModal(true)} style={{ padding: '8px 16px', fontSize: '0.85rem' }}>
          <FaPlus size={11} /> New Discussion
        </button>
      }
    >
      <div style={{ display: 'grid', gridTemplateColumns: '200px 1fr', gap: 20 }}>
        {/* Sidebar */}
        <div className="card-dark" style={{ padding: 12, alignSelf: 'start', position: 'sticky', top: 80 }}>
          <div style={{ fontSize: '0.65rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.8px', color: 'var(--text-muted)', padding: '4px 8px 8px', marginBottom: 4 }}>
            Categories
          </div>
          {CATEGORIES.map(cat => (
            <button
              key={cat.value}
              onClick={() => setSelectedCategory(cat.value)}
              style={{
                display: 'flex', alignItems: 'center', gap: 8,
                width: '100%', padding: '8px 10px', marginBottom: 2,
                border: 'none', borderRadius: 7, cursor: 'pointer',
                background: selectedCategory === cat.value ? 'var(--green-dim)' : 'transparent',
                color: selectedCategory === cat.value ? 'var(--green)' : 'var(--text-secondary)',
                fontWeight: selectedCategory === cat.value ? 600 : 400,
                fontSize: '0.82rem', transition: 'all 0.15s ease', textAlign: 'left',
              }}
            >
              <span style={{ fontSize: 13 }}>{cat.icon}</span>
              <span>{cat.label}</span>
            </button>
          ))}
        </div>

        {/* Main */}
        <div>
          {/* Search + Sort */}
          <div style={{ display: 'flex', gap: 10, marginBottom: 16, flexWrap: 'wrap' }}>
            <div style={{ position: 'relative', flex: 1, minWidth: 200 }}>
              <FaSearch style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)', fontSize: 12 }} />
              <input
                type="text"
                placeholder="Search discussions..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="input-dark"
                style={{ paddingLeft: 36 }}
              />
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              {[
                { value: 'newest', label: 'Newest', icon: FaClock },
                { value: 'popular', label: 'Popular', icon: FaFire },
              ].map(opt => {
                const Icon = opt.icon;
                return (
                  <button
                    key={opt.value}
                    onClick={() => setSortBy(opt.value)}
                    className={sortBy === opt.value ? 'btn-amber' : 'btn-ghost'}
                    style={{ padding: '9px 14px', fontSize: '0.82rem' }}
                  >
                    <Icon size={11} /> {opt.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Posts */}
          {loading ? (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '60px 0', gap: 16 }}>
              <div className="spinner-amber" />
              <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Loading discussions...</p>
            </div>
          ) : posts.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon"><FaComment style={{ color: 'var(--text-muted)' }} /></div>
              <div className="empty-title">No discussions yet</div>
              <div className="empty-sub">Be the first to start a conversation!</div>
              <button className="btn-amber" onClick={() => setShowCreateModal(true)}>
                <FaPlus size={11} /> Start Discussion
              </button>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {posts.map(post => {
                const cat = getCatMeta(post.category);
                return (
                  <div
                    key={post._id}
                    className="card-dark card-hover-lift"
                    style={{ padding: 18, cursor: 'pointer' }}
                    onClick={() => handleViewPost(post)}
                  >
                    <div style={{ display: 'flex', gap: 12 }}>
                      <div style={{
                        width: 38, height: 38, borderRadius: '50%', flexShrink: 0,
                        background: 'var(--bg-elevated)',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                      }}>
                        <FaUserCircle style={{ color: 'var(--text-muted)', fontSize: 20 }} />
                      </div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6, flexWrap: 'wrap' }}>
                          <span style={{
                            background: `${cat.color}20`, color: cat.color,
                            borderRadius: 6, padding: '2px 8px', fontSize: '0.72rem', fontWeight: 600,
                          }}>
                            {cat.icon} {cat.label}
                          </span>
                          {post.isResolved && (
                            <span className="badge-emerald"><FaCheckCircle size={9} style={{ marginRight: 3 }} />Resolved</span>
                          )}
                          <span style={{ marginLeft: 'auto', fontSize: '0.72rem', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>
                            {moment(post.createdAt).fromNow()}
                          </span>
                        </div>
                        <h6 style={{ fontWeight: 600, marginBottom: 4, color: 'var(--text-primary)', fontSize: '0.95rem' }}>
                          {post.title}
                        </h6>
                        <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginBottom: 10, lineHeight: 1.5 }}>
                          {post.content?.length > 120 ? post.content.substring(0, 120) + '...' : post.content}
                        </p>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                          <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                            by <strong style={{ color: 'var(--text-secondary)' }}>{post.user?.name || 'Farmer'}</strong>
                          </span>
                          <div style={{ display: 'flex', gap: 12, marginLeft: 'auto' }}>
                            <button
                              onClick={e => handleLike(e, post._id)}
                              style={{ display: 'flex', alignItems: 'center', gap: 4, background: 'none', border: 'none', cursor: 'pointer', color: 'var(--green)', fontSize: '0.78rem', padding: 0 }}
                            >
                              <FaThumbsUp size={11} /> {post.likes?.length || 0}
                            </button>
                            <span style={{ display: 'flex', alignItems: 'center', gap: 4, color: 'var(--text-muted)', fontSize: '0.78rem' }}>
                              <FaComment size={11} /> {post.commentCount || 0}
                            </span>
                            <span style={{ display: 'flex', alignItems: 'center', gap: 4, color: 'var(--text-muted)', fontSize: '0.78rem' }}>
                              <FaEye size={11} /> {post.views || 0}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Create Post Modal */}
      {showCreateModal && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setShowCreateModal(false)}>
          <div className="modal-dark modal-dark-lg">
            <div className="modal-header-dark">
              <span className="modal-title-dark">💬 Start a New Discussion</span>
              <button className="modal-close" onClick={() => setShowCreateModal(false)}><FaTimes size={12} /></button>
            </div>
            <form onSubmit={handleCreatePost}>
              <div className="modal-body-dark">
                <div className="form-group">
                  <label className="label-dark">Title <span style={{ color: 'var(--rose)' }}>*</span></label>
                  <input type="text" placeholder="What's your question or topic?" value={formData.title} onChange={e => setFormData({ ...formData, title: e.target.value })} required className="input-dark" />
                </div>
                <div className="form-group">
                  <label className="label-dark">Category</label>
                  <select value={formData.category} onChange={e => setFormData({ ...formData, category: e.target.value })} className="input-dark">
                    {CATEGORIES.filter(c => c.value !== 'all').map(cat => (
                      <option key={cat.value} value={cat.value}>{cat.icon} {cat.label}</option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label className="label-dark">Content <span style={{ color: 'var(--rose)' }}>*</span></label>
                  <textarea
                    rows={6}
                    placeholder="Describe your question or share your experience..."
                    value={formData.content}
                    onChange={e => setFormData({ ...formData, content: e.target.value })}
                    required
                    className="input-dark"
                    style={{ resize: 'vertical' }}
                  />
                  <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: 4 }}>
                    {formData.content.length} / 2000 characters
                  </div>
                </div>
              </div>
              <div className="modal-footer-dark">
                <button type="button" className="btn-ghost" onClick={() => setShowCreateModal(false)}>Cancel</button>
                <button type="submit" className="btn-amber" disabled={submitting} style={{ opacity: submitting ? 0.7 : 1 }}>
                  {submitting ? 'Posting...' : <><FaPaperPlane size={11} /> Post Discussion</>}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Post Detail Modal */}
      {showPostModal && selectedPost && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setShowPostModal(false)}>
          <div className="modal-dark modal-dark-lg" style={{ maxHeight: '85vh', display: 'flex', flexDirection: 'column' }}>
            <div className="modal-header-dark">
              <div style={{ flex: 1, paddingRight: 12 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6, flexWrap: 'wrap' }}>
                  {(() => {
                    const cat = getCatMeta(selectedPost.category);
                    return (
                      <span style={{ background: `${cat.color}20`, color: cat.color, borderRadius: 6, padding: '2px 8px', fontSize: '0.72rem', fontWeight: 600 }}>
                        {cat.icon} {cat.label}
                      </span>
                    );
                  })()}
                  {selectedPost.isResolved && <span className="badge-emerald"><FaCheckCircle size={9} style={{ marginRight: 3 }} />Resolved</span>}
                </div>
                <div className="modal-title-dark" style={{ fontSize: '0.95rem' }}>{selectedPost.title}</div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: 4 }}>
                  by <strong>{selectedPost.user?.name}</strong> · {moment(selectedPost.createdAt).fromNow()} · <FaEye size={10} style={{ marginRight: 3 }} />{selectedPost.views || 0} views
                </div>
              </div>
              <button className="modal-close" onClick={() => { setShowPostModal(false); setSelectedPost(null); setPostComments([]); }}><FaTimes size={12} /></button>
            </div>

            <div style={{ flex: 1, overflowY: 'auto' }}>
              {/* Post body */}
              <div style={{ padding: '16px 24px', borderBottom: '1px solid var(--border)' }}>
                <p style={{ fontSize: '0.9rem', lineHeight: 1.75, color: 'var(--text-secondary)', whiteSpace: 'pre-wrap' }}>
                  {selectedPost.content}
                </p>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 12 }}>
                  <button
                    onClick={e => handleLike(e, selectedPost._id)}
                    className="btn-ghost"
                    style={{ padding: '6px 14px', fontSize: '0.82rem', color: 'var(--green)', borderColor: 'var(--green-dim)' }}
                  >
                    <FaThumbsUp size={12} /> {selectedPost.likes?.length || 0} Likes
                  </button>
                  <span style={{ color: 'var(--text-muted)', fontSize: '0.82rem' }}>
                    <FaComment size={12} style={{ marginRight: 4 }} />{postComments.length} comment{postComments.length !== 1 ? 's' : ''}
                  </span>
                </div>
              </div>

              {/* Comments */}
              <div style={{ padding: '16px 24px' }}>
                <div style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--text-primary)', marginBottom: 12 }}>
                  Comments ({postComments.length})
                </div>
                {loadingPost ? (
                  <div style={{ textAlign: 'center', padding: '20px 0' }}>
                    <div className="spinner-amber" style={{ margin: '0 auto' }} />
                  </div>
                ) : postComments.length === 0 ? (
                  <p style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.875rem', padding: '20px 0' }}>
                    No comments yet. Be the first to reply!
                  </p>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 16 }}>
                    {postComments.map(comment => (
                      <div key={comment._id} style={{
                        display: 'flex', gap: 10,
                        padding: '12px 14px',
                        background: comment.isExpertAnswer ? 'var(--emerald-dim)' : 'var(--bg-elevated)',
                        borderRadius: 10,
                        border: comment.isExpertAnswer ? '1px solid rgba(16,185,129,0.3)' : '1px solid var(--border)',
                      }}>
                        <div style={{ width: 30, height: 30, borderRadius: '50%', background: 'var(--bg-hover)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                          <FaUserCircle style={{ color: 'var(--text-muted)', fontSize: 16 }} />
                        </div>
                        <div style={{ flex: 1 }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4, flexWrap: 'wrap' }}>
                            <strong style={{ fontSize: '0.82rem', color: 'var(--text-primary)' }}>{comment.user?.name}</strong>
                            {comment.user?.role === 'expert' && <span className="badge-sky">Expert</span>}
                            {comment.isExpertAnswer && <span className="badge-emerald"><FaCheckCircle size={9} style={{ marginRight: 3 }} />Best Answer</span>}
                            <span style={{ marginLeft: 'auto', fontSize: '0.72rem', color: 'var(--text-muted)' }}>{moment(comment.createdAt).fromNow()}</span>
                          </div>
                          <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.6 }}>{comment.content}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Reply box */}
                <form onSubmit={handlePostComment} style={{ display: 'flex', gap: 8, alignItems: 'flex-end' }}>
                  <textarea
                    rows={2}
                    placeholder="Write a reply..."
                    value={newComment}
                    onChange={e => setNewComment(e.target.value)}
                    className="input-dark"
                    style={{ flex: 1, resize: 'none' }}
                  />
                  <button
                    type="submit"
                    className="btn-amber"
                    disabled={postingComment || !newComment.trim()}
                    style={{ padding: '10px 14px', flexShrink: 0, opacity: postingComment ? 0.7 : 1 }}
                  >
                    {postingComment ? '...' : <FaPaperPlane size={13} />}
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}
    </AppLayout>
  );
};

export default ForumPage;
