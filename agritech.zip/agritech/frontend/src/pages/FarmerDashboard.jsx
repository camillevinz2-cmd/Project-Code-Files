import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  FaTractor, FaSeedling, FaLeaf, FaExclamationTriangle,
  FaArrowRight, FaCheckCircle, FaPlus, FaBell, FaRocket,
  FaComments, FaStore, FaChartLine, FaCalendarAlt, FaEllipsisH
} from 'react-icons/fa';
import AppLayout from '../components/Layout/AppLayout';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';
import WeatherWidget from '../components/Dashboard/WeatherWidget';

const GROWTH_STAGES = ['planting','germination','vegetative','flowering','fruiting','maturing','harvesting'];

export default function FarmerDashboard() {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const [stats, setStats] = useState({ farms: 0, crops: 0, activeCrops: 0, alerts: 0 });
  const [loading, setLoading] = useState(true);
  const [recentCrops, setRecentCrops] = useState([]);
  const [recentAlerts, setRecentAlerts] = useState([]);

  const getAuthHeaders = () => ({ headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } });

  useEffect(() => {
    if (!isAuthenticated) { navigate('/login'); return; }
    fetchDashboardData();
  }, [isAuthenticated]);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const [farmsRes, cropsRes] = await Promise.all([
        axios.get('http://localhost:5000/api/farms', getAuthHeaders()),
        axios.get('http://localhost:5000/api/crops', getAuthHeaders()),
      ]);
      const farms = farmsRes.data || [];
      const crops = cropsRes.data || [];
      const activeCrops = crops.filter(c => c.growthStage !== 'harvesting' && c.growthStage !== 'fallow').length;
      const allAlerts = crops.flatMap(crop => (crop.alerts || []).map(a => ({ ...a, cropName: crop.name }))).slice(0, 3);
      setStats({ farms: farms.length, crops: crops.length, activeCrops, alerts: allAlerts.length });
      setRecentCrops(crops.slice(0, 4));
      setRecentAlerts(allAlerts);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const getHealthBadgeClass = h => ({ excellent: 'badge-emerald', good: 'badge-emerald', fair: 'badge-amber', poor: 'badge-rose', critical: 'badge-rose' }[h] || 'badge-muted');
  const getGrowthPct = stage => ((GROWTH_STAGES.indexOf(stage) + 1) / GROWTH_STAGES.length) * 100;
  const userName = user?.name?.split(' ')[0] || 'Farmer';
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  const statCards = [
    { icon: FaTractor,            title: 'Total Farms',   value: stats.farms,       link: '/farms',  color: 'var(--green)',   bg: 'var(--green-dim)',   trend: '+0' },
    { icon: FaSeedling,           title: 'Total Crops',   value: stats.crops,       link: '/crops',  color: 'var(--emerald)', bg: 'var(--emerald-dim)', trend: '+0' },
    { icon: FaLeaf,               title: 'Active Crops',  value: stats.activeCrops, link: '/crops',  color: 'var(--sky)',     bg: 'var(--sky-dim)',     trend: '+0' },
    { icon: FaExclamationTriangle,title: 'Alerts',        value: stats.alerts,      link: '/crops',  color: 'var(--rose)',    bg: 'var(--rose-dim)',    trend: '' },
  ];

  const quickActions = [
    { name: 'Add Farm',    icon: '🚜', link: '/farms',       color: 'var(--green)',   bg: 'var(--green-dim)' },
    { name: 'Add Crop',    icon: '🌾', link: '/crops',       color: 'var(--emerald)', bg: 'var(--emerald-dim)' },
    { name: 'Forum',       icon: '💬', link: '/forum',       color: 'var(--violet)',  bg: 'var(--violet-dim)' },
    { name: 'Marketplace', icon: '🛒', link: '/marketplace', color: 'var(--sky)',     bg: 'var(--sky-dim)' },
    { name: 'Analytics',   icon: '📊', link: '/analytics',   color: 'var(--teal)',    bg: 'var(--teal-dim)' },
    { name: 'Profile',     icon: '👤', link: '/profile',     color: 'var(--violet)',  bg: 'var(--violet-dim)' },
  ];

  if (loading) {
    return (
      <AppLayout title="Dashboard">
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '60vh', gap: 16 }}>
          <div className="spinner-amber" />
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Loading your dashboard...</p>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout
      title={`${greeting}, ${userName} 👋`}
      subtitle={`${new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}`}
      actions={
        <div style={{ display: 'flex', gap: 8 }}>
          <Link to="/farms" className="btn-ghost" style={{ padding: '7px 14px', fontSize: '0.82rem' }}>
            <FaTractor size={12} /> Farms
          </Link>
          <Link to="/crops" className="btn-amber" style={{ padding: '7px 16px', fontSize: '0.82rem' }}>
            <FaPlus size={11} /> Add Crop
          </Link>
        </div>
      }
    >
      {/* ── STAT CARDS ── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>
        {statCards.map((card, i) => {
          const Icon = card.icon;
          return (
            <div key={i} onClick={() => navigate(card.link)} style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 16, padding: '20px', cursor: 'pointer', transition: 'all 0.2s', position: 'relative', overflow: 'hidden' }}
              onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-3px)'; e.currentTarget.style.boxShadow = '0 12px 32px rgba(22,163,74,0.12)'; e.currentTarget.style.borderColor = 'var(--border-strong)'; }}
              onMouseLeave={e => { e.currentTarget.style.transform = 'none'; e.currentTarget.style.boxShadow = 'none'; e.currentTarget.style.borderColor = 'var(--border)'; }}
            >
              <div style={{ position: 'absolute', top: 0, right: 0, width: 80, height: 80, background: card.bg, borderRadius: '0 16px 0 80px', opacity: 0.6 }} />
              <div style={{ width: 40, height: 40, background: card.bg, borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 14, border: `1px solid ${card.color}25` }}>
                <Icon style={{ color: card.color, fontSize: 16 }} />
              </div>
              <div style={{ fontSize: '2rem', fontWeight: 900, color: 'var(--text-primary)', lineHeight: 1, marginBottom: 4 }}>{card.value}</div>
              <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', fontWeight: 500 }}>{card.title}</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 10, color: card.color, fontSize: '0.72rem', fontWeight: 600 }}>
                View all <FaArrowRight size={9} />
              </div>
            </div>
          );
        })}
      </div>

      {/* ── MAIN GRID ── */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: 20, marginBottom: 20 }}>

        {/* LEFT: Recent Crops */}
        <div style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 16, overflow: 'hidden' }}>
          <div style={{ padding: '18px 20px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'linear-gradient(135deg, #f0fdf4, #fff)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ width: 32, height: 32, background: 'var(--emerald-dim)', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <FaSeedling style={{ color: 'var(--emerald)', fontSize: 13 }} />
              </div>
              <div>
                <div style={{ fontWeight: 700, fontSize: '0.9rem', color: 'var(--text-primary)' }}>Recent Crops</div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{recentCrops.length} crops tracked</div>
              </div>
            </div>
            <Link to="/crops" style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: '0.78rem', color: 'var(--green)', textDecoration: 'none', fontWeight: 600, background: 'var(--green-dim)', padding: '5px 12px', borderRadius: 8 }}>
              View All <FaArrowRight size={10} />
            </Link>
          </div>
          <div style={{ padding: '16px 20px' }}>
            {recentCrops.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '32px 0' }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>🌱</div>
                <div style={{ fontWeight: 600, color: 'var(--text-primary)', marginBottom: 6 }}>No crops yet</div>
                <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginBottom: 16 }}>Start tracking your first crop</div>
                <Link to="/crops" className="btn-amber" style={{ padding: '8px 18px', fontSize: '0.82rem', borderRadius: 10 }}>
                  <FaPlus size={10} /> Add Crop
                </Link>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {recentCrops.map(crop => (
                  <div key={crop._id} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 14px', background: 'var(--bg-elevated)', borderRadius: 12, border: '1px solid var(--border)', transition: 'all 0.2s' }}
                    onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--border-strong)'; e.currentTarget.style.background = '#fff'; }}
                    onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.background = 'var(--bg-elevated)'; }}
                  >
                    <div style={{ width: 42, height: 42, borderRadius: 10, background: 'var(--green-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontSize: 20 }}>🌾</div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
                        <span style={{ fontWeight: 700, fontSize: '0.875rem', color: 'var(--text-primary)' }}>{crop.name}</span>
                        <span className={getHealthBadgeClass(crop.health)}>{crop.health}</span>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <div style={{ flex: 1, height: 5, background: 'var(--border)', borderRadius: 99, overflow: 'hidden' }}>
                          <div style={{ height: '100%', width: `${getGrowthPct(crop.growthStage)}%`, background: 'linear-gradient(90deg, var(--green), var(--green-light))', borderRadius: 99, transition: 'width 0.5s' }} />
                        </div>
                        <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', whiteSpace: 'nowrap', fontWeight: 600 }}>{Math.round(getGrowthPct(crop.growthStage))}%</span>
                      </div>
                      <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: 4, textTransform: 'capitalize' }}>{crop.growthStage} stage</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* RIGHT: Alerts + Quick Actions */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* Alerts */}
          <div style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 16, overflow: 'hidden' }}>
            <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'linear-gradient(135deg, #fff5f5, #fff)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ width: 28, height: 28, background: 'var(--rose-dim)', borderRadius: 7, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <FaBell style={{ color: 'var(--rose)', fontSize: 11 }} />
                </div>
                <span style={{ fontWeight: 700, fontSize: '0.875rem', color: 'var(--text-primary)' }}>Alerts</span>
              </div>
              {recentAlerts.length > 0 && <span className="badge-rose">{recentAlerts.length}</span>}
            </div>
            <div style={{ padding: '12px 14px' }}>
              {recentAlerts.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '16px 0' }}>
                  <FaCheckCircle style={{ color: 'var(--green)', fontSize: 24, marginBottom: 8 }} />
                  <p style={{ color: 'var(--text-muted)', fontSize: '0.8rem', margin: 0, fontWeight: 500 }}>All clear! No alerts.</p>
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {recentAlerts.map((alert, i) => (
                    <div key={i} style={{ display: 'flex', gap: 10, padding: '10px 12px', background: 'var(--rose-dim)', borderRadius: 10, border: '1px solid rgba(220,38,38,0.15)' }}>
                      <FaExclamationTriangle style={{ color: 'var(--rose)', fontSize: 12, marginTop: 2, flexShrink: 0 }} />
                      <div>
                        <div style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-primary)' }}>{alert.cropName}</div>
                        <div style={{ fontSize: '0.72rem', color: 'var(--rose)' }}>{alert.message || alert.type}</div>
                      </div>
                    </div>
                  ))}
                  <Link to="/crops" style={{ fontSize: '0.75rem', color: 'var(--green)', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 4, fontWeight: 600, marginTop: 2 }}>
                    View all <FaArrowRight size={9} />
                  </Link>
                </div>
              )}
            </div>
          </div>

          {/* Quick Actions */}
          <div style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 16, overflow: 'hidden' }}>
            <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--border)', background: 'linear-gradient(135deg, #f0fdf4, #fff)' }}>
              <span style={{ fontWeight: 700, fontSize: '0.875rem', color: 'var(--text-primary)' }}>Quick Actions</span>
            </div>
            <div style={{ padding: '12px', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
              {quickActions.map((a, i) => (
                <Link key={i} to={a.link} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, padding: '12px 8px', background: 'var(--bg-elevated)', borderRadius: 10, textDecoration: 'none', border: '1px solid var(--border)', transition: 'all 0.2s' }}
                  onMouseEnter={e => { e.currentTarget.style.background = a.bg; e.currentTarget.style.borderColor = a.color + '40'; e.currentTarget.style.transform = 'translateY(-2px)'; }}
                  onMouseLeave={e => { e.currentTarget.style.background = 'var(--bg-elevated)'; e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.transform = 'none'; }}
                >
                  <span style={{ fontSize: 20 }}>{a.icon}</span>
                  <span style={{ fontSize: '0.68rem', fontWeight: 600, color: 'var(--text-secondary)', textAlign: 'center' }}>{a.name}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ── WEATHER ── */}
      <div style={{ marginBottom: 20 }}>
        <WeatherWidget />
      </div>

      {/* ── TIP BANNER ── */}
      <div style={{ background: 'linear-gradient(135deg, var(--green-dark), var(--green))', borderRadius: 16, padding: '20px 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 16, position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', right: -30, top: -30, width: 140, height: 140, borderRadius: '50%', background: 'rgba(255,255,255,0.06)', pointerEvents: 'none' }} />
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, position: 'relative', zIndex: 1 }}>
          <div style={{ width: 44, height: 44, background: 'rgba(255,255,255,0.15)', borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontSize: 20 }}>💡</div>
          <div>
            <div style={{ fontSize: '0.875rem', fontWeight: 700, color: '#fff', marginBottom: 3 }}>Farming Tip of the Day</div>
            <div style={{ fontSize: '0.8rem', color: 'rgba(255,255,255,0.8)' }}>Regular soil testing helps optimize fertilizer usage and improve crop yields by up to 20%.</div>
          </div>
        </div>
        <Link to="/forum" style={{ display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 18px', background: 'rgba(255,255,255,0.15)', color: '#fff', borderRadius: 10, fontWeight: 600, fontSize: '0.82rem', textDecoration: 'none', border: '1px solid rgba(255,255,255,0.25)', flexShrink: 0, transition: 'background 0.2s', position: 'relative', zIndex: 1 }}
          onMouseEnter={e => e.currentTarget.style.background = 'rgba(255,255,255,0.25)'}
          onMouseLeave={e => e.currentTarget.style.background = 'rgba(255,255,255,0.15)'}
        >
          <FaComments size={12} /> Ask Experts
        </Link>
      </div>
    </AppLayout>
  );
}
