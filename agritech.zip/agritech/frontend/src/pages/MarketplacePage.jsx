import React, { useState, useEffect } from 'react';
import {
  FaSearch, FaStar, FaTruck, FaShieldAlt, FaShoppingCart,
  FaPlus, FaEdit, FaTrash, FaTimes, FaLeaf
} from 'react-icons/fa';
import { getAllProducts, addProductReview, createProduct, updateProduct, deleteProduct } from '../services/productService';
import { createBooking } from '../services/bookingService';
import AppLayout from '../components/Layout/AppLayout';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';

const CATEGORIES = [
  { value: 'all',         label: 'All Products' },
  { value: 'seeds',       label: '🌱 Seeds' },
  { value: 'fertilizers', label: '💚 Fertilizers' },
  { value: 'pesticides',  label: '🐛 Pesticides' },
  { value: 'herbicides',  label: '🌿 Herbicides' },
  { value: 'equipment',   label: '🚜 Equipment' },
  { value: 'tools',       label: '🔧 Tools' },
];

const MarketplacePage = () => {
  const { user, isAdmin } = useAuth();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showProductModal, setShowProductModal] = useState(false);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [showFormModal, setShowFormModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [review, setReview] = useState({ rating: 5, comment: '' });
  const [productForm, setProductForm] = useState({ name: '', category: 'seeds', description: '', price: '', unit: 'kg', stock: '', manufacturer: '', images: [] });

  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(searchTerm), 500);
    return () => clearTimeout(t);
  }, [searchTerm]);

  useEffect(() => { fetchProducts(); }, [selectedCategory, debouncedSearch]);

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const filters = {};
      if (selectedCategory !== 'all') filters.category = selectedCategory;
      if (debouncedSearch) filters.search = debouncedSearch;
      const data = await getAllProducts(filters);
      setProducts(data);
    } catch { toast.error('Failed to load products'); }
    finally { setLoading(false); }
  };

  const handleBooking = async () => {
    try {
      await createBooking({ product: selectedProduct._id, bookingType: 'product_purchase', quantity, totalAmount: selectedProduct.price * quantity, deliveryAddress: user?.address || {} });
      toast.success('Order placed successfully!');
      setShowBookingModal(false);
    } catch { toast.error('Failed to place order'); }
  };

  const handleReview = async (e) => {
    e.preventDefault();
    try {
      await addProductReview(selectedProduct._id, review);
      toast.success('Review added!');
      setReview({ rating: 5, comment: '' });
      fetchProducts();
    } catch { toast.error('Failed to add review'); }
  };

  const handleSaveProduct = async (e) => {
    e.preventDefault();
    try {
      if (editingProduct) { await updateProduct(editingProduct._id, productForm); toast.success('Product updated!'); }
      else { await createProduct(productForm); toast.success('Product created!'); }
      setShowFormModal(false);
      setEditingProduct(null);
      setProductForm({ name: '', category: 'seeds', description: '', price: '', unit: 'kg', stock: '', manufacturer: '', images: [] });
      fetchProducts();
    } catch (error) { toast.error(error.response?.data?.message || 'Failed to save product'); }
  };

  const handleDeleteProduct = async (id) => {
    if (window.confirm('Delete this product?')) {
      try { await deleteProduct(id); toast.success('Product deleted'); fetchProducts(); }
      catch { toast.error('Failed to delete product'); }
    }
  };

  const openProductForm = (product = null) => {
    if (product) {
      setEditingProduct(product);
      setProductForm({ name: product.name, category: product.category, description: product.description, price: product.price, unit: product.unit, stock: product.stock, manufacturer: product.manufacturer || '', images: product.images || [] });
    } else {
      setEditingProduct(null);
      setProductForm({ name: '', category: 'seeds', description: '', price: '', unit: 'kg', stock: '', manufacturer: '', images: [] });
    }
    setShowFormModal(true);
  };

  const getCategoryColor = (cat) => ({
    seeds: 'var(--emerald)', fertilizers: 'var(--sky)', pesticides: 'var(--rose)',
    herbicides: 'var(--green)', equipment: 'var(--violet)', tools: 'var(--teal)',
  }[cat] || 'var(--text-muted)');

  if (loading) {
    return (
      <AppLayout title="Marketplace">
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '50vh', gap: 16 }}>
          <div className="spinner-amber" />
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Loading products...</p>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout
      title="Agri-Marketplace"
      subtitle="Quality farming products at competitive prices"
      actions={isAdmin && (
        <button className="btn-amber" onClick={() => openProductForm()} style={{ padding: '8px 16px', fontSize: '0.85rem' }}>
          <FaPlus size={11} /> Add Product
        </button>
      )}
    >
      {/* Search + Filter */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 20, flexWrap: 'wrap', alignItems: 'center' }}>
        <div style={{ position: 'relative', flex: 1, minWidth: 200 }}>
          <FaSearch style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)', fontSize: 12 }} />
          <input type="text" placeholder="Search products..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="input-dark" style={{ paddingLeft: 36 }} />
        </div>
        <select value={selectedCategory} onChange={e => setSelectedCategory(e.target.value)} className="input-dark" style={{ maxWidth: 180 }}>
          {CATEGORIES.map(cat => <option key={cat.value} value={cat.value}>{cat.label}</option>)}
        </select>
        <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>
          {products.length} product{products.length !== 1 ? 's' : ''}
        </span>
      </div>

      {/* Products Grid */}
      {products.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🛒</div>
          <div className="empty-title">No products found</div>
          <div className="empty-sub">Try a different search or category.</div>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 16 }}>
          {products.map((product) => (
            <div key={product._id} className="card-dark card-hover-lift" style={{ overflow: 'hidden' }}>
              {/* Image */}
              <div style={{ position: 'relative', height: 160, background: 'var(--bg-elevated)', overflow: 'hidden' }}>
                <img
                  src={product.images?.[0]
                    ? (product.images[0].startsWith('/uploads/') ? `http://localhost:5000${product.images[0]}` : product.images[0])
                    : `https://via.placeholder.com/300x160/dcfce7/16a34a?text=${encodeURIComponent(product.name)}`}
                  alt={product.name}
                  style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                  onError={e => { e.target.src = `https://via.placeholder.com/300x160/dcfce7/16a34a?text=${encodeURIComponent(product.name)}`; }}
                />
                <div style={{ position: 'absolute', top: 8, left: 8 }}>
                  <span style={{
                    background: 'rgba(255,255,255,0.9)', backdropFilter: 'blur(4px)',
                    color: getCategoryColor(product.category),
                    borderRadius: 6, padding: '3px 9px', fontSize: '0.72rem', fontWeight: 600,
                    textTransform: 'capitalize',
                    border: '1px solid rgba(22,163,74,0.15)',
                  }}>
                    {product.category}
                  </span>
                </div>
                {isAdmin && (
                  <div style={{ position: 'absolute', top: 8, right: 8, display: 'flex', gap: 4 }}>
                    <button className="btn-icon" style={{ background: 'rgba(15,23,42,0.85)', color: 'var(--emerald)', width: 28, height: 28 }} onClick={() => openProductForm(product)}><FaEdit size={11} /></button>
                    <button className="btn-icon" style={{ background: 'rgba(15,23,42,0.85)', color: 'var(--rose)', width: 28, height: 28 }} onClick={() => handleDeleteProduct(product._id)}><FaTrash size={11} /></button>
                  </div>
                )}
              </div>

              <div style={{ padding: '14px 16px' }}>
                <h6 style={{ fontWeight: 600, fontSize: '0.9rem', color: 'var(--text-primary)', marginBottom: 4 }}>{product.name}</h6>
                <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginBottom: 10, lineHeight: 1.4 }}>
                  {product.description?.length > 65 ? product.description.substring(0, 65) + '…' : product.description}
                </p>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                  <span style={{ fontWeight: 700, color: 'var(--green)', fontSize: '1rem' }}>
                    ₱{product.price}<span style={{ fontSize: '0.72rem', fontWeight: 400, color: 'var(--text-muted)' }}>/{product.unit}</span>
                  </span>
                  {product.rating > 0 && (
                    <span style={{ fontSize: '0.78rem', color: 'var(--green)', fontWeight: 600 }}>
                      <FaStar size={10} style={{ marginRight: 3 }} />{product.rating.toFixed(1)}
                    </span>
                  )}
                </div>
                <div style={{ marginBottom: 12 }}>
                  <small style={{ fontSize: '0.72rem' }}>
                    {product.stock > 0
                      ? <span style={{ color: 'var(--emerald)' }}>✓ {product.stock} {product.unit}s in stock</span>
                      : <span style={{ color: 'var(--rose)' }}>✗ Out of stock</span>
                    }
                  </small>
                </div>
                <button
                  className={product.stock === 0 ? 'btn-ghost' : 'btn-amber'}
                  style={{ width: '100%', justifyContent: 'center', padding: '8px', fontSize: '0.82rem', opacity: product.stock === 0 ? 0.5 : 1 }}
                  onClick={() => { setSelectedProduct(product); setShowProductModal(true); }}
                  disabled={product.stock === 0}
                >
                  {product.stock === 0 ? 'Out of Stock' : 'View Details'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Product Details Modal */}
      {showProductModal && selectedProduct && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setShowProductModal(false)}>
          <div className="modal-dark modal-dark-lg">
            <div className="modal-header-dark">
              <span className="modal-title-dark">{selectedProduct.name}</span>
              <button className="modal-close" onClick={() => setShowProductModal(false)}><FaTimes size={12} /></button>
            </div>
            <div className="modal-body-dark">
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
                <img
                  src={selectedProduct.images?.[0]
                    ? (selectedProduct.images[0].startsWith('/uploads/') ? `http://localhost:5000${selectedProduct.images[0]}` : selectedProduct.images[0])
                    : 'https://via.placeholder.com/300x220/dcfce7/16a34a?text=No+Image'}
                  alt={selectedProduct.name}
                  style={{ width: '100%', height: 220, objectFit: 'cover', borderRadius: 10 }}
                  onError={e => { e.target.src = 'https://via.placeholder.com/300x220/dcfce7/16a34a?text=No+Image'; }}
                />
                <div>
                  <span className="badge-amber" style={{ marginBottom: 10, display: 'inline-block', textTransform: 'capitalize' }}>{selectedProduct.category}</span>
                  <div style={{ fontSize: '1.4rem', fontWeight: 700, color: 'var(--green)', marginBottom: 8 }}>
                    ₱{selectedProduct.price}/{selectedProduct.unit}
                  </div>
                  <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', marginBottom: 12, lineHeight: 1.6 }}>{selectedProduct.description}</p>
                  <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginBottom: 4 }}>Stock: <span style={{ color: 'var(--text-secondary)' }}>{selectedProduct.stock} {selectedProduct.unit}s</span></div>
                  <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginBottom: 16 }}>Manufacturer: <span style={{ color: 'var(--text-secondary)' }}>{selectedProduct.manufacturer || 'Standard'}</span></div>
                  <div className="form-group">
                    <label className="label-dark">Quantity</label>
                    <input type="number" min="1" max={selectedProduct.stock} value={quantity} onChange={(e) => setQuantity(parseInt(e.target.value))} className="input-dark" style={{ maxWidth: 120 }} />
                  </div>
                  <button className="btn-amber" style={{ width: '100%', justifyContent: 'center', marginBottom: 8 }} onClick={() => setShowBookingModal(true)} disabled={selectedProduct.stock === 0}>
                    <FaShoppingCart size={13} /> Buy Now
                  </button>
                  <div className="alert-dark alert-sky" style={{ fontSize: '0.78rem' }}>
                    <FaTruck size={12} /> Free shipping on orders above ₱1000
                  </div>
                </div>
              </div>

              <div style={{ borderTop: '1px solid var(--border)', marginTop: 20, paddingTop: 20 }}>
                <div style={{ fontSize: '0.875rem', fontWeight: 600, color: 'var(--text-primary)', marginBottom: 12 }}>Customer Reviews</div>
                <form onSubmit={handleReview} style={{ marginBottom: 16 }}>
                  <div style={{ display: 'flex', gap: 10, marginBottom: 8 }}>
                    <select value={review.rating} onChange={(e) => setReview({ ...review, rating: parseInt(e.target.value) })} className="input-dark" style={{ maxWidth: 160 }}>
                      <option value="5">★★★★★ Excellent</option>
                      <option value="4">★★★★ Good</option>
                      <option value="3">★★★ Average</option>
                      <option value="2">★★ Poor</option>
                      <option value="1">★ Terrible</option>
                    </select>
                    <input type="text" placeholder="Write your review..." value={review.comment} onChange={(e) => setReview({ ...review, comment: e.target.value })} className="input-dark" style={{ flex: 1 }} />
                    <button type="submit" className="btn-ghost" style={{ padding: '9px 14px', fontSize: '0.82rem', flexShrink: 0 }}>Submit</button>
                  </div>
                </form>
                {selectedProduct.reviews?.length === 0 && (
                  <p style={{ color: 'var(--text-muted)', fontSize: '0.82rem' }}>No reviews yet. Be the first!</p>
                )}
                {selectedProduct.reviews?.slice().reverse().map((rev, idx) => (
                  <div key={idx} style={{ borderBottom: '1px solid var(--border)', paddingBottom: 10, marginBottom: 10 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                      <span style={{ color: '#d97706', fontSize: '0.85rem' }}>{'★'.repeat(rev.rating)}</span>
                      <small style={{ color: 'var(--text-muted)' }}>— {rev.user?.name || 'Anonymous'}</small>
                    </div>
                    <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', margin: 0 }}>{rev.comment}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Booking Modal */}
      {showBookingModal && selectedProduct && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setShowBookingModal(false)}>
          <div className="modal-dark">
            <div className="modal-header-dark">
              <span className="modal-title-dark">Confirm Order</span>
              <button className="modal-close" onClick={() => setShowBookingModal(false)}><FaTimes size={12} /></button>
            </div>
            <div className="modal-body-dark">
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 16 }}>
                {[
                  ['Product', selectedProduct.name],
                  ['Quantity', `${quantity} ${selectedProduct.unit}`],
                  ['Total', `₱${selectedProduct.price * quantity}`],
                ].map(([label, val]) => (
                  <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 14px', background: 'var(--bg-elevated)', borderRadius: 8 }}>
                    <span style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>{label}</span>
                    <span style={{ fontSize: '0.875rem', fontWeight: 600, color: 'var(--text-primary)' }}>{val}</span>
                  </div>
                ))}
              </div>
              <div className="alert-dark alert-emerald">
                <FaShieldAlt size={13} /> Secure payment after delivery
              </div>
            </div>
            <div className="modal-footer-dark">
              <button className="btn-ghost" onClick={() => setShowBookingModal(false)}>Cancel</button>
              <button className="btn-amber" onClick={handleBooking}>Place Order</button>
            </div>
          </div>
        </div>
      )}

      {/* Admin Product Form Modal */}
      {showFormModal && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setShowFormModal(false)}>
          <div className="modal-dark modal-dark-lg">
            <div className="modal-header-dark">
              <span className="modal-title-dark">{editingProduct ? '✏️ Edit Product' : '➕ Add New Product'}</span>
              <button className="modal-close" onClick={() => setShowFormModal(false)}><FaTimes size={12} /></button>
            </div>
            <form onSubmit={handleSaveProduct}>
              <div className="modal-body-dark">
                <div className="form-group">
                  <label className="label-dark">Product Name <span style={{ color: 'var(--rose)' }}>*</span></label>
                  <input type="text" value={productForm.name} onChange={(e) => setProductForm({ ...productForm, name: e.target.value })} required className="input-dark" />
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div className="form-group">
                    <label className="label-dark">Category <span style={{ color: 'var(--rose)' }}>*</span></label>
                    <select value={productForm.category} onChange={(e) => setProductForm({ ...productForm, category: e.target.value })} required className="input-dark">
                      <option value="seeds">🌱 Seeds</option>
                      <option value="fertilizers">💚 Fertilizers</option>
                      <option value="pesticides">🐛 Pesticides</option>
                      <option value="herbicides">🌿 Herbicides</option>
                      <option value="equipment">🚜 Equipment</option>
                      <option value="tools">🔧 Tools</option>
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="label-dark">Unit</label>
                    <select value={productForm.unit} onChange={(e) => setProductForm({ ...productForm, unit: e.target.value })} className="input-dark">
                      <option value="kg">Kilogram (kg)</option>
                      <option value="g">Gram (g)</option>
                      <option value="liter">Liter (L)</option>
                      <option value="ml">Milliliter (ml)</option>
                      <option value="piece">Piece</option>
                    </select>
                  </div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div className="form-group">
                    <label className="label-dark">Price (₱) <span style={{ color: 'var(--rose)' }}>*</span></label>
                    <input type="number" step="0.01" value={productForm.price} onChange={(e) => setProductForm({ ...productForm, price: e.target.value })} required className="input-dark" />
                  </div>
                  <div className="form-group">
                    <label className="label-dark">Stock <span style={{ color: 'var(--rose)' }}>*</span></label>
                    <input type="number" value={productForm.stock} onChange={(e) => setProductForm({ ...productForm, stock: e.target.value })} required className="input-dark" />
                  </div>
                </div>
                <div className="form-group">
                  <label className="label-dark">Description</label>
                  <textarea rows={3} value={productForm.description} onChange={(e) => setProductForm({ ...productForm, description: e.target.value })} placeholder="Product description..." className="input-dark" style={{ resize: 'vertical' }} />
                </div>
                <div className="form-group">
                  <label className="label-dark">Manufacturer</label>
                  <input type="text" value={productForm.manufacturer} onChange={(e) => setProductForm({ ...productForm, manufacturer: e.target.value })} placeholder="Manufacturer name" className="input-dark" />
                </div>
              </div>
              <div className="modal-footer-dark">
                <button type="button" className="btn-ghost" onClick={() => setShowFormModal(false)}>Cancel</button>
                <button type="submit" className="btn-amber">{editingProduct ? 'Update Product' : 'Create Product'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </AppLayout>
  );
};

export default MarketplacePage;
