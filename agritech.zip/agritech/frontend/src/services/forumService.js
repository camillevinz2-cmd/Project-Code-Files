import api from './api';

export const getForumPosts = async (filters = {}) => {
  const response = await api.get('/forum/posts', { params: filters });
  return response.data;
};

export const getPostById = async (id) => {
  const response = await api.get(`/forum/posts/${id}`);
  return response.data;
};

export const createPost = async (postData) => {
  const response = await api.post('/forum/posts', postData);
  return response.data;
};

export const addComment = async (postId, content) => {
  const response = await api.post(`/forum/posts/${postId}/comments`, { content });
  return response.data;
};

export const likePost = async (postId) => {
  const response = await api.post(`/forum/posts/${postId}/like`);
  return response.data;
};