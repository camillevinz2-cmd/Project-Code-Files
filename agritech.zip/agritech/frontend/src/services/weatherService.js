import api from './api';

export const getCurrentWeather = async (lat, lon) => {
  const response = await api.get('/weather/current', { params: { lat, lon } });
  return response.data;
};

export const getWeatherByCity = async (city) => {
  const response = await api.get('/weather/city', { params: { city } });
  return response.data;
};

export const getWeatherForecast = async (lat, lon) => {
  const response = await api.get('/weather/forecast', { params: { lat, lon } });
  return response.data;
};