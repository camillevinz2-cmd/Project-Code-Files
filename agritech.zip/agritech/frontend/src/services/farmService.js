import api from './api';

export const createFarm = async (farmData) => {
  const response = await api.post('/farms', farmData);
  return response.data;
};

export const getUserFarms = async () => {
  const response = await api.get('/farms');
  return response.data;
};

export const getFarmById = async (id) => {
  const response = await api.get(`/farms/${id}`);
  return response.data;
};

export const updateFarm = async (id, farmData) => {
  const response = await api.put(`/farms/${id}`, farmData);
  return response.data;
};

export const deleteFarm = async (id) => {
  const response = await api.delete(`/farms/${id}`);
  return response.data;
};

export const getFarmStats = async (id) => {
  const response = await api.get(`/farms/stats/${id}`);
  return response.data;
};