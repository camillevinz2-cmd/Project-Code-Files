# AgriTech — Smart Farming Platform

## Requirements
- Node.js v18+
- MongoDB (local or Atlas connection string in `.env`)

---

## Setup & Run

### 1. Backend
```bash
cd backend
npm install
npm run dev
```
Runs on: http://localhost:5000

### 2. Frontend (new terminal)
```bash
cd frontend
npm install
npm run dev
```
Runs on: http://localhost:5173

### 3. Create Admin Account (run once, after backend is running)
```bash
cd backend
node create-admin.js
```
Admin credentials:
- Email: `admin@agritech.com`
- Password: `Admin@1234`

---

## Environment Variables
Edit `backend/.env` before running:
```
MONGODB_URI=your_mongodb_connection_string
JWT_SECRET=your_jwt_secret
PORT=5000
```
