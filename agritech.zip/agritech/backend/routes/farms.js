const express = require('express');
const {
  createFarm,
  getUserFarms,
  getFarmById,
  updateFarm,
  deleteFarm,
  getFarmStats,
} = require('../controllers/farmController');
const { protect } = require('../middleware/auth');

const router = express.Router();

router.route('/')
  .post(protect, createFarm)
  .get(protect, getUserFarms);

router.get('/stats/:id', protect, getFarmStats);
router.route('/:id')
  .get(protect, getFarmById)
  .put(protect, updateFarm)
  .delete(protect, deleteFarm);

module.exports = router;