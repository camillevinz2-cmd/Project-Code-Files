const express = require('express');
const {
  getSystemStats,
  getAllUsers,
  getUserById,
  updateUser,
  deleteUser,
  getAllBookings,
  updateBookingStatus,
  getAllProductsAdmin,
  getAllForumPosts,
  deleteForumPost,
  getAllFarms,
  getAllCrops,
} = require('../controllers/adminController');
const { protect } = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

const router = express.Router();

router.use(protect);
router.use(roleCheck('admin'));

router.get('/stats', getSystemStats);

// Users
router.get('/users', getAllUsers);
router.get('/users/:id', getUserById);
router.put('/users/:id', updateUser);
router.delete('/users/:id', deleteUser);

// Bookings
router.get('/bookings', getAllBookings);
router.put('/bookings/:id', updateBookingStatus);

// Products
router.get('/products', getAllProductsAdmin);

// Forum
router.get('/forum', getAllForumPosts);
router.delete('/forum/:id', deleteForumPost);

// Farms & Crops
router.get('/farms', getAllFarms);
router.get('/crops', getAllCrops);

module.exports = router;
