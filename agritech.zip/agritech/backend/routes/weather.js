const express = require('express');
const {
  getWeatherByLocation,
  getWeatherByCity,
  getForecast,
} = require('../controllers/weatherController');

const router = express.Router();

router.get('/current', getWeatherByLocation);
router.get('/city', getWeatherByCity);
router.get('/forecast', getForecast);

module.exports = router;