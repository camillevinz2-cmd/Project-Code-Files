const User = require('../models/User');
const Farm = require('../models/Farm');
const Crop = require('../models/Crop');
const Product = require('../models/Product');
const Booking = require('../models/Booking');
const ForumPost = require('../models/ForumPost');
const ForumComment = require('../models/ForumComment');

// @desc    Get system statistics
// @route   GET /api/admin/stats
// @access  Private/Admin
const getSystemStats = async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    const totalFarmers = await User.countDocuments({ role: 'farmer' });
    const totalExperts = await User.countDocuments({ role: 'expert' });
    const totalFarms = await Farm.countDocuments();
    const totalCrops = await Crop.countDocuments();
    const totalProducts = await Product.countDocuments();
    const totalBookings = await Booking.countDocuments();
    const totalForumPosts = await ForumPost.countDocuments();
    
    // Recent activity
    const recentUsers = await User.find().sort('-createdAt').limit(5);
    const recentBookings = await Booking.find().sort('-createdAt').populate('user', 'name').limit(5);
    
    // Revenue stats
    const completedBookings = await Booking.find({ status: 'completed', paymentStatus: 'paid' });
    const totalRevenue = completedBookings.reduce((sum, booking) => sum + booking.totalAmount, 0);
    
    res.json({
      users: {
        total: totalUsers,
        farmers: totalFarmers,
        experts: totalExperts,
      },
      agriculture: {
        farms: totalFarms,
        crops: totalCrops,
      },
      commerce: {
        products: totalProducts,
        bookings: totalBookings,
        revenue: totalRevenue,
      },
      community: {
        forumPosts: totalForumPosts,
      },
      recentActivity: {
        users: recentUsers,
        bookings: recentBookings,
      },
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get all users (admin)
// @route   GET /api/admin/users
// @access  Private/Admin
const getAllUsers = async (req, res) => {
  try {
    const { role, search } = req.query;
    let query = {};
    
    if (role && role !== 'all') {
      query.role = role;
    }
    
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
      ];
    }
    
    const users = await User.find(query).select('-password').sort('-createdAt');
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get single user
// @route   GET /api/admin/users/:id
// @access  Private/Admin
const getUserById = async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password');
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Get user's farms and crops
    const farms = await Farm.find({ user: user._id });
    const crops = await Crop.find({ user: user._id });
    
    res.json({ user, farms, crops });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update user (admin)
// @route   PUT /api/admin/users/:id
// @access  Private/Admin
const updateUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Check email uniqueness if email is being changed
    if (req.body.email && req.body.email !== user.email) {
      const emailTaken = await User.findOne({ email: req.body.email });
      if (emailTaken) {
        return res.status(400).json({ message: 'Email is already in use by another account' });
      }
    }

    user.name = req.body.name || user.name;
    user.email = req.body.email || user.email;
    user.role = req.body.role || user.role;
    user.isVerified = req.body.isVerified !== undefined ? req.body.isVerified : user.isVerified;

    await user.save();
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Delete user (admin)
// @route   DELETE /api/admin/users/:id
// @access  Private/Admin
const deleteUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Delete associated data
    await Farm.deleteMany({ user: user._id });
    await Crop.deleteMany({ user: user._id });
    await Booking.deleteMany({ user: user._id });
    await ForumPost.deleteMany({ user: user._id });
    await ForumComment.deleteMany({ user: user._id });
    
    await user.deleteOne();
    res.json({ message: 'User and all associated data deleted' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get all bookings (admin)
// @route   GET /api/admin/bookings
// @access  Private/Admin
const getAllBookings = async (req, res) => {
  try {
    const bookings = await Booking.find()
      .populate('user', 'name email')
      .populate('product', 'name price')
      .sort('-createdAt');
    res.json(bookings);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update booking status (admin)
// @route   PUT /api/admin/bookings/:id
// @access  Private/Admin
const updateBookingStatus = async (req, res) => {
  try {
    const { status, paymentStatus } = req.body;
    const booking = await Booking.findById(req.params.id);
    
    if (!booking) {
      return res.status(404).json({ message: 'Booking not found' });
    }
    
    if (status) booking.status = status;
    if (paymentStatus) booking.paymentStatus = paymentStatus;
    if (status === 'completed') booking.completedDate = Date.now();
    
    await booking.save();
    res.json(booking);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get all products (admin)
// @route   GET /api/admin/products
// @access  Private/Admin
const getAllProductsAdmin = async (req, res) => {
  try {
    const products = await Product.find().sort('-createdAt');
    res.json(products);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get all forum posts (admin)
// @route   GET /api/admin/forum
// @access  Private/Admin
const getAllForumPosts = async (req, res) => {
  try {
    const posts = await ForumPost.find()
      .populate('user', 'name email')
      .sort('-createdAt');
    res.json(posts);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Delete forum post (admin)
// @route   DELETE /api/admin/forum/:id
// @access  Private/Admin
const deleteForumPost = async (req, res) => {
  try {
    const post = await ForumPost.findById(req.params.id);
    if (!post) return res.status(404).json({ message: 'Post not found' });
    await ForumComment.deleteMany({ post: req.params.id });
    await post.deleteOne();
    res.json({ message: 'Post deleted' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get all farms (admin)
// @route   GET /api/admin/farms
// @access  Private/Admin
const getAllFarms = async (req, res) => {
  try {
    const farms = await Farm.find()
      .populate('user', 'name email')
      .sort('-createdAt');
    res.json(farms);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get all crops (admin)
// @route   GET /api/admin/crops
// @access  Private/Admin
const getAllCrops = async (req, res) => {
  try {
    const crops = await Crop.find()
      .populate('user', 'name email')
      .populate('farm', 'name')
      .sort('-createdAt');
    res.json(crops);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getSystemStats,
  getAllUsers,
  getUserById,
  updateUser,
  deleteUser,
  getAllBookings,
  updateBookingStatus,
  getAllProductsAdmin,
  getAllForumPosts,
  deleteForumPost,
  getAllFarms,
  getAllCrops,
};