const ForumPost = require('../models/ForumPost');
const ForumComment = require('../models/ForumComment');

// @desc    Create forum post
// @route   POST /api/forum/posts
// @access  Private
const createPost = async (req, res) => {
  try {
    const post = await ForumPost.create({
      ...req.body,
      user: req.user._id,
    });
    
    const populatedPost = await post.populate('user', 'name role profilePicture');
    res.status(201).json(populatedPost);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get all forum posts
// @route   GET /api/forum/posts
// @access  Public
const getAllPosts = async (req, res) => {
  try {
    const { category, search, sort } = req.query;
    let query = {};
    
    if (category && category !== 'all') {
      query.category = category;
    }
    
    if (search) {
      query.$text = { $search: search };
    }
    
    let postsQuery = ForumPost.find(query).populate('user', 'name role profilePicture');
    
    if (sort === 'popular') {
      postsQuery = postsQuery.sort('-views -likes');
    } else if (sort === 'unanswered') {
      // This would need a comments count - simplified for now
      postsQuery = postsQuery.sort('-createdAt');
    } else {
      postsQuery = postsQuery.sort('-createdAt');
    }
    
    const posts = await postsQuery;
    res.json(posts);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get single post with comments
// @route   GET /api/forum/posts/:id
// @access  Public
const getPostById = async (req, res) => {
  try {
    const post = await ForumPost.findById(req.params.id)
      .populate('user', 'name role profilePicture');
    
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }
    
    // Increment views
    post.views += 1;
    await post.save();
    
    const comments = await ForumComment.find({ post: post._id })
      .populate('user', 'name role profilePicture')
      .sort('createdAt');
    
    res.json({ post, comments });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update post
// @route   PUT /api/forum/posts/:id
// @access  Private
const updatePost = async (req, res) => {
  try {
    const post = await ForumPost.findOne({
      _id: req.params.id,
      user: req.user._id,
    });
    
    if (!post) {
      return res.status(404).json({ message: 'Post not found or unauthorized' });
    }
    
    post.title = req.body.title || post.title;
    post.content = req.body.content || post.content;
    post.category = req.body.category || post.category;
    post.tags = req.body.tags || post.tags;
    
    await post.save();
    res.json(post);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Delete post
// @route   DELETE /api/forum/posts/:id
// @access  Private
const deletePost = async (req, res) => {
  try {
    const post = await ForumPost.findById(req.params.id);

    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }

    // Only the post owner or an admin can delete
    if (post.user.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to delete this post' });
    }

    await ForumComment.deleteMany({ post: req.params.id });
    await ForumPost.findByIdAndDelete(req.params.id);

    res.json({ message: 'Post deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Add comment to post
// @route   POST /api/forum/posts/:id/comments
// @access  Private
const addComment = async (req, res) => {
  try {
    const post = await ForumPost.findById(req.params.id);
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }
    
    const comment = await ForumComment.create({
      post: req.params.id,
      user: req.user._id,
      content: req.body.content,
      isExpertAnswer: req.user.role === 'expert' && req.body.isExpertAnswer,
    });
    
    const populatedComment = await comment.populate('user', 'name role profilePicture');
    res.status(201).json(populatedComment);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Like/unlike post
// @route   POST /api/forum/posts/:id/like
// @access  Private
const likePost = async (req, res) => {
  try {
    const post = await ForumPost.findById(req.params.id);
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }
    
    const index = post.likes.findIndex(id => id.equals(req.user._id));
    if (index === -1) {
      post.likes.push(req.user._id);
    } else {
      post.likes.splice(index, 1);
    }
    
    await post.save();
    res.json({ likes: post.likes.length });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Mark answer as accepted (for OP)
// @route   PUT /api/forum/comments/:commentId/accept
// @access  Private
const acceptAnswer = async (req, res) => {
  try {
    const comment = await ForumComment.findById(req.params.commentId);
    if (!comment) {
      return res.status(404).json({ message: 'Comment not found' });
    }
    
    const post = await ForumPost.findById(comment.post);
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }
    if (post.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Only post author can accept answers' });
    }
    
    comment.isExpertAnswer = true;
    await comment.save();
    
    post.isResolved = true;
    await post.save();
    
    res.json({ message: 'Answer accepted' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  createPost,
  getAllPosts,
  getPostById,
  updatePost,
  deletePost,
  addComment,
  likePost,
  acceptAnswer,
};