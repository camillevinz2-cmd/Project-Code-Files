const Crop = require('../models/Crop');
const Farm = require('../models/Farm');

// @desc    Add a crop
// @route   POST /api/crops
// @access  Private
const addCrop = async (req, res) => {
  try {
    const farm = await Farm.findOne({
      _id: req.body.farm,
      user: req.user._id,
    });
    
    if (!farm) {
      return res.status(404).json({ message: 'Farm not found' });
    }
    
    const crop = await Crop.create({
      ...req.body,
      user: req.user._id,
    });
    
    res.status(201).json(crop);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get all crops for user
// @route   GET /api/crops
// @access  Private
const getUserCrops = async (req, res) => {
  try {
    const crops = await Crop.find({ user: req.user._id })
      .populate('farm', 'name location')
      .sort('-createdAt');
    res.json(crops);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get crops by farm
// @route   GET /api/crops/farm/:farmId
// @access  Private
const getCropsByFarm = async (req, res) => {
  try {
    const farm = await Farm.findOne({
      _id: req.params.farmId,
      user: req.user._id,
    });
    
    if (!farm) {
      return res.status(404).json({ message: 'Farm not found' });
    }
    
    const crops = await Crop.find({ farm: farm._id });
    res.json(crops);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get single crop
// @route   GET /api/crops/:id
// @access  Private
const getCropById = async (req, res) => {
  try {
    const crop = await Crop.findOne({
      _id: req.params.id,
      user: req.user._id,
    }).populate('farm', 'name location');
    
    if (!crop) {
      return res.status(404).json({ message: 'Crop not found' });
    }
    
    res.json(crop);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update crop
// @route   PUT /api/crops/:id
// @access  Private
const updateCrop = async (req, res) => {
  try {
    const crop = await Crop.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      req.body,
      { new: true, runValidators: true }
    );
    
    if (!crop) {
      return res.status(404).json({ message: 'Crop not found' });
    }
    
    res.json(crop);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update growth stage
// @route   PUT /api/crops/:id/growth-stage
// @access  Private
const updateGrowthStage = async (req, res) => {
  try {
    const { growthStage, health } = req.body;
    
    const crop = await Crop.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      { growthStage, health },
      { new: true }
    );
    
    if (!crop) {
      return res.status(404).json({ message: 'Crop not found' });
    }
    
    // Add alert for important stage changes
    if (growthStage === 'harvesting') {
      crop.alerts.push({
        type: 'harvest_ready',
        message: '🎉 Your crop is ready for harvest!',
        severity: 'success',
        date: new Date(),
        isRead: false,
      });
      await crop.save();
    }
    
    res.json(crop);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Add pest/disease report (FIXED VERSION)
// @route   POST /api/crops/:id/report-issue
// @access  Private
// @desc    Add pest/disease report (FIXED - MULTIPLE ISSUES SUPPORT)
// @route   POST /api/crops/:id/report-issue
// @access  Private
const reportIssue = async (req, res) => {
  try {
    const { type, issue, severity } = req.body;
    
    console.log('Report issue request:', { type, issue, severity });
    
    const crop = await Crop.findOne({
      _id: req.params.id,
      user: req.user._id,
    });
    
    if (!crop) {
      return res.status(404).json({ message: 'Crop not found' });
    }
    
    // Determine severity level for alert
    let alertSeverity = 'info';
    let healthStatus = crop.health;
    
    if (severity === 'high') {
      alertSeverity = 'danger';
      healthStatus = 'poor';
    } else if (severity === 'medium') {
      alertSeverity = 'warning';
      if (healthStatus !== 'poor') {
        healthStatus = 'fair';
      }
    } else {
      alertSeverity = 'info';
    }
    
    // Create alert object
    const newAlert = {
      type: type === 'pest' ? 'pest_detected' : type === 'disease' ? 'disease_detected' : 'general',
      message: `${type === 'pest' ? '🐛 Pest' : type === 'disease' ? '🦠 Disease' : 'Issue'} detected: ${issue}`,
      severity: alertSeverity,
      date: new Date(),
      isRead: false
    };
    
    console.log('Creating alert:', newAlert);
    
    // Update crop health
    crop.health = healthStatus;
    
    // Update pest/disease status - APPEND, not replace
    if (type === 'pest') {
      // If there's an existing pestStatus, update it properly
      if (!crop.pestStatus) {
        crop.pestStatus = {};
      }
      crop.pestStatus.hasPests = true;
      // Append new pest type to array
      if (!crop.pestStatus.pestTypes) {
        crop.pestStatus.pestTypes = [];
      }
      crop.pestStatus.pestTypes.push(issue);
      crop.pestStatus.severity = severity;
      crop.pestStatus.lastTreatment = new Date();
    } else if (type === 'disease') {
      // If there's an existing diseaseStatus, update it properly
      if (!crop.diseaseStatus) {
        crop.diseaseStatus = {};
      }
      crop.diseaseStatus.hasDiseases = true;
      // Append new disease type to array
      if (!crop.diseaseStatus.diseaseTypes) {
        crop.diseaseStatus.diseaseTypes = [];
      }
      crop.diseaseStatus.diseaseTypes.push(issue);
      crop.diseaseStatus.severity = severity;
      crop.diseaseStatus.lastTreatment = new Date();
    }
    
    // Add alert to array (this keeps ALL alerts)
    crop.alerts.push(newAlert);
    
    await crop.save();
    
    // Return the updated crop with all alerts
    res.json({ 
      success: true, 
      message: 'Issue reported successfully',
      alert: newAlert,
      allAlerts: crop.alerts,
      pestStatus: crop.pestStatus,
      diseaseStatus: crop.diseaseStatus
    });
  } catch (error) {
    console.error('Report issue error:', error);
    res.status(500).json({ message: error.message });
  }
};

// @desc    Delete crop
// @route   DELETE /api/crops/:id
// @access  Private
const deleteCrop = async (req, res) => {
  try {
    const crop = await Crop.findOneAndDelete({
      _id: req.params.id,
      user: req.user._id,
    });
    
    if (!crop) {
      return res.status(404).json({ message: 'Crop not found' });
    }
    
    res.json({ message: 'Crop deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  addCrop,
  getUserCrops,
  getCropsByFarm,
  getCropById,
  updateCrop,
  updateGrowthStage,
  reportIssue,
  deleteCrop,
};