const ExpertAdvice = require('../models/ExpertAdvice');
const ForumComment = require('../models/ForumComment');
const ForumPost = require('../models/ForumPost');

// @desc    Create expert advice
// @route   POST /api/expert/advice
// @access  Private/Expert
const createAdvice = async (req, res) => {
  try {
    const advice = await ExpertAdvice.create({
      ...req.body,
      expert: req.user._id,
    });
    res.status(201).json(advice);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get all expert advice
// @route   GET /api/expert/advice
// @access  Public
const getAllAdvice = async (req, res) => {
  try {
    const { category } = req.query;
    let query = { isPublished: true };
    
    if (category) {
      query.category = category;
    }
    
    const advice = await ExpertAdvice.find(query)
      .populate('expert', 'name profilePicture')
      .sort('-createdAt');
    res.json(advice);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get single advice
// @route   GET /api/expert/advice/:id
// @access  Public
const getAdviceById = async (req, res) => {
  try {
    const advice = await ExpertAdvice.findById(req.params.id)
      .populate('expert', 'name profilePicture');
    
    if (!advice) {
      return res.status(404).json({ message: 'Advice not found' });
    }
    
    res.json(advice);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update advice
// @route   PUT /api/expert/advice/:id
// @access  Private/Expert
const updateAdvice = async (req, res) => {
  try {
    const advice = await ExpertAdvice.findOneAndUpdate(
      { _id: req.params.id, expert: req.user._id },
      req.body,
      { new: true }
    );
    
    if (!advice) {
      return res.status(404).json({ message: 'Advice not found or unauthorized' });
    }
    
    res.json(advice);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Delete advice
// @route   DELETE /api/expert/advice/:id
// @access  Private/Expert
const deleteAdvice = async (req, res) => {
  try {
    const advice = await ExpertAdvice.findOneAndDelete({
      _id: req.params.id,
      expert: req.user._id,
    });
    
    if (!advice) {
      return res.status(404).json({ message: 'Advice not found or unauthorized' });
    }
    
    res.json({ message: 'Advice deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Like advice
// @route   POST /api/expert/advice/:id/like
// @access  Private
const likeAdvice = async (req, res) => {
  try {
    const advice = await ExpertAdvice.findById(req.params.id);
    if (!advice) {
      return res.status(404).json({ message: 'Advice not found' });
    }
    
    const index = advice.likes.findIndex(id => id.equals(req.user._id));
    if (index === -1) {
      advice.likes.push(req.user._id);
    } else {
      advice.likes.splice(index, 1);
    }
    
    await advice.save();
    res.json({ likes: advice.likes.length });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get unanswered forum questions for experts
// @route   GET /api/expert/pending-questions
// @access  Private/Expert
const getPendingQuestions = async (req, res) => {
  try {
    // Find posts with no expert answers
    const posts = await ForumComment.aggregate([
      {
        $group: {
          _id: '$post',
          hasExpertAnswer: { $max: { $cond: ['$isExpertAnswer', 1, 0] } }
        }
      },
      { $match: { hasExpertAnswer: 0 } }
    ]);
    
    const postIds = posts.map(p => p._id);
    const pendingPosts = await ForumPost.find({ _id: { $in: postIds }, isResolved: false })
      .populate('user', 'name')
      .sort('-createdAt')
      .limit(20);
    
    res.json(pendingPosts);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  createAdvice,
  getAllAdvice,
  getAdviceById,
  updateAdvice,
  deleteAdvice,
  likeAdvice,
  getPendingQuestions,
};