const mongoose = require('mongoose');

const cropSchema = new mongoose.Schema({
  farm: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Farm',
    required: true,
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  name: {
    type: String,
    required: [true, 'Please add crop name'],
    trim: true,
  },
  variety: {
    type: String,
    default: ''
  },
  plantingDate: {
    type: Date,
    required: true,
  },
  expectedHarvestDate: {
    type: Date,
    default: null
  },
  actualHarvestDate: {
    type: Date,
    default: null
  },
  areaPlanted: {
    value: {
      type: Number,
      default: 0
    },
    unit: {
      type: String,
      default: 'acre',
    },
  },
  seedQuantity: {
    value: Number,
    unit: String,
  },
  growthStage: {
    type: String,
    enum: ['planting', 'germination', 'vegetative', 'flowering', 'fruiting', 'maturing', 'harvesting', 'fallow'],
    default: 'planting',
  },
  health: {
    type: String,
    enum: ['excellent', 'good', 'fair', 'poor', 'critical'],
    default: 'good',
  },
  pestStatus: {
    hasPests: { type: Boolean, default: false },
    pestTypes: [String],
    severity: {
      type: String,
      enum: ['low', 'medium', 'high'],
    },
    lastTreatment: Date,
  },
  diseaseStatus: {
    hasDiseases: { type: Boolean, default: false },
    diseaseTypes: [String],
    severity: {
      type: String,
      enum: ['low', 'medium', 'high'],
    },
    lastTreatment: Date,
  },
  irrigation: {
    lastIrrigated: Date,
    nextIrrigationDue: Date,
    waterUsage: Number,
    frequency: Number,
  },
  fertilizers: [{
    name: String,
    type: String,
    applicationDate: Date,
    quantity: Number,
    unit: String,
  }],
  pesticides: [{
    name: String,
    applicationDate: Date,
    quantity: Number,
    reason: String,
  }],
  predictedYield: {
    value: {
      type: Number,
      default: 0
    },
    unit: {
      type: String,
      default: 'kg',
    },
  },
  actualYield: {
    value: {
      type: Number,
      default: 0
    },
    unit: String,
  },
  marketPrice: {
    current: Number,
    updatedAt: Date,
  },
  images: [String],
  notes: String,
  // FIXED: alerts as array of objects, not strings
  alerts: [{
    type: {
      type: String,
      enum: ['pest_detected', 'disease_detected', 'harvest_ready', 'irrigation_needed', 'general'],
      default: 'general'
    },
    message: {
      type: String,
      required: true
    },
    severity: {
      type: String,
      enum: ['info', 'warning', 'danger', 'success'],
      default: 'info'
    },
    date: {
      type: Date,
      default: Date.now
    },
    isRead: {
      type: Boolean,
      default: false
    }
  }],
}, {
  timestamps: true,
});

// Index for efficient queries
cropSchema.index({ farm: 1, plantingDate: -1 });
cropSchema.index({ user: 1, growthStage: 1 });

module.exports = mongoose.model('Crop', cropSchema);