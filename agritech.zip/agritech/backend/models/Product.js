const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Please add product name'],
    trim: true,
  },
  category: {
    type: String,
    enum: ['seeds', 'fertilizers', 'pesticides', 'herbicides', 'equipment', 'tools', 'other'],
    required: true,
  },
  subCategory: String,
  description: {
    type: String,
    required: true,
  },
  price: {
    type: Number,
    required: true,
    min: 0,
  },
  discountPrice: Number,
  unit: {
    type: String,
    default: 'kg',
  },
  stock: {
    type: Number,
    required: true,
    default: 0,
    min: 0,
  },
  manufacturer: String,
  images: [String],
  specifications: {
    type: Map,
    of: String,
  },
  rating: {
    type: Number,
    min: 0,
    max: 5,
    default: 0,
  },
  reviews: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    rating: Number,
    comment: String,
    date: {
      type: Date,
      default: Date.now,
    },
  }],
  isAvailable: {
    type: Boolean,
    default: true,
  },
}, {
  timestamps: true,
});

module.exports = mongoose.model('Product', productSchema);